import firebase from './firebaseConfig';
import moment from 'moment';

export const SendMessage = async (currentUserId, guestUserId, msgValue,imgSource,fcmToken1) => {
     console.log('-------new fcm token on message screen *******************',currentUserId,guestUserId);
    var todayDate=moment();
    try {
        return await firebase.
            database().
            ref('messages/' + currentUserId).
           child(guestUserId).
            push({
                messege: {
                    sender: currentUserId,
                    reciever: guestUserId,
                    msg: msgValue,
                    date:todayDate.format('YYYY-MM-DD'),
                    image:imgSource,
                    token:token,
                     token:fcmToken1,
                    // token:fcmToken,
                    
                    time:todayDate.format('hh:mm A')
                },
            })
    } catch (error) {
        return error;
    }
}                


export const RecieveMessage = async (currentUserId, guestUserId, msgValue,imgSource,fcmToken1) => {
       console.log('-------refresh arriwal ************************************',fcmToken1);
    try {
        var todayDate=moment();
        return await firebase.
            database().
            ref('messages/' + guestUserId).
            child(currentUserId).
            push({
                messege: {
                    sender: currentUserId,
                    reciever: guestUserId,
                    msg: msgValue,
                    image:imgSource,
                     token:fcmToken1,
                     token:token,
                    date:todayDate.format('YYYY-MM-DD'),
                    time:todayDate.format('hh:mm A')
                },
            })
    } catch (error) {
        return error;
    }
}
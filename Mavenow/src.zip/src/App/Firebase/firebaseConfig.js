import Firebase from 'firebase';
import RNFirebase from 'react-native-firebase';


const firebaseConfig = {

    apiKey: "AIzaSyAcEyhmZ_0HdzadleOHwYexQhBMG4RiSFI",
    databaseURL: "https://mavenow-34cdd-default-rtdb.firebaseio.com/",
    projectId: "mavenow-34cdd",
    appId: "1:251238529081:android:ec85b1c389b7cd9d58f5e8",
    debug: true,
    promptOnMissingPlayServices: true
    
};
// const firebase = RNFirebase.initializeApp(configurationOptions)

export default Firebase.initializeApp(firebaseConfig);



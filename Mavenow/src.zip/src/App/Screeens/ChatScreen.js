import React, { Component } from 'react';
import { View, Text, TouchableOpacity, Image, TextInput, FlatList, Dimensions,ScrollView ,AppState,StyleSheet } from 'react-native';
import AppHeader from '../Components/AppHeader';
import Spinner from 'react-native-loading-spinner-overlay';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icons from 'react-native-vector-icons/MaterialIcons';
import { SendMessage, RecieveMessage } from '../Firebase/Message';
import firebase from '../Firebase/firebaseConfig';
import ImgToBase64 from 'react-native-image-base64';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import moment from 'moment';
import axios from 'axios'; 
import { NativeModules } from 'react-native';


import { topNotificationChanged, logOut } from '../actions';
class Chat extends Component {
    state = {
        message: '',
        currentUid: '',
        allMessages: [],
        image: '',
        fcmToken1:this.props.navigation.getParam('token'),
        token:'',
        guestUid : this.props.navigation.getParam('guestUid')
        
    }

    async componentDidMount() {
   const currentUid = await AsyncStorage.getItem('UID');
        
         const token = this.props.navigation.getParam('token');
         this.setState({ currentUid: currentUid });
        try { 
            firebase.database().
                ref('messages').
                child(currentUid).
                child(this.state.guestUid).
                on("value", (dataSnapshot) => {
                console.log('dataSnapshot',dataSnapshot.val());
                    let message = [];
                    

                    dataSnapshot.forEach((data) => {
                        
                        message.push({
                            sendBy: data.val().messege.sender,
                            recieveBy: data.val().messege.reciever,
                            msg: data.val().messege.msg,
                            image: data.val().messege.image,
                            date: data.val().messege.date,
                            time: data.val().messege.time,
                            fcmToken1: data.val().messege.fcmToken1,
                             fcmtoken:data.val().message.fcmToken,
                        });
                    })
                    this.setState({ allMessages: message.reverse() });
                    console.log('allMessages is here =============+++++++++++++++++++++++++++++', this.state.allMessages)
                    
                })
        } catch (error) {
            alert(error);
        }
    }

      // componentWillUnmount() {
      // this.onTokenRefreshListener();
      // this.messageListener();
      // }
      // async checkPermission() {
      //   const enabled = await firebase.messaging().hasPermission();
      //   console.log("checkPermission=" + enabled);
      //   if (enabled) {
      //     // this.getFCMToken();
      //     // testTocken();
      //     let fcmToken = await AsyncStorage.getItem('fcmToken', "");
      //     console.log("getToken=" + enabled);
    
      //     if (!fcmToken) {
      //       fcmToken = await firebase.messaging().getToken();
      //       alert(fcmToken);
      //       if (fcmToken) {
      //         // user has a device token
      //         await AsyncStorage.setItem('fcmToken', fcmToken);
      //       }
      //     }
      //   } 
      //   else {
      //     this.onTokenRefreshListener();
      //   }
      // }
    
      // async onTokenRefreshListener() {
      //   try {
      //     await firebase.messaging().requestPermission();
      //     // User has authorised
      //     // this.getFCMToken();
      //     let fcmToken = await AsyncStorage.getItem('fcmToken', "");
      //     console.log("getToken=" + enabled);
    
      //     if (!fcmToken) {
      //       fcmToken = await firebase.messaging().getToken();
      //       alert(fcmToken);
      //       if (fcmToken) {
      //         // user has a device token
      //         await AsyncStorage.setItem('fcmToken', fcmToken);
      //       }
      //     }
      //   } catch (error) {
      //     // User has rejected permissions
      //     console.log('permission rejected');
      //   }
      // }
     
   


                                        // ====================================  
openGallery() {
    
            launchImageLibrary('photo', (response) => {
            this.setState({ loader: true });
            ImgToBase64.getBase64String(response.uri)
            .then(async (base64String) => {
                    let source = "data:image/jpeg;base64," + base64String;
                    SendMessage(this.state.currentUid, this.state.guestUid, "", source,this.state.fcmToken1).
                        then((res) => {
                            this.setState({ loader: false })
                        }).catch((err) => {
                            alert(err)
                        })

                    RecieveMessage(this.state.currentUid, this.state.guestUid, "", source,this.state.fcmToken1).
                    then((res) => {
                            this.setState({ loader: false })
                        }).catch((err) => {
                            alert(err)
                        })
                })
                .catch(err => this.setState({ loader: false }));
        })
    }

  //  =========================================== ============================== API Calling ==================================================================

   selectedItems = item =>{
    if(this.selectedMsg.includes(item)){
        const newListItems=selectedMsg.filter(
            ListItem=>ListItem!==item,
        );
         this.setSelectedMsg(newListItems)
    }
    this.selectedItems(selectedMsg)
  }

  ApiCalling=async()=>{
    var token22=this.props.navigation.getParam('token')


    console.log('token22',token22);
    // return false
    var data = JSON.stringify({
        data: {
          "message": this.state.message,
          "messageType": this.state.fcmToken1,
          "title": "Gmail",
          
        },
        notification: {
          "body": this.state.message,
          "image": '',
          "tag": "hey",
          "title": "123456"
        },
        to:this.state.fcmToken1
      });
      
      var config = {
        method: 'post',
        url: 'https://fcm.googleapis.com/fcm/send',
        headers: { 
          'Authorization': 'key=AAAA9A4Ejc8:APA91bFMn8fSYcmRqE1nwNA2H-vZq4wbg4Uzp67P7wx900PyZfe6yMnmzyAoI5u9E5kJusueFLuCp5h_MUJgONxnOcrbJXEpFJlSh7Z-Qhd0OXlboeConQkKMeuK-AieqcC1RseX9Ixr', 
          'Content-Type': 'application/json'
        },
        data : data
      };
      console.log(">>>>>>>>>>>>",data)
      axios(config)
      .then(function (response) {
      console.log("Api Data======",response.data);
      })
      .catch(function (error) {
        console.log(error);
      });

        }  

  //  ================================================================== JsonData =========================================================================//

//   JsonData =async()=>{
//     let fcmToken = await AsyncStorage.getItem('fcmToken')
//     this.setState({fcmToken1:fcmToken})
//     // console.log('fcmToken send msgggggggg---->',fcmToken);
// // console.log('==========> send meg console....' )
//     try{
//         console.log('i am here json data')
//         console.log({
//             "data":{
//                  "message": this.state.message ,
//                   "title":this.state.name 
//              },
//              "notification":{
//                   "email": this.state.email,
//                   "image":'',
//                   "tag":"hey",
//                   "title":this.state.password
//              },
 
//              "to":fcmToken
//              })
//     }
//     catch (error) {
//         console.log('==========> send meg error..',error)
//     }

// #include<stdio.h>  
// int main(){    
// int n,i,m=0,flag=0;    
// printf("Enter the number to check prime:");    
// scanf("%d",&n);    
// m=n/2;    
// for(i=2;i<=m;i++)    
// {    
// if(n%i==0)    
// {    
// printf("Number is not prime");    
// flag=1;    
// break;    
// }    
// }    
// if(flag==0)    
// printf("Number is prime");     
// return 0;  
//  }    
    
    
// }

//========================================================================Token================================================================//
  getFcmToken = async () => {
    // let fcmToken = await AsyncStorage.getItem('fcmToken')
    // console.log(fcmToken,'new  get fcm token refresh token arriwal =============================================================================')
    
   
    let fcmToken1 = await AsyncStorage.getItem('fcmToken')
    console.log(fcmToken1, "the old token Login screen================")
    if (fcmToken1) {
        try {
            const fcmToken = await messaging().getToken(); 
            if (fcmToken) {
                console.log("the new generate token",fcmToken );
               await AsyncStorage.setItem('fcmToken', fcmToken)
}
} catch (error) {
            console.log("error resaid in fcmToken......",error )
            //  ShowError(error.message)
        }
    }
}

//========================================================================SendMessage================================================================//
    sendMessage = async () => {
 
    
       this.ApiCalling();
      //  console.log(' here is api calling data',this.ApiCalling())
          let fcmToken1 = await AsyncStorage.getItem('fcmToken')
           console.log(fcmToken1 , "This is FCMToken*-*********************************************************************")
    
        if (this.state.message) {
            SendMessage(this.state.currentUid, this.state.guestUid, this.state.message,'').
                then((res) => {
                    console.log(' iam error',res);
                    this.setState({ message: '' })
                }).catch((err) => {
                    alert(err)
                })

            RecieveMessage(this.state.currentUid, this.state.guestUid, this.state.message,'').
                then((res) => {
                    console.log(res);
                    this.setState({ message: '' })
                }).catch((err) => {
                    alert(err)
                })
        }
        // this.renderTicks()
    }

    // ============================================================================== Delete and Copy Messages ==============================================================================================

  
  
    // onDelete = (messageIdToDelete) => {
    //     this.setState(previousState =>
    //       ({ messages: previousState.messages.filter(message => message.id !== messageIdToDelete) }))
          
    //     }
    
    //     onLongPress(context, message) {
    //     console.log("Context and message",context, message);
    //     const options = ['copy','Delete Message', 'Cancel'];
    //     const cancelButtonIndex = options.length - 1;
    //     context.actionSheet().showActionSheetWithOptions({
    //         options,
    //         cancelButtonIndex
    //     }, (buttonIndex) => {
    //         switch (buttonIndex) {
    //             case 0:
    //                 Clipboard.setString(message.text);
    //                 break;
    //             case 1:
    //                 this.onDelete(messageIdToDelete) //pass the function here
    //                 break;
    //         }
    //     });
    // }
   
    // ============================================================================================================================================================================
    render() 
    {
        return (
            <View style={{ flex: 1, backgroundColor: '#fff' }}>
              

                <View>
                <AppHeader title={this.props.navigation.getParam('UserName')} navigation={this.props.navigation} onPress={() => this.logOut()} />
                </View>

                
                
                <FlatList 
                    inverted
                    style={{ marginBottom: 60,padding:8 }}
                    data={this.state.allMessages}
                    keyExtractor={(_, index) => index.toString()}
                    renderItem={({ item }) => (
                        <TouchableOpacity   onLongPress={() =>this.selectedItems(item)} >
                        <View style={{ marginVertical: 5, maxWidth: Dimensions.get('window').width / 2 + 10, alignSelf: this.state.currentUid === item.sendBy ? 'flex-end' : 'flex-start',  }}>
                           
                            <View  style={{ borderRadius: 20, backgroundColor: this.state.currentUid === item.sendBy ? '#075E54' : '#343434' }}>
                               
                                {item.image === "" ? <Text  selectable  style={{ padding: 10, fontSize: 16, fontWeight: 'bold', color:'#fff', }}>
                                    {item.msg} {"   "} <Text style={{ fontSize: 12, color:'#fff' }}>{item.time}</Text>
                                </Text> :
                                    <View style={{backgroundColor:"#fff"}}>
                                        <Image  source={{ uri: item.image }} style={{ width: Dimensions.get('window').width / 2 + 20, height: 140, resizeMode: 'stretch', borderRadius: 20,borderWidth:2,borderColor:"white",alignItems:"center",alignSelf:"center",marginRight:65 }} />
                                        <Text  style={{ fontSize: 12,position:'absolute',bottom:5,right:35 }}>{item.time}</Text>
                                    </View>
                                }
                            </View>
                           
                        </View>
                        </TouchableOpacity>
                    )}
                />
                <View style={{ bottom: 0, height: 50, width: '100%', position: 'absolute', flexDirection: 'row' }}>
                    <TouchableOpacity style={{ width: '10%', justifyContent: 'center', alignItems: 'center', marginRight: 10 }} onPress={() => this.openGallery()}>

                       <Image resizeMode='contain'  style={{width:25, height:25,}}
                                    source={require('./assests/gg.png')}></Image> 
                                    
                    </TouchableOpacity>
                    <View style={{ width: '75%', justifyContent: 'center' }}>
                        <TextInput value={this.state.message} onChangeText={(text) => this.setState({ message: text })} placeholder="Enter Message" placeholderTextColor="#000" style={{ height: 40, borderRadius: 20, backgroundColor: '#ccc' }} />
                    </View>
                    <TouchableOpacity style={{ width: '10%', justifyContent: 'center', alignItems: 'center', marginLeft: 5 }} onPress={() => this.sendMessage()}>
                        {/* <Icons name="send" size={30} color="#000" /> */}
                        {/* <Image resizeMode='contain'  style={{width:25, height:25,}}   source={require('./assests/savee.jpg')}/> */}
                                    <Image resizeMode='contain'  style={{width:100,height:55}} source={require('./assests/savee.jpg')}/> 
                    </TouchableOpacity>
                </View>
                <Spinner
                    visible={this.state.loader}
                />
            </View>
        )
    }
}




export default Chat;  





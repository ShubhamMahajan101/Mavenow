import { View, Text } from 'react-native'
import React from 'react'

export default function Scanner() {
  return (
    <View>
      <Text>Scanner</Text>
    </View>
  )
}
import { View, Text } from 'react-native'
import React from 'react'

export default function AnimatedLoader() {
  return (
    <View>
      <Text>AnimatedLoader================</Text>
    </View>
  )
}
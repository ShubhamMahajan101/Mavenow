import { View, StatusBar, Text, StyleSheet, Dimensions, TouchableOpacity, Image, Modal, Alert, ScrollView, FlatList ,} from 'react-native'
import React, { useState, useRef, useEffect } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from './Provider/Colorsfont';
import PhoneInput from 'react-native-phone-number-input';
import { Stack, TextInput, } from "@react-native-material/core";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { config, msgProvider, msgText, consolepro, Lang_chg, Font, localStorage, msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;
import NetInfo from '@react-native-community/netinfo';
import DeviceInfo from 'react-native-device-info';
import axios from "axios"
import { color } from 'react-native-reanimated';
import { colors } from 'react-native-elements';
const Msignup = ({ navigation }) => {

  const [select, SetSelect] = useState('Maven')
  const [modalVisible1, setModalVisible1] = useState(false);
  const [validationmodal, setvalidationmodal] = useState(false);
  const [ModalVisible_Gif, setModalVisible_Gif] = useState(false);
  const [shouldShow, setShouldShow] = useState(false);
  const [mobile_number, setValue] = useState('');
  const [language, setlanguage] = useState('');
  const [languageId, setlanguageId] = useState('Select anguage');
  const [countryCode, setCountryCode] = useState('');
  const [formattedValue, setFormattedValue] = useState('');
  const [fullname, setFullname] = useState('')
  const [email, setEmail] = useState('')
  const [languages, setlanguages] = useState('');
  const [DeviceId, setDeviceId] = useState('');
  const [validation, setvalidation] = useState('');
  const [checked, setChecked] = useState('current')
  const[toggle,settogle]=useState('toggle');
  const phoneInput = useRef(null);

console.log('=====================>', select);

  // =====================================================
  useEffect(() => {
TogetDeviceId()
    apiCalling();
    const unsubscribe = NetInfo.addEventListener((state) => {
      if (state.isConnected == false) {
        alert(
          "Please check your internet connection",
        );
      }
    });
    return () => {
 unsubscribe();
    };

  }, []);
const TogetDeviceId = async () => {
    var uniqueId = await DeviceInfo.getUniqueId();
    setDeviceId(uniqueId)
    console.log('uniqueId=======>>>>>>', uniqueId);
  }

  // ============ Api Calling to get Languages ===============
  const apiCalling = () => {
    axios.get('https://mavenow.com:8001/user/GetLanguages')
      .then(res => {
        const nameList = res.data.result;
        // const imageArray = nameList.result;
        console.log('---------->', nameList)

        setlanguages(nameList)
        
      })
      .catch(function (error) {
        console.log('---------->', error);
      }); }

  // ========================================================
  const setSelectedIndex1 = (item ,index) => {
console.log('-----------------',item);
    for(let i=0;i<=languages.length;i++){
      if(item.code=="en"){
        config.language = 0
      } if(item.code=="hi"){
        config.language = 1
      }if(item.code=="es"){
        config.language = 2
      }
      if(item.code=="nl"){
        config.language = 3
      }
      if(item.code=="fr"){
        config.language = 4
      }
      if(item.code=="th"){
        config.language = 5
      }
      if(item.code=="ar"){
        config.language = 6
      }
      if(item.code=="zh"){
        config.language = 7
      }
    }
    languages.forEach((elem) => {
      elem.toggle = false
      if (elem.id === item.id) {
        elem.toggle = true
        setlanguage(elem.name)
        setlanguageId(elem.id)  } })
    setlanguages([...languages]);
  }; 

    









 


   const _loginBtn = () => {
 console.log('Before validation');
 if (shouldShow == false) {
      msgProvider.toast(msgText.acceptTerms[config.language], 'center')
      return false
    }
    // ======================== Validations for Signup ==================
    // {fullname.length==""?Colors.red:Colors.themecolor}
    // if (fullname.length <= 0?Colors.red:Colors.themecolor && email.length <= 0 && mobile_number.length <= 0) {
    //   msgProvider.toast(msgText.Sign_In_or_Login_error_msg[config.language], 'center')
    //   return false
    // }
    //=====================All Fields Check================

    if (fullname.length <= 0) {
      msgProvider.toast(msgText.accountHolderName[config.language], 'center')
      return false
    }

    if (fullname.length <= 2) {
      msgProvider.toast(msgText.firstNameMinLength[config.language], 'center')
      return false
    }
    //===========email============================
    if (email.length <= 0) {
      msgProvider.toast(msgText.emptyEmail[config.language], 'center')
      setEmail('NA')
      return false
    }
    var reg = config.emailvalidation;
    if (reg.test(email) !== true) {
      msgProvider.toast(msgText.validEmail[config.language], 'center')
      setEmail('NA')
      return false
    }
    //======================================mobile============================
    if (mobile_number.length <= 9) {
      msgProvider.toast(msgText.emptyMobile[config.language], 'center')
      return false
    }
    if (language.length <= 0) {
      msgProvider.toast(msgText.ChooseLanguage[config.language], 'center')
      return false
    }
    if (mobile_number.length > 13) {
      msgProvider.toast(msgText.mobileMaxLength[config.language], 'center')
      return false
    }
    var mobilevalidation = config.mobilevalidation;
    if (mobilevalidation.test(mobile_number) !== true) {
      msgProvider.toast(msgText.validMobile[config.language], 'center')
      return false
    }
  
    if (language == 'Select language') {
      msgProvider.toast(msgText.ChooseLanguage[config.language], 'center')
      return false
    }



    if (select == "Maven") {
      var isUserType = 1;
    } else {
      var isUserType = 2;
    }

    setModalVisible_Gif(true)

    console.log('After validation');

    var dataTOSendToNextPage = {
      fullName: fullname,
      email: email,
      mobile: mobile_number,
      countryCode: countryCode,
      userType: isUserType,
      firebaseToken: "",
      deviceId: DeviceId,
      lcid: languageId,
    }

    var dataTOSend = {
      mobileNo: mobile_number,
      countryCode: countryCode,
      email: email,
      fullName: fullname
    }

    let config12 = {
      method: 'post',
      maxBodyLength: Infinity,
      url: config.baseURL + 'registration/otp',
      headers: {
        'Content-Type': 'application/json'
      },
      data: dataTOSend
    };

    axios.request(config12)
      .then(async (response) => {
        console.log('-------------------------- sign up screen>>', response.data);
        // var user_arr = response.data;
        var otpsuccesses = response.data.ErrorCode;
        console.log("otpsuccesses====================================", otpsuccesses);
        var ErrorMessage = response.data.ErrorMessage;
        if (otpsuccesses == 200) {
          setModalVisible_Gif(false)
          await localStorage.setItemObject('dataTOSend', dataTOSend);
          var userId = response.data.registrationOTP._id
          console.log('userId------>>>', userId);
          navigation.navigate('VerificationCode', { mobile_number: mobile_number, dataTOSend: dataTOSendToNextPage, isLoginScreen: false })
        }
        else {
          setTimeout(() => {
            msgProvider.alert(msgTitle.information[config.language], ErrorMessage, false);
            return false;
           }, 2000);
        }
        })
       .catch((error) => {
        console.log(error);
          }); }
  // ==================================================================================================================== >>
  return (
          <View style={{ flex: 1, backgroundColor: Colors.themecolor }}>
          <SafeAreaView style={styles.SafeAreaView}>
         <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
         <ScrollView>

          {/* -------------------------------------  gif modal */}
               <View>
              <Modal animationType="slide"
               transparent={true}
              visible={ModalVisible_Gif}
              onRequestClose={() => {
              setModalVisible_Gif(!ModalVisible_Gif);}} >
              <View style={styles.GIF_modal}>
              <Image style={styles.GIF_Images} source={require("./Icon/neighcoach_loader.gif")}></Image>
              </View>
              </Modal>
              </View>
 {/* --------------------------------------------------------------------------------------- modaL ------------------------------------------------------------------------------------- */}
              <View>
              <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible1}
              onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible1(!modalVisible1); }}>
              <View style={styles.language_modal}>
              <View style={styles.modalHeader}>
              <Text style={styles.ChooseLanguageText}>Choose your language</Text>
              </View>
              <View style={styles.languageDataStyle}>

                     <FlatList
                      data={languages}
                      numColumns={2}
                       renderItem={({ item ,index}) =>
                      <View style={{ paddingVertical: mobileW * 3 / 100, alignSelf: "center", }} >
                      <TouchableOpacity activeOpacity={0.8} onPress={() => setSelectedIndex1(item)} style={styles.languageText}>
                      <View style={{ width: mobileW * 22 / 100, alignSelf: "center",  }}>
                      <Text style={styles.lan_name}>{item.lan_name}</Text>
                      <Text style={{ color: Colors.black_color, fontSize: mobileW * 3 / 100 }}>{item.name}</Text>
                      </View>

                          {/* ================= Radio Button ================== */}

                      <TouchableOpacity activeOpacity={0.8}onPress={() => setSelectedIndex1(item)} style={[{ borderColor: item.toggle ? Colors.themecolor : Colors.gray },styles.redioButtonBorder]}>
                      <View  style={[{ backgroundColor: item.toggle ? Colors.themecolor : Colors.white_color, },styles.redioButtonbackground]}></View>
                      </TouchableOpacity>
                      </TouchableOpacity>
                      </View>} />
                  <TouchableOpacity onPress={() => setModalVisible1(!modalVisible1)} style={styles.modaldone_txt}>
                  <Text style={styles.Done_text}>{Lang_chg.DoneTxt[config.language]}</Text>
                    </TouchableOpacity>
                    </View>
                    </View>
                    </Modal>
                    </View>
           {/* ================== MODEL ==================== */}
            <View style={styles.Top_view}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()}>
            <Image style={styles.backIcon} resizeMode='contain' source={require("./Icon/bk.png")}></Image>
            </TouchableOpacity>
            <Image style={styles.mavenowLogo} resizeMode='contain' source={require("./Icon/new_logo_mavenow.png")}></Image>
            <View style={{ alignItems: 'center',}}>
            <Text style={styles.loginText}>{Lang_chg.SignUPTxt[config.language]}</Text>
            </View>
            </View>
            <View style={styles.cardView}>
            <View>

             <Text style={styles.topText}>{Lang_chg.SwitchProfileTxt[config.language]}</Text>

            </View>

            {/*======================= Radio buton ====================== */}
                <View style={styles.maven_view}>
                <TouchableOpacity activeOpacity={0.8} onPress={() => SetSelect('Maven')}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                <View style={[styles.RadioBtn, { borderColor: select === 'Maven' ? Colors.themecolor : Colors.themecolor }]}>
                 <View style={{width: mobileW * 3 / 100, height: mobileW * 3 / 100, backgroundColor: select === 'Maven' ? Colors.themecolor : Colors.white_color,borderRadius: mobileW * 10 / 100,}}>
                </View>
                </View>
                {/* <Text style={styles.maven_txt}>Maven</Text> */}
                <Text style={styles.maven_txt}>{Lang_chg.MavenTxt[config.language]}</Text>
                </View>
                </TouchableOpacity>
                <TouchableOpacity activeOpacity={0.8} onPress={() => SetSelect('Learner')}>
                <View style={styles.learner_view}>
                <View style={[styles.RadioBtn, { borderColor: select === 'Learner' ? Colors.themecolor : Colors.themecolor }]}>
                <View style={{ width: mobileW * 3 / 100, height: mobileW * 3 / 100, backgroundColor: select === 'Learner' ? Colors.themecolor : Colors.white_color, borderRadius: mobileW * 10 / 100 }}>
                </View>
                </View>
               {/* <Text style={styles.Learner_text}>Learner</Text> */}
               <Text style={styles.maven_txt}>{Lang_chg.LearnerTxt[config.language]}</Text>
               </View>
               </TouchableOpacity>
                </View>

              {select === 'Learner' ?
              <Text style={styles.RadioBtn_txt}>{Lang_chg.LearnerGuidanceTxt[config.language]}</Text> :
              <Text style={styles.RadioBtn_txt}>{Lang_chg.MentorGuideTxt[config.language]}</Text>
              }

               <View style={styles.textinput_view}>


              <TextInput

             onChangeText={(txt) => setFullname(txt)}   
       color={fullname==""? Colors.red:Colors.themecolor}label={Lang_chg.FullName[config.language]} variant="outlined"
       trailing={props =>(<Text></Text>)}/>
               </View>
               <View style={styles.textinput_view}>
               <TextInput color={email==""? Colors.redColor:Colors.themecolor}
                // onChangeText={(newEmail) => { setEmail(newEmail) }}label="Email*" variant="outlined"
                onChangeText={(newEmail) => { setEmail(newEmail) }}label={Lang_chg.Email[config.language]}  variant="outlined"
                 trailing={props => (<Text></Text>)}/>
               </View>
              {/* ================== Phone ====================== */}
            <PhoneInput
              ref={phoneInput}
              defaultCode="IN"
              layout="first"
              withShadow
              containerStyle={styles.containerstyle}
              textContainerStyle={{ paddingVertical: 0, paddingHorizontal: 0,  backgroundColor: Colors.white_color,  borderRadius: mobileW * 1 / 100,}} onChangeText={(text) => {
              setValue(text); }}
              onChangeFormattedText={(text) => {
              setFormattedValue(text);
               setCountryCode(phoneInput.current?.getCountryCode() ||'');}}/>
           
              <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible1(true)}style={{ marginTop: mobileW * 2 / 100 }}>
              <TextInput value={language}  placeholderTextColor={"black"} onChangeText={(newEmail) => { setlanguage(newEmail) }}

               editable={false} placeholder={Lang_chg.ChooselanguageTxt[config.language]}   variant="outlined" trailing={props => (<Text></Text>)} />

               </TouchableOpacity>
               <View style={{ flexDirection: 'row', marginTop: mobileW * 5 / 100, alignItems: "center" }}>
               <TouchableOpacity onPress={() => setShouldShow(!shouldShow)}>
               {shouldShow ? (                                                                                
               <Image style={styles.right_image} source={require("./Icon/right.png")}></Image>) :
               <Image style={styles.square_image} source={require("./Icon/square.png")}></Image>}
               </TouchableOpacity>
               <View style={styles.Terms_VIEW}>
              
               <Text style={styles.agreed_txt}>{Lang_chg.IagreedtoTxt[config.language]}</Text>
               <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('Terms')}>
               {/* <Text style={styles.Terms_TExt}>Terms and Conditions</Text> */}
               <Text style={styles.Terms_TExt}>{Lang_chg.TermsandConditions[config.language]}</Text>
               </TouchableOpacity>
               </View>
               </View>
               <TouchableOpacity activeOpacity={0.8} onPress={() => _loginBtn()} style={styles.LoginView}>
               <Text style={styles.signup_txt}>{Lang_chg.SIGNUPbtnTxt[config.language]}</Text>
               </TouchableOpacity>
               </View>
               </ScrollView>
               </SafeAreaView>
              </View>
              )}
export default Msignup
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  backIcon: {
    width: mobileW * 10/ 100,
    height: mobileW * 10 / 100,
    tintColor: Colors.white_color
  },
  learner_view: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: mobileW * 5 / 100
  },
  lan_name: {
    color: Colors.black_color,
    fontSize: mobileW * 4 / 100,
  },
  mavenowLogo: {
    width: mobileW * 70 / 100,
    height: mobileW * 18 / 100,
    alignSelf: 'center',
    marginTop:mobileW*-5/100
  },

  loginText: {
    fontSize: mobileW * 4.5 / 100,
    color: Colors.black_color,
    fontWeight: '500',
    marginTop: mobileW * 1 / 100
  },
  maven_view: {
    flexDirection: "row",
    marginTop: mobileW * 5 / 100,
    alignItems: "center"
  },
  cardView: {
    width: mobileW,
    height: mobileH * 85 / 100,
    backgroundColor: Colors.whiteColor,
    padding: mobileW * 7.5 / 100,
    borderTopLeftRadius: mobileW * 10 / 100
  },
  topText: {
    fontSize: mobileW * 3.4/ 100,
    color: Colors.black_color,
fontFamily:Font.FontSemiBold
  },
  RadioBtn: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    borderRadius: mobileW * 10 / 100,
    borderWidth: mobileW * 0.40 / 100,
    justifyContent: 'center',
    alignItems: "center"
  },
  phoneView: {
    justifyContent: 'center',
    height: mobileW * 13 / 100,
    backgroundColor: Colors.white_color,
    borderRadius: mobileW * 3 / 100,
    marginTop: mobileW * 10 / 100,
    elevation: 1,
    shadowColor: '#000',
    borderColor: Colors.gray,
    borderWidth: mobileW * 0.55,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,
  },
  containerstyle: {
    width: mobileW * 85 / 100,
    height: mobileW * 15 / 100,
    backgroundColor: Colors.white_color ,
    marginTop: mobileW * 2 / 100,
    borderRadius: mobileW * 1 / 100,
    elevation: 1,
    shadowColor: '#000',
    borderColor: Colors.gray,
    borderWidth: 0.80,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,
  },
  language_modal: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#00000096'
  },
  LoginView: {
    justifyContent: 'center',
    alignItems: 'center',
    height: mobileW * 13 / 100,
    backgroundColor: Colors.themecolor,
    borderRadius: mobileW * 3 / 100,
    marginTop: mobileW * 10 / 100,
    elevation: 1,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    // borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,

  },
  GIF_modal: {
    flex: 1,
    backgroundColor: '#00000090',
    justifyContent: 'center', alignItems: "center"
  },
  GIF_Images: {
    width: mobileW * 25 / 100,
    height: mobileW * 12 / 100,
    alignSelf: "center"
  },
  redioButtonBorder: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    borderRadius: mobileW * 5 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: mobileW * 0.40 / 100,
    // marginTop: mobileW * 5 / 100,
    // margin: mobileW * 2 / 100
  },
  redioButtonbackground: {
    width: mobileW * 3 / 100,
    height: mobileW * 3 / 100,
    borderRadius: mobileW * 5 / 100,
  },
  modalHeader: {
    backgroundColor: Colors.themecolor,
    width: mobileW * 85 / 100,
    height: mobileW * 12 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    justifyContent: 'center'
  },
  ChooseLanguageText: {
    alignSelf: 'center',
    color: Colors.whiteColor,
    fontSize: mobileW * 3.5 / 100,
    fontWeight: '500'
  },
  languageDataStyle: {
    backgroundColor: Colors.white_color,
    width: mobileW * 85 / 100,
    // height: mobileH * 53/ 100,
    elevation: mobileW * 2 / 100,
    paddingHorizontal:mobileW*3/100,
    paddingBottom:mobileW*2/100,
    // padding: mobileW * 3 / 100,
    borderBottomRightRadius: mobileW * 2 / 100,
    borderBottomLeftRadius: mobileW * 2 / 100
  },
  languageText: {
    backgroundColor: Colors.whiteColor,
    padding:mobileW*3/100,
    flexDirection: "row",
    borderRadius: mobileW * 1 / 100,
    marginHorizontal: mobileW * 2.3 / 100,
    alignItems:'center',
    width: mobileW * 35 / 100,
    justifyContent: "space-between",
    height: mobileW * 18 / 100,
    borderWidth: mobileW * 0.24 / 100,
    borderColor: Colors.gray,
    elevation: mobileW * 0.45 / 100
  },
  maven_txt: { 
    marginHorizontal: mobileW * 2 / 100, 
    color: Colors.black_color 
  },
  RadioBtn_txt: { 
    fontSize: mobileW * 2.8 / 100, 
    marginTop: mobileW * 3 / 100, 
    color: Colors.gray
  },
  signup_txt: { 
    fontSize: mobileW * 4 / 100, 
    color: Colors.white_color,
    fontFamily:Font.FontMedium 
 
  },
  Terms_TExt: {
    color: Colors.themecolor,
    fontSize: mobileW * 2.9 / 100,
    marginTop: mobileW * 0.8 / 100,
    textDecorationLine: "underline",
    fontFamily:Font.FontMedium
  },
  square_image: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    tintColor: Colors.gray,
    borderWidth: mobileW * 0.5 / 100,
    borderColor: Colors.gray,
    borderRadius: mobileW * 0.8 / 100
  },
  Top_view: { 
    width: mobileW, 
    height: mobileH * 20 / 100, 
    padding: mobileW * 3 / 100, 
  },
  Terms_VIEW: { 
    flexDirection: 'row', 
    marginHorizontal: mobileW * 2 / 100, 
    alignItems: "center" 
  },
  agreed_txt: { 
    fontSize: mobileW * 2.8 / 100, 
    color: Colors.gray 
  },
  Done_text: {
    alignSelf: "center",
    color: Colors.white_color,
    fontSize: mobileW * 4.5 / 100,
    fontWeight:'500'
  },
  right_image: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    backgroundColor: Colors.themecolor,
    alignSelf: 'center',
    tintColor: Colors.white_color,
    borderRadius: mobileW * 1 / 100
  },
  textinput_view: { 
    marginTop: mobileW * 2 / 100, 
 
  },
  Learner_text: { 
    marginHorizontal: mobileW * 2 / 100, 
    color: Colors.black_color 
  },
  modaldone_txt: {
    backgroundColor: Colors.themecolor,
    width: mobileW * 78 / 100,
    height: mobileW * 11 / 100,
    borderRadius: mobileW * 1 / 100,
    alignSelf: "center",
    justifyContent: "center",
  },
  SafeAreaView: { 
    flex: 0, 
    backgroundColor: Colors.themecolor 
  }
})




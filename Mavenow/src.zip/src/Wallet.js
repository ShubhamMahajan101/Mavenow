
import {Modal,Alert,ScrollView, TextInput,StatusBar,Animated,FlatList, View, Text,Dimensions,TouchableOpacity,Image, StyleSheet,RefreshControl} from 'react-native'
import React,{useState, useEffect} from 'react';
import { Colors, Font } from './Provider/Colorsfont';
import { SafeAreaView } from 'react-native-safe-area-context';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';

import moment from 'moment';
import LearnerList from './LearnerList';
import axios from 'axios';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;
// const DATA_top = [
//   {
//     id: 1,
   
//     name_Available:'Total Available Balance',

 
//     price_Available:'  Rs 500',
//     name_Withdrawable:"Total Withdrawable Amount",
//     price_Withdrawable:'   Rs 5000',
//     PaymentProcess:"Withdraw Payment is progress"
    
//   },
// ]

  

export default function Wallet({navigation}) {
  const [checked, setChecked] = useState('Current')
  const [show, setShow] = useState('Add')
  const [number, onChangeNumber] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const [ complete, setComplete] = useState([]);
  const [ active, setActive] = useState([]);
  const [ history, setHistory] = useState([]);
  const [topdata, setTopdata] = useState({});
  const [refresh, setrefresh] = useState(false)

  // -------------------------- refresh --------------------
  const _onRefresh = async () => {
    console.log('_onRefresh', '_onRefresh')
    setrefresh(true)
    setTimeout(() => {
      setrefresh(false)
    }, 1200);
  }
  // -----------------------refresh-------------------


  useEffect(() => {
    apiCalling();
  
  }, [])

  const apiCalling = () => {
    axios.get('https://mavenow.com:8001/wallet?id=848&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI', {
    
    })
        .then(function (data) {
          var GetData = data.data
          // console.log('jsdsssss',GetData);
        
          if(GetData.StatusCode== 200){
            var GetData1= GetData.result
            console.log("Header",GetData1);
            var DataToSet = GetData1.classes
            // console.log('All classes ==>', DataToSet);
            setTopdata(GetData1)
            setComplete(DataToSet.complete)
            setActive(DataToSet.current)
            setHistory(DataToSet.history)
            // console.log("Complete Data",DataToSet.complete );
            // console.log("Active Data",DataToSet.current );
            // console.log("History Data",DataToSet.history ); 

          }else{
            console.log("I am in nor found")
          }
          
          console.log("dfdfsfs",GetData);
         
        })
        .catch(function (error) {
          console.log('======>',error);
        });
  }


  return (
    <View style={{ flex: 1, }}>
    <SafeAreaView style={{ flex: 1, backgroundColor:Colors.white_color }}>
         <StatusBar barStyle = "light-content" hidden = {false} backgroundColor ={Colors.themecolor} />
         <View style={styles.Header}>
           <View style={{flexDirection:'row', alignItems:'center'}}>
  <TouchableOpacity activeOpacity={0.8} onPress={()=>navigation.goBack()} >
         <Image style={styles.backIcon} resizeMode='contain'
            source={require("./Icon/bk.png")}></Image>
        </TouchableOpacity>
        <Text style={{color:Colors.white_color,fontSize:mobileW*4.5/100,marginHorizontal:mobileW*3/100,fontFamily:Font.FontRegular}}>{Lang_chg.WalletTxt[config.language]}</Text>
        </View>
        

        <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)}   style={{marginRight:mobileW*2/100}} >
         <Image style={styles.SearchIcon} resizeMode='contain'
            source={require("./Icon/icon_info.png")}></Image>
        </TouchableOpacity>
</View>

{/* =================================================================Model================================================================ */}
<View  >
<Modal 
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={{flex:1, backgroundColor:'#00000096', justifyContent:'center'}}>
        <View style={{width:mobileW*90/100,borderRadius:mobileW*3/100, alignSelf:'center', backgroundColor:Colors.white_color,elevation:5}}>
          <View style={styles.ModalHeader}>
          <Text style={{color:Colors.white_color, fontSize:mobileW*5/100, fontWeight:'500'}}></Text>
          <Text style={{color:Colors.white_color, fontSize:mobileW*5/100, fontWeight:'500'}}>       Help : Wallet</Text>
          <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{marginRight:mobileW*5/100}} >
            <Image style={styles.backIcon_I} resizeMode='contain'
               source={require("./Icon/close2.png")}></Image>
           </TouchableOpacity>
          </View>
          <ScrollView>
          <View style={{alignItems:'center', padding:mobileW*3/100}}>
            
            <Text style={{color:Colors.gray,fontSize:mobileW*4/100,fontWeight:'500'}}>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
            when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
            It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
            It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
            and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

            </Text>
          </View>
          </ScrollView>
        </View>
        </View>
        </Modal>
</View>



<View style={{backgroundColor:Colors.light_cyan,margin:mobileW*1/100, borderRadius:mobileW*1/100}}>
 
<View style={{margin:mobileW*4/100, }}>
  <View style={{alignItems:'center', }}>
  <Text style={{fontSize:mobileW*4/100, color:Colors.themecolor, fontWeight:'500',}}>Rs {topdata.walletAmount}</Text>
    <Text style={{fontSize:mobileW*3/100, color:Colors.gray, marginTop:mobileW*1/100,fontFamily:Font.FontRegular}}>{Lang_chg.AvailableBalanceTxt[config.language]}</Text>
</View>

<View style={{flexDirection:'row', alignItems:'center',  }}>
<View style={{marginTop:mobileW*3/100,width:mobileW*43/100, }} >
  <Text style={{fontSize:mobileW*4/100, color:Colors.themecolor, fontWeight:'500',textAlign:'center'}}>Rs {topdata.retrievalAmount}</Text>
  <Text style={{fontSize:mobileW*3/100, marginTop:mobileW*1/100, color:Colors.gray,fontFamily:Font.FontRegular }}>{Lang_chg.withdrawableAmounTxt[config.language]}</Text>
</View>
<View style={{width:mobileW*47/100,}}>
  <Text style={{fontSize:mobileW*3/100, color:Colors.gray, textAlign:'center',fontFamily:Font.FontRegular}}>{Lang_chg.FundsprogressTxt[config.language]}</Text>
</View>
{/* <TouchableOpacity activeOpacity={0.8} style={styles.withdrawBtn} onPress={() =>navigation.navigate('QRScanner')}>
<Text style={{color:Colors.white_color,fontSize:mobileW*4/100, fontWeight:'500'}}>Withdraw</Text>
</TouchableOpacity> */}
</View>
</View>


</View>

          <View style={styles.buttonCard}>
            <TouchableOpacity activeOpacity={0.8}onPress={()=>setChecked('Current')}
              style={[{ backgroundColor: checked === 'Current' ? Colors.white_color : Colors.themecolor, }, styles.activeButton]}>
              <Text style={{ color: checked === 'Current' ? Colors.themecolor : Colors.white_color, fontSize: mobileW * 3 / 100, fontFamily:Font.FontSemiBold }}>{Lang_chg.ActiveTxt[config.language]}</Text>
            </TouchableOpacity >
            <TouchableOpacity activeOpacity={0.8} onPress={()=>setChecked('Old')}
              style={[{ backgroundColor: checked === 'Old' ? Colors.white_color : Colors.themecolor, }, styles.activeButton]}>
              <Text style={{ color: checked === 'Old' ? Colors.themecolor : Colors.white_color, fontSize: mobileW * 3/ 100, fontFamily:Font.FontSemiBold }}>{Lang_chg.CompletedTxt[config.language]}</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8} onPress={()=>setChecked('History')}
              style={[{ backgroundColor: checked === 'History' ? Colors.white_color : Colors.themecolor }, styles.activeButton]}>
              <Text style={{ color: checked === 'History' ? Colors.themecolor : Colors.white_color, fontSize: mobileW * 3/ 100, fontFamily:Font.FontSemiBold }}>{Lang_chg.HistoryTxt[config.language]}</Text>
            </TouchableOpacity>
          </View>


{/* =====================================       active dataa  */}

{checked == 'Current' &&
<ScrollView
          refreshControl={
            <RefreshControl
              refreshing={refresh}
              onRefresh={_onRefresh}
              tintColor={Colors.themecolor}
              colors={[Colors.themecolor]}/>}>
 {active!=""?
<View>
<FlatList
            data={active}
            renderItem={({ item, index }) =>
            <View  style={styles.flatlistCard}>
            <TouchableOpacity activeOpacity={0.8} onPress={() =>navigation.navigate('LearnerList')} style={{ flexDirection:'row',  }}>
              <View style={{width:mobileW*31/100,alignItems:'center',padding:mobileW*2/100, }}>
                <View style={styles.imageCard}>
              <Image resizeMode='contain' style={styles.mavenImage}
                  source={item.teacherImage}></Image>
                  </View>
                  <Text  style={{fontSize:mobileW*3.5/100, color:Colors.black_color, marginTop:mobileW*1/100, fontWeight:'400'}}>{item.teacherName} </Text>
                <Text  style={{fontSize:mobileW*3.7/100, color:Colors.black_color,fontWeight:'400'}}>{Lang_chg.MavenTxt[config.language]}</Text>
                <View style={{flexDirection:'row', marginTop:mobileW*1/100}}>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
            </View>
              </View>
              <View>
              <Text style={{ color:Colors.black_color, fontWeight:'500', fontSize:mobileW*3.5/100}}>{item.Skills}</Text>
              <View style={{flexDirection:'row',}}>
                
              <View style={{width:mobileW*31/100,}}>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Start Date</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item. StartDate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>End Date</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>All Student</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{item.AllStudentCount}</Text>
                </View>
              </View>
              <View style={{width:mobileW*31/100,}}>
              <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Charges</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.themecolor}}>Rs {item.Charges}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Your Earning*</Text>
                <Text style={{fontSize:mobileW*4/100, color:Colors.themecolor,fontWeight:'500'}}>Rs {item.earningAmount}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Paid Students</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,}}>{item.PaidStudentCount}</Text>
                </View>
              </View>
              </View>
              </View>
             
            </TouchableOpacity>
           
            </View> 
              }
              keyExtractor={item => item.id}/>
</View>
:
<Text style={{fontSize:mobileW*4/100,color:Colors.black_color,alignSelf:"center",marginTop:mobileH*30/100}}>Data Not found</Text>
}
</ScrollView>
}

{/* /////////////////////////////////////                        Complete data  */}


{checked == 'Old' &&
<ScrollView>
  {complete!=""?
<View>
<FlatList
            data={complete}
            renderItem={({ item, index }) =>
            <View  style={styles.flatlistCard}>
            <TouchableOpacity activeOpacity={0.8} onPress={() =>navigation.navigate('LearnerList',{item:item})} style={{ flexDirection:'row',  }}>
              <View style={{width:mobileW*31/100,alignItems:'center',padding:mobileW*2/100, }}>
                <View style={styles.imageCard}>
              <Image resizeMode='contain' style={styles.mavenImage}
                  source={item.teacherImage}></Image>
                  </View>
                  <Text  style={{fontSize:mobileW*3.5/100, color:Colors.black_color, marginTop:mobileW*1/100, fontWeight:'400'}}>{item.teacherName} </Text>
                <Text  style={{fontSize:mobileW*3.7/100, color:Colors.black_color,fontWeight:'400'}}>{Lang_chg.MavenTxt[config.language]}</Text>
                  <Text  style={{fontSize:mobileW*3.2/100, color:Colors.black_color, marginTop:mobileW*1/100,fontFamily:Font.FontRegular}}>{item.teacherName} </Text>
                <Text  style={{fontSize:mobileW*3.2/100, color:Colors.black_color,fontFamily:Font.FontRegular}}>(Maven)</Text>
                <View style={{flexDirection:'row', marginTop:mobileW*1/100}}>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
            </View>
              </View>
              <View>
              <Text style={{ color:Colors.black_color, fontWeight:'400', fontSize:mobileW*3.3/100}}>{item.Skills}</Text>
              <View style={{flexDirection:'row',}}>
                
              <View style={{width:mobileW*31/100,}}>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.StartDateTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item. StartDate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.EndDateTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.AllStudentTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{item.AllStudentCount}</Text>
                </View>
              </View>
              <View style={{width:mobileW*31/100,}}>
              <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.ChargesTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.themecolor}}>Rs {item.Charges}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.YourEarningTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*4/100, color:Colors.themecolor,fontWeight:'500'}}>Rs {item.earningAmount}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>{Lang_chg.PaidStudentsTxt[config.language]}</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,}}>{item.PaidStudentCount}</Text>
                </View>
              </View>
              </View>
              </View>
             
            </TouchableOpacity>
           
            </View> 
              }
              keyExtractor={item => item.id}/>
</View>
:
<Text style={{fontSize:mobileW*4/100,color:Colors.black_color,alignSelf:"center",marginTop:mobileH*30/100}}>Data Not found</Text>
            }
</ScrollView>
}





{/* /////////////////////////////////////                        history  data  */}
{checked == 'History' &&
<ScrollView>
  {history!=""?
<View>
<FlatList
            data={history}
            renderItem={({ item, index }) =>
            <View  style={styles.flatlistCard}>
            <TouchableOpacity activeOpacity={0.8} onPress={() =>navigation.navigate('LearnerList')} style={{ flexDirection:'row',  }}>
              <View style={{width:mobileW*31/100,alignItems:'center',padding:mobileW*2/100, }}>
                <View style={styles.imageCard}>
              <Image resizeMode='contain' style={styles.mavenImage}
                  source={item.teacherImage}></Image>
                  </View>
                  <Text  style={{fontSize:mobileW*3.5/100, color:Colors.black_color, marginTop:mobileW*1/100, fontWeight:'400'}}>{item.teacherName} </Text>
                <Text  style={{fontSize:mobileW*3.7/100, color:Colors.black_color,fontWeight:'400'}}>(Maven)</Text>
                <View style={{flexDirection:'row', marginTop:mobileW*1/100}}>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
                  <TouchableOpacity activeOpacity={0.8}>
                <Image resizeMode='contain' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.light_grey}}
                  source={require('./Icon/star.png')}></Image>
                  </TouchableOpacity>
            </View>
              </View>
              <View>
              <Text style={{ color:Colors.black_color, fontWeight:'500', fontSize:mobileW*3.5/100}}>{item.Skills}</Text>
              <View style={{flexDirection:'row',}}>
                
              <View style={{width:mobileW*31/100,}}>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Start Date</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>End Date</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>All Student</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color}}>{item.AllStudentCount}</Text>
                </View>
              </View>
              <View style={{width:mobileW*31/100,}}>
              <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Charges</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.themecolor}}>Rs {item.Charges}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Your Earning*</Text>
                <Text style={{fontSize:mobileW*4/100, color:Colors.themecolor,fontWeight:'500'}}>Rs {item.earningAmount}</Text>
                </View>
                <View style={{marginTop:mobileW*2/100}} >
                <Text style={{fontSize:mobileW*3/100, color:Colors.gray}}>Paid Students</Text>
                <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,}}>{item.PaidStudentCount}</Text>
                </View>
              </View>
              </View>
              </View>
             
            </TouchableOpacity>
           
            </View> 
              }
              keyExtractor={item => item.id}/>
</View>
:
<Text style={{fontSize:mobileW*4/100,color:Colors.black_color,alignSelf:"center",marginTop:mobileH*30/100}}>Data Not found</Text>
}



</ScrollView>
}
{/* /////////////////////////////////////                        history  data  */}



</SafeAreaView>
</View>
  )
}
const styles = StyleSheet.create({
    container: {
  flex:1,
  // backgroundColor:"red"
    },
    Header:{
      backgroundColor:Colors.themecolor, 
      width:mobileW, height:mobileW*13/100, 
      flexDirection:'row', 
      alignItems:'center',
      justifyContent:'space-between'
    },
    backIcon:{ 
      width: mobileW * 10 / 100, 
      height: mobileW * 10 / 100, 
      tintColor: Colors.white_color ,
      marginHorizontal:mobileW*3/100
    },
    backIcon_I:{ 
      width: mobileW * 7 / 100, 
      height: mobileW * 7 / 100, 
      tintColor: Colors.white_color 
    },
 
      flatlistCard:{ 
        width:mobileW*98/100,
        alignSelf:'center',
        marginTop:mobileW*3/100, 
        borderRadius:mobileW*1/100, 
        backgroundColor:Colors.white_color,
        padding:mobileW*2/100,
      shadowColor: '#000',
      borderColor:"#e8edfb",
      borderWidth:1,
      shadowOpacity: 0.1,
      shadowOffset: { width: 0, },
     // shadowColor: '#000',
      shadowOpacity: 0.1,
      },
      withdrawBtn:{ 
        backgroundColor:Colors.themecolor,
        width:mobileW*26/100,
        height:mobileW*8/100,
        borderRadius:mobileW*2/100,
        marginHorizontal:mobileW*5/100,
        justifyContent:'center',
        alignItems:'center'
      },
      imageCard:{
        width:mobileW*18/100,
        height:mobileW*18/100,
        borderRadius:mobileW*10/100,
        borderWidth:mobileW*0.4/100,
        borderColor:Colors.themecolor, 
        alignItems:'center',
        justifyContent:'center'
      },
      mavenImage:{
        width:mobileW*15/100,
        height:mobileW*15/100,
        borderRadius:mobileW*5/100, 
        tintColor:Colors.themecolor
      },
      flatlistFootar:{
        backgroundColor:Colors.themecolor,
        borderBottomRightRadius:mobileW*2/100,
        borderBottomLeftRadius:mobileW*2/100,
        flexDirection:"row",
        justifyContent:"space-between",elevation:mobileW*0/100,marginTop:mobileW*2/100,height:mobileW*7/100
    
       

      },
      SearchIcon:{
        width:mobileW*6/100,height:mobileW*6/100,tintColor:Colors.white_color

      },
      buttonCard: {
        flexDirection: 'row',
        backgroundColor: Colors.themecolor,
        width:mobileW*100/100,
        height:mobileW*12.5/100,
        justifyContent:'center',
        alignItems:'flex-end',
        // backgroundColor:'red',
        // elevation: 1,
        // shadowColor: '#000',
        // borderColor: "#e8edfb",
        // borderWidth: 1,
        // shadowOpacity: 0.1,
        // shadowOffset: { width: 0, },
        // // shadowColor: '#000',
        // shadowOpacity: 0.1,

    
      },
      activeButton: {
        
        width: mobileW * 32 / 100,
        height: mobileW * 10 / 100,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopLeftRadius: mobileW * 2 / 100,
        borderTopRightRadius: mobileW * 2 / 100,


      },
      ModalHeader:{
        width:mobileW*90/100,
        justifyContent:'space-between',
        flexDirection:'row', 
        alignItems:'center', 
        height:mobileW*12/100,
        borderTopLeftRadius:mobileW*2/100, 
        borderTopRightRadius:mobileW*2/100, 
        backgroundColor:Colors.themecolor
      },
})
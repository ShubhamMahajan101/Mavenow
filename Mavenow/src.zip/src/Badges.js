import { View, ScrollView, StatusBar, Modal, Alert, FlatList, Text, StyleSheet, Dimensions, TouchableOpacity, Image } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Colors, Font } from './Provider/Colorsfont';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import axios from 'axios';
import { SafeAreaView } from 'react-native-safe-area-context'
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;


const userList1 = [
  {
    id: 1,
    image: require('./Icon/icon_student.png'),
    name: 'dixit',
    title: 'hello',
    date: '2022-06-01',
    isEnabled:false
  },
  {
    id: 2,
    image: require('./Icon/icon_student.png'),
    name: 'pritesh',
    title: 'hello',
    date: '20-07-2022',
    isEnabled:true
  },
  
]

export default function Badges({ navigation }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [badge, setBadges] = useState([]);

  useEffect(() => {
    apiCalling();
    // recommendedApi();
  }, [])

  const apiCalling = () => {
    axios.get('https://mavenow.com:8001/bedges?type=1&token=6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI', {
      
    })
        .then(function (data) {
          var GetData = data.data.result
          console.log("data=========",GetData);
          setBadges(GetData)
          // var ErrorMessage = data.data.ErrorMessage   https://mavenow.com:8001/badges/848
          // console.log("all data",ErrorMessage)
          // console.log('Current Data ==>',GetData.current);
          // console.log('Old Data ==>',GetData.old);
          // setCurrentData(GetData.current)
          // setOldData(GetData.old)
         
          // if(ErrorMessage=="successfuly") {
          //   setResult(GetData)
          //   // navigation.navigate('Home')
          //   // navigation.navigate('Testing')
          //   console.log('=============>',result.old);
          // }else{
    
          // }
    
        })
        .catch(function (error) {
          console.log('======>',error);
        });
  }
  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.Header}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} style={{ marginHorizontal: mobileW * 2 / 100 }} onPress={() => navigation.goBack()}>
        <Image style={styles.backIcon_} resizeMode='contain'source={require("./Icon/bk.png")}></Image>
        </TouchableOpacity>
        <Text style={styles.BadgesText}>{Lang_chg.BadgesTxt[config.language]}</Text>
        </View>
        <TouchableOpacity activeOpacity={0.8}  style={{ marginRight: mobileW * 2 / 100 }} onPress={() => setModalVisible(true)} >
         <Image style={{width:mobileW*6.3/100, height:mobileW*6.3/100, tintColor:Colors.white_color, marginRight:mobileW*2/100}} resizeMode='contain'source={require("./Icon/icon_info.png")}></Image>
        </TouchableOpacity>
        </View>
            {/* ++++++++++++++++++++++++++++++++++++++ Header close ++++++++++++++++++++++++++++++++++++++++ */}

              {/* .........................................................model................................................... */}
              <View>
            <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible(!modalVisible);
            }}>
                <View style={{ flex: 1, backgroundColor: '#00000090', justifyContent:'center', alignItems:'center' }}>
                <View style={styles.Modal}>
                <View style={styles.ModalHeader}>
                <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}></Text>
                 <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>    Help : Badges</Text>
                 <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                 <Image style={{width:mobileW*7/100, height:mobileW*7/100, tintColor:Colors.white_color, marginRight:mobileW*2/100}} resizeMode='contain'source={require("./Icon/close2.png")}></Image>
                 </TouchableOpacity>
                  </View>
                  <ScrollView>
                  <View style={{padding: mobileW * 3 / 100,flexDirection:"row" }}>

                    <Text style={{ color: Colors.blackColor, fontSize: mobileW * 4 / 100,  }}>
                      Badges :
                      </Text>
                      <Text    style={{color:Colors.blackColor,fontSize:mobileW*4/100,width:mobileW*70/100}}> Under the Badges section,you  can view the list of all the 
                      badges that you  have entered</Text>
          </View>
          </ScrollView>
          </View>
          </View>
          </Modal>
          </View>

          
        {/* .........................................................model................................................... */}
        {/* ==============================================================Flatlist================================================================= */}
                 <ScrollView >
                  <FlatList
                   data={userList1}
                    renderItem={({ item, index }) =>
                   <View>
                    <TouchableOpacity activeOpacity={0.8} style={styles.CardView}>
                    <View style={{ width: mobileW * 30 / 100, alignItems: 'center', justifyContent: 'center', }}>
                     <Image resizeMode='contain' style={{ width: mobileW * 30 / 100, height: mobileW * 20 / 100 }}
                      // source={{ uri:item.BedgeIconFileNameFull}}
                      source={require('./Icon/galley_placeholder.png')}
                      >

                      </Image>
                     </View>
                     <View style={{ width: mobileW * 70 / 100, padding: mobileW * 2 / 100 }}>
                     {/* <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color, fontWeight: '500' }}>{item.BedgeName}</Text> */}
                     <Text style={{ fontSize: mobileW * 3.7 / 100, color: Colors.black_color, fontWeight: '500',  }}>ABC</Text>
                      {/* <Text style={styles.description}>{item.Description}</Text> */}
                      <Text style={styles.description}>get silver badge on complete success teaching class</Text>
                      {/* <Text style={styles.awardsText}>{item.awards}</Text> */}
                      <Text style={styles.awardsText}>Awarded on : 30, Dec 2022</Text>

                             </View>
                             </TouchableOpacity>
                            </View>
                              }
                              keyExtractor={item => item.id} />
                              {/* ======================================= =======================Flatlist================================================================= */}
                            </ScrollView>
                             </SafeAreaView> 
                             </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, 
    height: mobileW * 13 / 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },

  CardView:{ 
    backgroundColor: Colors.light_cyan, 
    padding: mobileW * 2 / 100, 
    width: mobileW * 98 / 100, 
    margin: mobileW * 1 / 100, 
    borderRadius:mobileW*2/100,
    flexDirection: 'row', 
    alignItems: 'center' ,
    elevation: 2,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
  },
  BadgesText:{ 
    color: Colors.white_color, 
    marginHorizontal: mobileW * 3/ 100, 
    fontSize: mobileW * 4.5/ 100 ,
    fontFamily:Font.FontMedium,marginTop:mobileW*0.2/100
  },
  description:{ 
    fontSize: mobileW * 3.2 / 100, 
    color: Colors.black_color, 
    fontWeight: "400", 
    width:mobileW*60/100,
    marginTop: mobileW * 2 / 100 
  },
  awardsText:{ 
    fontSize: mobileW * 3 / 100, 
    color: Colors.gray, 
    fontWeight: "400", 
    marginTop: mobileW * 2 / 100 
  },
  ModalHeader: {
    width: mobileW * 90 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 12 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  Modal: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 2 / 100,
    backgroundColor: Colors.white_color,
    elevation: 5
  },
  backIcon: {
    width: mobileW * 10/ 100,
    height: mobileW * 10 / 100,
    tintColor: Colors.white_color
  },
  backIcon_: {
    width: mobileW * 9.5 / 100,
    height: mobileW * 9.5 / 100,
    tintColor: Colors.white_color
  },
}
)
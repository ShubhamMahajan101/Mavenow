import { View, ScrollView, StatusBar, Modal, Alert, FlatList, Text, SafeAreaView, TextInput, StyleSheet, Dimensions, TouchableOpacity, Image, Keyboard } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Colors, } from './Provider/Colorsfont';
import axios from 'axios';
import { config, msgProvider, msgText, consolepro, Lang_chg, Font, localStorage, msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;


export default function Search({ navigation }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [search , setSearch] = useState([])
  const [Searchtext, setSearchtext] = useState('')

  console.log('search------',search);
  // useEffect(() => {
  //   apiCalling();
  //   // recommendedApi();
  // }, [])

  const apiCalling = () => {
    Keyboard.dismiss()
    axios.get('https://mavenow.com:8001/search/global?keyword='+Searchtext+'&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI&userType=1&lat=31.5491667&lng=-97.1463889&userId=848', {
    })
        .then(function (data) {
          var GetData = data.data.response
          console.log("data=========",GetData.masterList);
          var masterList =GetData.masterList
          setSearch(masterList)
        })
        .catch(function (error) {
          console.log('======>',error);
        });
  }

  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.Header}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity activeOpacity={0.8} style={{ marginHorizontal: mobileW * 2 / 100 }} onPress={() => navigation.goBack()}>
              <Image style={styles.backIcon_} resizeMode='contain'
                source={require("./Icon/bk.png")}></Image>
            </TouchableOpacity>
            <Text style={styles.searchText}>{Lang_chg.Search[config.language]}</Text>
          </View>
          <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginRight: mobileW * 2 / 100 }} >
            <Image style={styles.backIcon} resizeMode='contain'
              source={require("./Icon/icon_info.png")}></Image>
          </TouchableOpacity>
        </View>

        {/* ++++++++++++++++++++++++++++++++++++++ Search Bar ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.searchBarView}>
        <TextInput
          style={styles.input}
          onChangeText={text=>setSearchtext(text)}
          // value={search.detail}
          mode="outlined"
          placeholderTextColor={Colors.gray}
          fontSize={mobileW * 4 / 100}
          placeholder={Lang_chg.SearchMavenandSkills[config.language]}
          // placeholder="Search Maven and Skills"
        // keyboardType="numeric"
        />
        {Searchtext!=''&&
       <TouchableOpacity onPress={() =>apiCalling()} activeOpacity={0.8} style={{ marginRight: mobileW * 2 / 100 }} >
            <Image style={styles.SearchIcon} resizeMode='contain'
              source={require("./Icon/icon_search.png")}></Image>
          </TouchableOpacity>}
        </View>


        {/* =================================================================FlatList================================================================ */}

        <ScrollView >
        
          <FlatList
            data={search}
            renderItem={({ item, index }) =>
              <View>
                <TouchableOpacity activeOpacity={0.8} style={styles.Card} onPress={()=>navigation.navigate('LearnerRequestMaven', {item:item})}>
                  <View style={{ width: mobileW * 32 / 100, alignItems: 'center', padding: mobileW * 2 / 100,  }}>
                    <View style={styles.imageCard}>
                      <Image resizeMode='contain' style={{ width: mobileW * 15 / 100, height: mobileW * 15 / 100, borderRadius: mobileW * 10 / 100, }}
                        // source={item.image}></Image>
                        source={require('./Icon/icon_student.png')}></Image>
                    </View>
                    <Text style={{ fontSize: mobileW * 3.3 / 100, color: Colors.black_color, fontWeight: '500', textAlign:'center' }}>{item.userDetail.FullName}</Text>
                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray_dark, }}>{item.name}</Text>
                  </View>

                  <View style={{ width: mobileW * 32 / 100, padding: mobileW * 2 / 100 }}>
                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>Skills</Text>
                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{item.name}</Text>
                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>(Advance)</Text>
                  </View>
                  <View style={{ width: mobileW * 32 / 100, padding: mobileW * 3 / 100, alignItems: 'center' }}>
                    <View>
                      <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>Session</Text>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color, }}>5</Text>
                    </View>
                    <View style={{ marginTop: mobileW * 2 / 100, }}>
                      <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>followers</Text>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color, }}>500</Text>
                    </View>
                    <TouchableOpacity activeOpacity={0.8} style={styles.chatButton} onPress={()=>navigation.navigate('Chat')}>
                      <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>Chat</Text>
                    </TouchableOpacity>
                  </View>
                </TouchableOpacity>
              </View>
            }
            keyExtractor={item => item.id} />
        </ScrollView>



        {/* =================================================================Model================================================================ */}
        <View >
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible(!modalVisible);
            }}
          >
            <View style={{ flex: 1, backgroundColor: '#00000090', alignItems:'center', justifyContent:'center' }}>
              <View style={styles.ModelView}>
                <View style={styles.ModelHeader}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>Help : Search</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                    <Image style={styles.backIcon} resizeMode='contain'
                      source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                </View>
                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    <Text style={{ color: Colors.dark_gray, fontSize: mobileW * 3.5 / 100, fontWeight: '400' }}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

                    </Text>
                  </View>
                </ScrollView>
              </View>
            </View>
          </Modal>
        </View>
      </SafeAreaView>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 13 /100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  backIcon_: {
    width: mobileW * 9.5 / 100,
    height: mobileW * 9.5 / 100,
    tintColor: Colors.white_color
  },
  SearchIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.themecolor
  },
  searchText: {
    color: Colors.white_color,
    marginHorizontal: mobileW * 3 / 100,
    fontSize: mobileW * 4.5 / 100,
    fontFamily:Font.FontMedium
  },
  input: {
    width:mobileW*80/100,
    height: mobileW * 12 / 100,
    // paddingLeft: mobileW * 5 / 100,
    borderColor: Colors.themecolor,
    color:Colors.gray
  },
  searchBarView:{
    flexDirection:'row', 
    alignItems:'center', 
    backgroundColor:'white', 
    width:mobileW*96/100, 
    alignSelf:'center',borderWidth: 1,    
    borderColor: Colors.themecolor,
  justifyContent:'space-between',   
   borderRadius: mobileW * 1 / 100,
  margin:mobileW*2/100
},
  ModelView: {
    width: mobileW * 85 / 100,
    borderRadius: mobileW * 3 / 100,
    backgroundColor: Colors.white_color,
    elevation: 5,
  },
  ModelHeader: {
    width: mobileW * 85 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 12 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  Card: {
    backgroundColor: Colors.white_color,
    borderRadius: mobileW * 1 / 100,
    elevation: 1,
    width: mobileW * 98 / 100,
    margin: mobileW * 1 / 100,
    flexDirection: 'row',
  },
  imageCard: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    borderRadius: mobileW * 10 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.green,
    backgroundColor: Colors.white_color
  },
  chatButton: {
    width: mobileW * 25 / 100,
    borderRadius: mobileW * 1.5 / 100,
    marginTop: mobileW * 2 / 100,
    justifyContent: 'center',
    alignItems: 'center',
    height: mobileW * 7 / 100,
    backgroundColor: Colors.themecolor
  }
}
)

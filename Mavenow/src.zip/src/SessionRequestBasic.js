import { View, StatusBar, ScrollView, FlatList, Modal, Alert, Text, SafeAreaView, StyleSheet, Dimensions, TouchableOpacity, Image } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Colors, Font } from './Provider/Colorsfont';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Stack, TextInput, } from "@react-native-material/core";
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';

// import { flingHandlerName } from 'react-native-gesture-handler/lib/typescript/handlers/FlingGestureHandler';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;
import moment from 'moment';
import axios from 'axios';
import { Dropdown } from 'react-native-element-dropdown';


const data2 = [
    { label: '30', value: '1' },
    { label: '35', value: '2' },
    { label: '45', value: '3' },
];
//============================================Other Applicants==================================
const OtherApplicant = [
    {
        id: 1,
        image: require("./Icon/icon_maven.png"),
        name: 'Shubham Mahajan',
        paymentstatuss: 'Paid',
        startdate: 'Dec 15, 2022',
        enddate: 'Dec 18, 2022'
    },
];

const SessionRequestBasic = ({ navigation, route }) => {

    const [shouldShow, setShouldShow] = useState(0)
    const [modalVisible, setModalVisible] = useState(false);
    const [learnerList, setlearnerList] = useState([]);
    const [modalVisible_loadergif, setModalVisible_loadergif] = useState(false);


    const [firstname, setFirstname] = useState('');
    //Dite & Time Picker

    const [datePicker, setShow] = useState(false);
    const [timePicker, setTimePicker] = useState(false);
    const [date, setdate] = useState(Lang_chg.StartDateTxt[config.language]);
    const [time, setTime] = useState(Lang_chg.StartTimeTxt[config.language]);

    const [isFocus, setIsFocus] = useState(false);
    const [value, setValue] = useState('Dance');

    // const data = route.params.Active;
    const item = route.params.item;
    // console.log("Active Data-------", data)
    console.log("Active item========", item.Id)

    const setDatetoFunction = (date) => {
        setTimePicker(false)
        setTimeout(() => {
            console.log(timePicker);
        }, 500);

        var formateDate = date.nativeEvent.timestamp
        let newDate = moment(new Date(formateDate)).format('DD/MM/YYYY')
        setdate(newDate)
        console.log('date is here--------->>>>>>', newDate);
    }

    const setTimetoFunction = (given_time) => {
        console.log(given_time)
        setShow(false)
        var formateDate = given_time.nativeEvent.timestamp
        var hours = new Date(formateDate).getHours(); //Current Hours
        var min = new Date(formateDate).getMinutes(); //Current Minutes
        var sec = new Date(formateDate).getSeconds(); //Current Seconds

        var formattedDate = hours + ":" + min + ":" + sec
        setTime(formattedDate)
        console.log('Time is here===========', formattedDate);

    }
    const [change, setChange] = useState('Accept')
    const [reject, setReject] = useState('reject')
    const [request_DetailData, setrequestDetailData] = useState({})

    useEffect(() => {

        setTimeout(() => {
            setModalVisible_loadergif(false)
        }, 2000);

        ApiCalling();
    }, [])

    const ApiCalling = () => {
        setModalVisible_loadergif(true)
        axios.get('https://mavenow.com:8001/userrequest/Processing/discipleormaster/848/' + item.Id + '?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NzQ5NTc5Nn0.hp75g4O_N7R7MVkAyeWYiMlfglGAXP5Sl9pGohbPUYY', {

        })
            .then(function (data) {
                var GetData = data.data.result
                var requestDetailData = data.data.requestDetail
                //    setActived(GetData) 
                setrequestDetailData(requestDetailData)
                console.log('Completed API ========= >', GetData)
                console.log('Completed API Details ========= >', requestDetailData)
                setlearnerList(GetData)


                // if(StatusCode!=200) {
                //   setCompleted(GetData) 
                //   // navigation.navigate('Home')
                //   // navigation.navigate('Testing')
                //   console.log('Completed API ========= >',GetData)
                // }else{

                // }

            })
            .catch(function (error) {
                console.log('======>', error);
            });
    }

    return (
        <View style={{ flex: 1, }}>
            <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
                <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
                {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
                <View style={styles.Header}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <TouchableOpacity activeOpacity={0.8} style={{ marginHorizontal: mobileW * 3 / 100 }} onPress={() => navigation.goBack()}>
                            <Image style={styles.backIcon_} resizeMode='contain'
                                source={require("./Icon/bk.png")}></Image>
                        </TouchableOpacity>
                        <View style={{ width: mobileW * 71 / 100, }}>
                            <Text style={styles.HeaderText}>{item.TypeOfRequest == 'teaching' ? 'Session Request' : 'Learning Request'} - {request_DetailData.Skills} ({item.TypeOfRequest == 'teaching' ? request_DetailData.skill_level : request_DetailData.Skills})</Text>
                        </View>
                    </View>
                    <TouchableOpacity activeOpacity={0.8} style={{ marginRight: mobileW * 2 / 100 }} >
                        <Image style={styles.backIcon} resizeMode='contain'
                            source={require("./Icon/icon_info.png")}></Image>
                    </TouchableOpacity>
                </View>
                {/* ====================================================HEADER CLOSE============================================ */}
                <ScrollView >

                    <View style={styles.cardView}>
                        <View style={styles.cardHeader}>
                            <View style={{ width: mobileW * 20 / 100, borderTopLeftRadius: mobileW * 2 / 100, }}></View>
                            <View style={styles.cardHeaderr}>
                                <View style={{ width: mobileW * 50 / 100, justifyContent: 'space-between' }}>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{request_DetailData.FullName} {Lang_chg.MavenTxt[config.language]}</Text>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3 / 100, }}>{request_DetailData.Skills} ({item.TypeOfRequest == 'teaching' ? request_DetailData.skill_level : request_DetailData.Skills})</Text>
                                </View>
                                {/* <TouchableOpacity activeOpacity={0.8}>
                                    <Image resizeMode='contain' style={styles.shareicon}
                                        source={require('./Icon/share.png')}></Image>
                                </TouchableOpacity> */}
                            </View>

                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ width: mobileW * 21 / 100, }}>
                                <View style={styles.imageCard}>
                                    <Image style={styles.imageIcon} resizeMode='contain'
                                        source={require("./Icon/icon_maven.png")}
                                    ></Image>
                                </View>
                            </View>
                            <View>
                                <View style={{ flexDirection: 'row' }}>
                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.StartDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{moment(new Date(request_DetailData.StartDate)).format('MMM DD, YYYY')}</Text>
                                    </View>

                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.EndDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{moment(new Date(request_DetailData.Enddate)).format('MMM DD, YYYY')}</Text>
                                    </View>

                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}>{Lang_chg.DurationTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.gray }}>{request_DetailData.CourseDuration}</Text>
                                    </View>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.SessionTimeTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{request_DetailData.startduration} hours</Text>
                                    </View>

                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.SkillsTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.gray }}>{request_DetailData.Skills}</Text>
                                    </View>

                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.LevelTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{item.TypeOfRequest == 'teaching' ? request_DetailData.skill_level : request_DetailData.Skills}</Text>
                                    </View>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    {/* <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>Category</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{request_DetailData.SkillsCategory}</Text>
                                    </View> */}
                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.PostdateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{moment(new Date(request_DetailData.DateOfRequest)).format('MMM DD, YYYY')}</Text>
                                    </View>
                                    <View style={{ width: mobileW * 50 / 100, marginTop: mobileW * 2 / 100, }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>{Lang_chg.sessionincludesTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{request_DetailData.ShortDescription}</Text>
                                    </View>
                                </View>
                                {/* <View style={{ flexDirection: 'row' }}>
                                    <View style={{ width: mobileW * 25 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.4 / 100, color: Colors.black_color }}>Post date:</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>{moment(new Date(request_DetailData.DateOfRequest)).format('MMM DD, YYYY')}</Text>
                                    </View>
                                </View> */}
                            </View>
                        </View>
                        <View style={styles.cardfooter}>
                            <View style={{ flexDirection: "row", alignItems: 'center', justifyContent: "space-between", }}>
                                <View style={{ flexDirection: "row", }}>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, marginLeft: mobileW * 3 / 100 }}>{Lang_chg.FeeTxt[config.language]} {request_DetailData.Charges}</Text>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100 }}>rs</Text >
                                </View>
                                <View >
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, marginRight: mobileW * 2 / 100 }}>{Lang_chg.ApplyTillTxt[config.language]} {moment(new Date(request_DetailData.AppliedTill)).format('MMM DD, YYYY')}</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                    {/* -------------------------------------------- gif loader modal -------------------------- */}
                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modalVisible_loadergif}
                      >
                        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000096' }}>
                            <Image style={styles.GIF}
                                source={require("./Icon/neighcoach_loader.gif")}></Image>
                        </View>
                    </Modal>

                    {/* ============================================================== Learner's Flatlist================================================================= */}

                    {item.TypeOfRequest == 'teaching' ?
                        <View>
                            <Text style={styles.ListText}>{Lang_chg.LearnerListTxt[config.language]}</Text>
                            <FlatList
                                data={learnerList}
                                renderItem={({ item, index }) =>
                                    <View activeOpacity={0.8} style={styles.ListcardView}>
                                        <View style={styles.ListcardHeader}>
                                            <View style={{ width: mobileW * 20 / 100, borderTopLeftRadius: mobileW * 2 / 100, }}></View>
                                            <View style={{ width: mobileW * 76 / 100, borderTopRightRadius: mobileW * 2 / 100, justifyContent: 'center' }}>
                                                <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{item.FullName}</Text>
                                            </View>
                                        </View>
                                        <View style={{ flexDirection: 'row' }}>
                                            <View style={{ width: mobileW * 21 / 100, }}>
                                                <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('LearnersDetail', { item: item })} style={styles.listimageCard}>
                                                    <Image style={styles.imageIcon} resizeMode='contain'
                                                        source={item.profileImage == '' ? { uri: item.profileImage } : require("./Icon/icon_maven.png")}

                                                    ></Image>
                                                </TouchableOpacity>
                                            </View>
                                            <View>
                                                <View style={styles.listtextView}>
                                                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.PaymentStatusTxt[config.language]}</Text>
                                                    <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{item.isPaid == '0' ? 'Unpaid' : 'Paid'}</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                }
                                keyExtractor={item => item.id} />
                        </View>

                        :

                        <View>
                            <Text style={styles.ListText}>{Lang_chg.AppliedMavenTxt[config.language]}</Text>
                            {/* ============================================================== Applied Maven Flatlist================================================================= */}

                            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('AutomationTesting')} style={styles.ListcardView}>
                                <View style={styles.ListcardHeader}>
                                    <View style={{ width: mobileW * 21 / 100, borderTopLeftRadius: mobileW * 2 / 100, }}></View>
                                    <View style={{ width: mobileW * 71 / 100, borderTopRightRadius: mobileW * 2 / 100, justifyContent: 'center' }}>
                                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding:mobileW*1/100}}>
                                            <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{request_DetailData.FullName}</Text>

                                            {reject ? (
                                                <View>
                                                    {change ? (
                                                        <TouchableOpacity activeOpacity={0.8} onPress={() => setChange(!change)} style={styles.acceptedButton} >
                                                            <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: mobileW * 1 / 100 }}>
                                                                <Image resizeMode='contain' style={{ width: mobileW * 4 / 100, height: mobileW * 4 / 100, }}
                                                                    source={require('./Icon/icon_tick.png')}></Image>
                                                                <Text style={styles.AcceptText}>{Lang_chg.AcceptTxt[config.language]}</Text>
                                                            </View>
                                                        </TouchableOpacity>) : null
                                                    }
                                                </View>) : null}
                                        </View>
                                    </View>
                                </View>
                                <View style={{flexDirection: 'row'}}>
                                    <View style={{ width: mobileW * 21 / 100,}}>
                                        <View activeOpacity={0.8} style={styles.listimageCard}>
                                            <Image style={styles.imageIcon} resizeMode='contain'
                                                // source={item.image}
                                                source={item.image == '' ? '' : require("./Icon/icon_maven.png")}
                                                ></Image>
                                        </View>
                                    </View>
                                    <View>
                                        <View style={styles.requestDate}>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.PaymentStatusTxt[config.language]}</Text>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{request_DetailData.isPaid == '0' ? 'Unpaid' : 'Paid'}</Text>
                                        </View>
                                        <View style={styles.requestDate}>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.StartDateTxt[config.language]}</Text>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{moment(new Date(request_DetailData.StartDate)).format('MMM DD, YYYY')}</Text>
                                        </View>
                                        <View style={[styles.requestDate, { paddingBottom: mobileW * 3 / 100 }]}>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.EndDateTxt[config.language]}</Text>
                                            <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{moment(new Date(request_DetailData.Enddate)).format('MMM DD, YYYY')}</Text>
                                        </View>
                                        {reject ? (
                                            <View>
                                                {change ? (
                                                    <TouchableOpacity activeOpacity={0.8} onPress={() => setReject(!reject)} style={styles.RejectButton}>
                                                        <Text style={{ color: Colors.whiteColor, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.RejectTxt[config.language]}</Text>
                                                    </TouchableOpacity>) :
                                                    <TouchableOpacity activeOpacity={0.8} style={styles.AcceptedButton}>

                                                        <Text style={{ color: Colors.themecolor, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.AcceptedTxt[config.language]}</Text>
                                                    </TouchableOpacity>}
                                            </View>) : null}
                                    </View>
                                </View>
                            </TouchableOpacity>
                        </View>
                    }

                    {/* ============================================================== SCHEDULE SESSION ================================================================= */}
                    <View>
                        <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={styles.ScheduleHeader}>
                            <Text style={{ fontSize: mobileW * 3.5 / 100, fontWeight: '500', color: Colors.white_color }}>{Lang_chg.SCHEDULESESSIONTxt[config.language]}</Text>
                        </TouchableOpacity>
                        <Text style={styles.ListText}>{Lang_chg.OtherApplicantsTxt[config.language]}</Text>
                        <FlatList
                            data={OtherApplicant}
                            renderItem={({ item, index }) =>

                            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('AutomationTesting')} style={styles.ListcardView}>
                            <View style={styles.ListcardHeader}>
                                <View style={{ width: mobileW * 21 / 100, borderTopLeftRadius: mobileW * 2 / 100 }}></View>
                                <View style={{ width: mobileW * 71 / 100, borderTopRightRadius: mobileW * 2 / 100, justifyContent: 'center' }}>
                                    <View style={{  padding:mobileW*1/100}}>
                                        <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{item.name}</Text>

                                     
                                    </View>
                                </View>
                            </View>
                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ width: mobileW * 21 / 100 }}>
                                    <View activeOpacity={0.8} style={styles.listimageCard}>
                                        <Image style={styles.imageIcon} resizeMode='contain'
                                              source={item.image}></Image>
                                    </View>
                                </View>
                                <View>
                                    <View style={styles.requestDate}>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.PaymentStatusTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{item.paymentstatuss}</Text>
                                    </View>
                                    <View style={styles.requestDate}>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.StartDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{item.startdate}</Text>
                                    </View>
                                    <View style={[styles.requestDate, { paddingBottom: mobileW * 3 / 100 }]}>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{Lang_chg.EndDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, }}>{item.enddate}</Text>
                                    </View>
                                   
                                </View>
                            </View>
                        </TouchableOpacity>
                            }
                            keyExtractor={item => item.id} />
                    </View>
                </ScrollView>


                {/* ================================================================= Tiem Duration Model================================================================ */}
                <View  >
                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modalVisible}>
                        <View style={{ flex: 1, backgroundColor: '#00000090', justifyContent: 'center', alignItems: 'center' }}>
                            <View style={styles.ModelCard}>
                                <View style={styles.ModelHeader}>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>          {Lang_chg.CreateSessionTxt[config.language]}</Text>
                                    <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                                        <Image style={[styles.backIcon, { marginRight: mobileW * 2 / 100 }]} resizeMode='contain'
                                            source={require("./Icon/close2.png")}></Image>
                                    </TouchableOpacity>
                                </View>
                                <ScrollView>
                                    <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                                        <TextInput style={{ width: mobileW * 85 / 100, marginHorizontal: mobileW * 2 / 100 }}
                                            onChangeText={(firstname) => { setFirstname(firstname) }}
                                            color={Colors.themecolor} label={Lang_chg.ClassNameTxt[config.language]} variant="outlined" trailing={props => (<Text></Text>)} />

                                        {/* =================================================== Date / Time ================================================================ */}

                                        <View style={{ flexDirection: 'row' }}>
                                            {timePicker && (                                                                   //Date Picker
                                                <DateTimePicker
                                                    mode={'date'}
                                                    value={new Date(Date.now())}
                                                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                                    is24Hour={false}
                                                    onChange={text => setDatetoFunction(text)}
                                                />
                                            )}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setTimePicker(true)} style={styles.CalanderView}>
                                                <Image resizeMode='contain' style={styles.iconQuestionMark}
                                                    source={require('./Icon/icon_calendar.png')}></Image>
                                                <Text style={styles.calanderText}>{date}</Text>
                                            </TouchableOpacity>

                                            {datePicker && (                                                                   //Date Picker
                                                <DateTimePicker
                                                    mode={'time'}
                                                    value={new Date(Date.now())}
                                                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                                    is24Hour={false}
                                                    onChange={text => setTimetoFunction(text)}
                                                />
                                            )}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setShow(true)} style={styles.CalanderView}>
                                                <Image resizeMode='contain' style={styles.iconQuestionMark}
                                                    source={require('./Icon/icon_calendar.png')}></Image>
                                                <Text style={styles.calanderText}>{time}</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                    {/* {timePicker && (                                                                   //Date Picker
                                            <DateTimePicker
                                            mode={'date'}
                                            value={new Date(Date.now())}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={false}
                                            onChange={text=>setDatetoFunction(text)}
                                            />
                                        )} */}
                                    <Text style={styles.courseDurationText}>{Lang_chg.CourseDurationTxt[config.language]}</Text>

                                    <View >
                                        <Dropdown
                                            style={[styles.dropdown, isFocus && { borderColor: Colors.themecolor }]}
                                            placeholderStyle={styles.placeholderStyle}
                                            selectedTextStyle={styles.selectedTextStyle}
                                            inputSearchStyle={styles.inputSearchStyle}
                                            iconStyle={styles.iconStyle}
                                            data={data2}
                                            search
                                            Mode={"outlined"}
                                            maxHeight={300}
                                            labelField="label"
                                            valueField="value"
                                            placeholder={!isFocus ? 'Dance' : '...'}
                                            searchPlaceholder="Search..."
                                            value={value}
                                            onFocus={() => setIsFocus(true)}
                                            onBlur={() => setIsFocus(false)}
                                            onChange={item => {
                                                setValue(item.value);
                                                setIsFocus(false);
                                            }}

                                        />
                                    </View>
                                    <Text style={styles.learnerListText}>{Lang_chg.LearnerListTxt[config.language]}</Text>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: mobileW * 85 / 100, marginTop: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.gray, marginHorizontal: mobileW * 2 / 100, fontWeight: '500', }}>Maven</Text>
                                        <TouchableOpacity onPress={() => setShouldShow(!shouldShow)}>
                                            {shouldShow ? (
                                                <Image resizeMode='contain' style={{ width: mobileW * 5 / 100, tintColor: Colors.themecolor, height: mobileW * 5 / 100 }}
                                                    source={require('./Icon/check.png')}></Image>) :
                                                <Image resizeMode='contain' style={{ width: mobileW * 5 / 100, tintColor: Colors.themecolor, height: mobileW * 5 / 100 }}
                                                    source={require('./Icon/square.png')}></Image>}
                                        </TouchableOpacity>
                                    </View>
                                    <View style={styles.underline}></View>

                                    <View style={{ padding: mobileW * 1 / 100, marginBottom: mobileW * 5 / 100, flexDirection: 'row', marginTop: mobileW * 5 / 100 }}>
                                        <TouchableOpacity activeOpacity={0.8} style={styles.ModelButton} onPress={() => setShouldShow('shouldShow')}>
                                            <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{Lang_chg.SelectallTxt[config.language]}</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity onPress={() => setShouldShow()} activeOpacity={0.8} style={[styles.ModelButton,]}>
                                            <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{Lang_chg.DeselectTxt[config.language]}</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity activeOpacity={0.8} style={[styles.ModelButton,]} onPress={() => setModalVisible(!modalVisible)}>
                                            <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5 / 100, fontWeight: '500' }}>{Lang_chg.SubmitTxt[config.language]}</Text>
                                        </TouchableOpacity>
                                    </View>
                                </ScrollView>
                            </View>
                        </View>
                    </Modal>
                </View>
            </SafeAreaView>
        </View>
    )
}
export default SessionRequestBasic;

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    Header: {
        backgroundColor: Colors.themecolor,
        width: mobileW, height: mobileW * 13 / 100,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    backIcon: {
        width: mobileW * 6 / 100,
        height: mobileW * 6 / 100,
        tintColor: Colors.white_color
    },
    backIcon_: {
        width: mobileW * 9.5/ 100,
        height: mobileW * 9.5/ 100,
        tintColor: Colors.white_color
    },
    HeaderText: {
        color: Colors.white_color,
        marginHorizontal: mobileW * 0/ 100,
        fontSize: mobileW * 4 / 100,
        textAlign: "center",
        fontFamily:Font.FontMedium
    },
    input: {
        height: mobileW * 12 / 100,
        margin: mobileW * 2 / 100,
        borderRadius: mobileW * 1 / 100,
        borderWidth: 1,
        padding: mobileW * 2 / 100,
        borderColor: Colors.themecolor
    },
    cardView: {
        alignSelf: "center",
        margin: mobileW * 2 / 100,
        backgroundColor: Colors.white_color,
        // backgroundColor: 'green',
        elevation: 2,
        borderRadius: mobileW * 2 / 100
    },
    cardHeader: {
        backgroundColor: Colors.themecolor,
        flexDirection: 'row',
        width: mobileW * 96 / 100,
        // height: mobileW * 15 / 100,
        borderTopLeftRadius: mobileW * 2 / 100,
        borderTopRightRadius: mobileW * 2 / 100
    },
    cardHeaderr: {
        // width: mobileW * 76 / 100,
        flexDirection: 'row',
        borderTopRightRadius: mobileW * 2 / 100,
        padding: mobileW * 1 / 100,
        // alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: Colors.themecolor
    },
    shareicon: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        tintColor: Colors.white_color,
        marginRight: mobileW * 5 / 100,
    },
    ListcardView: {
        alignSelf: "center",
        margin: mobileW * 2 / 100,
        backgroundColor: Colors.white_color,
        elevation: 2,
        borderRadius: mobileW * 1 / 100
    },
    ListText: {
        marginLeft: mobileW * 5 / 100,
        fontSize: mobileW * 3.5 / 100,
        color: Colors.black_color,
        fontWeight: '500',
        marginBottom: mobileW * 2 / 100,
        marginTop: mobileW * 2 / 100
    },
    ListcardHeader: {
        backgroundColor: Colors.themecolor,
        flexDirection: 'row',
        width: mobileW * 96 / 100,
        height: mobileW * 12 / 100,
        borderTopLeftRadius: mobileW * 2 / 100,
        borderTopRightRadius: mobileW * 2 / 100,
        alignSelf: 'center',
    },
    acceptedButton: {
        flexDirection: 'row',
        borderRadius: mobileW * 1 / 100,
        width: mobileW * 22 / 100,
        height: mobileW * 8 / 100,
        backgroundColor: Colors.white_color,
        // marginTop:mobileW*2/100,
        // marginBottom:mobileW*2/100
    },
    RejectButton: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: mobileW * 1 / 100,
        width: mobileW * 22 / 100,
        height: mobileW * 8 / 100,
        backgroundColor: Colors.themecolor,
        marginBottom: mobileW * 2 / 100,
        alignSelf: 'flex-end',
        // marginRight: mobileW * 1 / 100
    },
    AcceptedButton: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: mobileW * 1 / 100,
        width: mobileW * 22 / 100,
        height: mobileW * 8 / 100,
        marginBottom: mobileW * 2 / 100,
        alignSelf: 'flex-end',
        // marginRight: mobileW * 1 / 100
    },
    imageCard: {
        width: mobileW * 15 / 100,
        height: mobileW * 15 / 100,
        borderRadius: mobileW * 8 / 100,
        marginTop: mobileW * -8 / 100,
        marginHorizontal: mobileW * 2 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.white_color,
        elevation: 5,
        shadowColor: '#000',
        borderColor: "#e8edfb",
        borderWidth: 1,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, },
        shadowOpacity: 0.1,
    },
    listimageCard: {
        width: mobileW * 15 / 100,
        height: mobileW * 15 / 100,
        borderRadius: mobileW * 8 / 100,
        marginTop: mobileW * -8 / 100,
        marginHorizontal: mobileW * 2 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.white_color,
        elevation: 1,
        shadowColor: '#000',
        borderColor: "#e8edfb",
        // borderWidth: 1,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, },
        shadowOpacity: 0.1,
    },
    imageIcon: {
        width: mobileW * 12 / 100,
        height: mobileW * 12 / 100,
        borderRadius: mobileW * 4 / 100,
        tintColor: Colors.themecolor,
        marginHorizontal: mobileW * 2 / 100
    },
    cardfooter: {
        width: mobileW * 96 / 100,
        height: mobileW * 10 / 100,
        marginTop: mobileW * 5 / 100,
        backgroundColor: Colors.themecolor,
        borderBottomEndRadius: mobileW * 2 / 100,
        borderBottomStartRadius: mobileW * 2 / 100,
        justifyContent: 'center',
        alignSelf: "center",
    },
    AcceptText: {
        color: Colors.themecolor,
        fontSize: mobileW * 4 / 100,
        fontWeight: '500',
        marginHorizontal: mobileW * 2 / 100
    },
    ScheduleHeader: {
        width: mobileW * 96 / 100,
        height: mobileW * 8 / 100,
        marginTop: mobileW * 2 / 100,
        backgroundColor: Colors.themecolor,
        borderRadius: mobileW * 2 / 100,
        alignSelf: "center",
        alignItems: 'center',
        justifyContent: 'center'
    },
    listtextView: {
        flexDirection: 'row',
        paddingBottom: mobileW * 8 / 100,
        marginTop: mobileW * 3 / 100,
        alignItems: 'center',
        justifyContent: 'space-between',
        width: mobileW * 71 / 100,
    },
    OtherApplicant: {
        flexDirection: 'row',
        paddingBottom: mobileW * 3 / 100,
        alignItems: 'center',
        justifyContent: 'space-between',
        width: mobileW * 71 / 100,
    },
    requestDate: {
        flexDirection: 'row',
        padding: mobileW * 1 / 100,
        alignItems: 'center',
        justifyContent: 'space-between',
        width: mobileW * 71 / 100,
     

    },
    CalanderView: {
        width: mobileW * 40 / 100,
        marginHorizontal: mobileW * 2 / 100,
        height: mobileW * 12 / 100,
        marginTop: mobileW * 3 / 100,
        borderRadius: mobileW * 1 / 100,
        padding: mobileW * 2 / 100,
        borderWidth: mobileW * 0.5 / 100,
        borderColor: Colors.themecolor,
        flexDirection: 'row',
        alignItems: 'center'
    },
    sessionDurationView: {
        width: mobileW * 40 / 100,
        marginHorizontal: mobileW * 2 / 100,
        height: mobileW * 13 / 100,
        marginTop: mobileW * 1 / 100,
        borderRadius: mobileW * 1 / 100,
        borderWidth: mobileW * 0.5 / 100,
        borderColor: Colors.themecolor,
        justifyContent: 'center',
        alignItems: 'center'
    },
    courseDurationText: {
        fontSize: mobileW * 3.5 / 100,
        color: Colors.themecolor,
        marginBottom: mobileW * 2 / 100,
        marginHorizontal: mobileW * 2 / 100,
        fontWeight: '500',
    },
    calanderText: {
        color: Colors.gray,
        alignSelf: 'center',
        fontSize: mobileW * 2.8 / 100,
        fontWeight: '500',
        marginHorizontal: mobileW * 2 / 100
    },
    sessionDuration: {
        color: Colors.gray,
        fontSize: mobileW * 5 / 100,
        fontWeight: '500',
        marginHorizontal: mobileW * 2 / 100
    },
    iconQuestionMark: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        tintColor: Colors.gray
    },
    ModelButton: {
        width: mobileW * 25 / 100,
        height: mobileW * 8 / 100,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.themecolor,
        borderRadius: mobileW * 1 / 100,
        marginHorizontal: mobileW * 2 / 100,
    },
    dropdown: {
        height: mobileW * 12 / 100, width: mobileW * 85 / 100,
        alignSelf: 'center',
        borderWidth: 1,
        borderRadius: mobileW * 1 / 100,
        paddingHorizontal: mobileW * 3 / 100,
    },
    ModelCard: {
        width: mobileW * 90 / 100,
        borderRadius: mobileW * 3 / 100,
        backgroundColor: Colors.white_color,
        elevation: 5
    },
    ModelHeader: {
        width: mobileW * 90 / 100,
        justifyContent: 'space-between',
        flexDirection: 'row',
        alignItems: 'center',
        height: mobileW * 12 / 100,
        borderTopLeftRadius: mobileW * 3 / 100,
        borderTopRightRadius: mobileW * 3 / 100,
        backgroundColor: Colors.themecolor
    },
    GIF: {
        width: mobileW * 25 / 100,
        height: mobileW * 12 / 100
    },
    underline: {
        width: mobileW * 85 / 100,
        height: mobileW * 0.2 / 100,
        marginTop: mobileW * 2 / 100,
        backgroundColor: Colors.gray,
        alignSelf: 'center'
    },
    icon: {
        marginRight: 0,
    },
    label: {
        position: 'absolute',
        left: 22,
        top: 2,
        zIndex: 999,
        paddingHorizontal: 0,
        fontSize: 12,
    },
    placeholderStyle: {
        fontSize: mobileW * 3 / 100,
        marginHorizontal: mobileW * 1 / 100
    },
    selectedTextStyle: {
        fontSize: mobileW * 4 / 100,
        color: Colors.gray,
        fontWeight: '500'
    },
    iconStyle: {
        width: mobileW * 7 / 100,
        height: mobileW * 2 / 100,
    },
    inputSearchStyle: {
        height: mobileW * 10 / 100,
        fontSize: mobileW * 3.5 / 100,
    },
    learnerListText: {
        fontSize: mobileW * 3.5 / 100,
        color: Colors.themecolor,
        marginHorizontal: mobileW * 2 / 100,
        fontWeight: '500',
        marginTop: mobileW * 2 / 100
    },
}
)
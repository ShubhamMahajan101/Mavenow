import { View, ScrollView,  StatusBar, Modal, Alert, FlatList, Text, StyleSheet, Dimensions, TouchableOpacity, Image, ImageComponent } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Colors, Font } from './Provider/Colorsfont';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import axios from 'axios';
import { SafeAreaView } from 'react-native-safe-area-context'
import { fonts } from 'react-native-elements/dist/config';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

const DATA = [
    {
      id: 1,
      title: 'Android',
      discription:'Android we can customize the OS based on our requirements'
    },
    {
      id:2,
      title: 'Android Setup',
      discription:'Android Open Source Project so we can customize the OS based on our requirements.'
    },
    {
      id: 3,
      title: 'Android Studio Setup',
      discription:'The design of the Android Application has guidelines from Google, which becomes easier for...'
    },
    {
      id: 4,
      title: 'Android Intro',
      discription:'Android Open Source Project so we can customize the OS based on our requirements.'
    },
    {
      id: 5,
      title: 'ALayout View',
      discription:'Layout View is very important of Android'
    },
    {
        id: 6,
        title: 'ALayout View',
        discription:'Layout View is very important of Android'
      },
  ];


export default function Syllabus({navigation}) {

  return (
    <View style={{ flex: 1, }}>
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
      <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
      {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
      <View style={styles.Header}>
      {/* <View style={{ flexDirection: 'row', alignItems: 'center' }}> */}
      <TouchableOpacity activeOpacity={0.8} style={{}} onPress={() => navigation.goBack()}>
      <Image style={{height:mobileW*10/100, height:mobileW*10/100, }} resizeMode='contain'source={require("./Icon/bk.png")}></Image>
      </TouchableOpacity>
      <Text style={{fontSize:mobileW*3.3/100, fontFamily:Font.FontMedium, color:Colors.black_color, marginRight:mobileW*8/100}}>Syllabus</Text>
      <Text style={{fontSize:mobileW*3.3/100, fontFamily:Font.FontMedium, color:Colors.black_color, marginRight:mobileW*8/100}}></Text>
      </View>

   <View style={{marginBottom:mobileH*20/100}}>
      <FlatList
    data={DATA}
    renderItem={({ item, index }) =>
      <View style={styles.CardView}>
        <Text style={{fontSize:mobileW*4/100, fontFamily:Font.FontRegular, color:Colors.black_color}}>{item.title}</Text>
        <Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontRegular, color:Colors.light_grey}}>{item.discription}</Text>
        <View style={{flexDirection:'row', justifyContent:'flex-end', marginTop:mobileW*3/100}}>
            <TouchableOpacity activeOpacity={0.8} onPress={()=>navigation.navigate('CreateTopic')}>
            <Image resizeMode='center' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.blackColor, }}
            source={require('./Icon/plus.png')}></Image>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8}>
            <Image resizeMode='center' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.blackColor,marginHorizontal:mobileW*5/100}}
            source={require('./Icon/ic_edit.png')}></Image>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8}>
            <Image resizeMode='center' style={{width:mobileW*4/100, height:mobileW*4/100, tintColor:Colors.blackColor }}
            source={require('./Icon/delete.png')}></Image>
            </TouchableOpacity>
        </View>
      </View>
                  }/>
                  </View>



      <View style={{flexDirection:'row', alignSelf:'center', position:'absolute', bottom:8}}>
        <TouchableOpacity style={{width:mobileW*45/100, height:mobileW*12/100, backgroundColor:Colors.lightgray,marginHorizontal:mobileW* 1/100, borderRadius:mobileW*2/100, alignItems:'center',justifyContent:'center'}}>
            <Text style={{fontSize:mobileW*4/100, color:Colors.black_color, fontFamily:Font.FontRegular}}>SAVE & EXIT</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{width:mobileW*45/100, height:mobileW*12/100, backgroundColor:Colors.themecolor,marginHorizontal:mobileW* 1/100, borderRadius:mobileW*2/100, alignItems:'center',justifyContent:'center'}}>
        <Text style={{fontSize:mobileW*4/100, color:Colors.white_color, fontFamily:Font.FontRegular}}>SAVE & NEXT</Text>
        </TouchableOpacity>
      </View>
      </SafeAreaView>
      </View>
  )
}
const styles = StyleSheet.create({
    container: {
      flex: 1
    },
    Header: {
      backgroundColor: Colors.white_color,
      width: mobileW, 
      height: mobileW * 13 / 100,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between'
    },
    backIcon_: {

        // width: mobileW * 9.5 / 100,
        // height: mobileW * 9.5 / 100,
        tintColor: Colors.white_color
      },
      CardView:{
        width:mobileW*96/100, 
        padding:mobileW*4/100, 
        marginTop:mobileW*2/100, 
        backgroundColor:Colors.white_color,
        elevation:2,
        alignSelf:'center',
        borderRadius:mobileW*2/100,
        shadowColor: '#000',
        borderColor: "#e8edfb",
        borderWidth: 1,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, },
}
})
import {StatusBar,ScrollView, Animated,FlatList,TextInput, View, Text,Dimensions,TouchableOpacity,Image, StyleSheet,Alert } from 'react-native'
import React,{useCallback, useRef,useState, useEffect} from 'react'
import { SafeAreaView } from 'react-native-safe-area-context';

import { Colors } from './Provider/Colorsfont';

// import { TextInput } from 'react-native-gesture-handler';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

const DATA = [
  {
    id: 1,
    className: 'Class Name',
    Learner : 'Learner',
    Maven:'Maven',
    Duration:'Duration:',
    StartDate:'Start Date',
    EndDate:'End Date',
    Feedback:'Feedback Date'
    // image: require('./Icon/galley_placeholder.png'),
    // title: 'test',
    // description: 'this is only test',
    // awards: 'Awarded on:27, Sep 2022',
  },
  
]

export default function Feedback1() {
  const [ description, setDescription] = useState(null);
  return (
    <View style={{ flex: 1, }}>
       <SafeAreaView style={{ flex: 1, backgroundColor:Colors.white_color}}>
            <StatusBar barStyle = "light-content" hidden = {false} backgroundColor ={Colors.themecolor} />
            <View style={styles.Header}>
              <Text style={{fontSize:mobileW*5/100, color:Colors.white_color, fontWeight:'500', paddingHorizontal:mobileW*5/100}}>Feedback1</Text>
            </View>
            <View style={{width:mobileW*25/100,margin:mobileW*5/100, height:mobileW*25/100, borderWidth:mobileW*0.8/100,borderColor:Colors.themecolor, borderRadius:mobileW*15/100, alignItems:'center', justifyContent:'center'}}>
           <Image style={{width:mobileW*22/100, height:mobileW*22/100,marginTop:mobileW*2/100,borderRadius:mobileW*10/100,tintColor:Colors.gray}}
           source={require('./Icon/ic_profile_placeholder_w.png')}></Image>
            </View>
            <Text style={{paddingLeft:mobileW*5/100, color:Colors.black_color, fontSize:mobileW*4/100}}>Your Rating:</Text>
            <View style={{flexDirection:'row',paddingRight:mobileW*5/100,paddingLeft:mobileW*5/100,justifyContent:'space-between'}}>
                <View>
              <Image style={{width:mobileW*10/100, height:mobileW*10/100,tintColor:Colors.light_grey}}
              source={require('./Icon/star.png')}></Image>
              <Text style={{color:Colors.dark_gray, fontSize:mobileW*3/100, textAlign:'center'}}>Terrible</Text>
              </View>
              <View>
              <Image style={{width:mobileW*10/100, height:mobileW*10/100,tintColor:Colors.light_grey}}
              source={require('./Icon/star.png')}></Image>
              <Text style={{color:Colors.dark_gray, fontSize:mobileW*3/100, textAlign:'center'}}>Terrible</Text>
              </View>
              <View>
              <Image style={{width:mobileW*10/100, height:mobileW*10/100,tintColor:Colors.light_grey}}
              source={require('./Icon/star.png')}></Image>
              <Text style={{color:Colors.dark_gray, fontSize:mobileW*3/100, textAlign:'center'}}>Terrible</Text>
              </View>
              <View>
              <Image style={{width:mobileW*10/100, height:mobileW*10/100,tintColor:Colors.light_grey}}
              source={require('./Icon/star.png')}></Image>
              <Text style={{color:Colors.dark_gray, fontSize:mobileW*3/100, textAlign:'center'}}>Terrible</Text>
              </View>
              <View>
              <Image style={{width:mobileW*10/100, height:mobileW*10/100,tintColor:Colors.light_grey}}
              source={require('./Icon/star.png')}></Image>
              <Text style={{color:Colors.dark_gray, fontSize:mobileW*3/100, textAlign:'center'}}>Terrible</Text>
              </View>
            </View>
             <Text style={{paddingTop:mobileW*5/100,paddingLeft:mobileW*5/100, color:Colors.black_color, fontSize:mobileW*4/100}}>Review Description:</Text>
<View style={{width:mobileW*90/100,height:mobileH*22/100,marginTop:mobileW*2/100, backgroundColor:Colors.white_color,elevation:1, borderColor:Colors.themecolor,borderWidth:mobileW*0.4/100, alignSelf:'center', borderRadius:mobileW*3/100}}>
<TextInput style={{fontSize:mobileW*5/100,color:Colors.gray,padding:mobileW*2/100,}}
                                 multiline onChangeText={setDescription}
                                 value={description}
                                 placeholderTextColor = {Colors.gray}
                                 placeholder="Review"
                                 // keyboardType="numeric"
                                    />
</View>


              {/* ======================================= Login Button ===================================== */}
          <TouchableOpacity activeOpacity={0.8} style={styles.LoginView}>
            <Text style={{ fontSize: mobileW * 5 / 100, color: Colors.white_color, fontWeight: '600' }}>POST</Text>
          </TouchableOpacity>
</SafeAreaView>
</View>
  )
}

const styles = StyleSheet.create({
    container: {
  flex:1,
  // backgroundColor:"red"
    },
    Header:{
      backgroundColor:Colors.themecolor, 
      width:mobileW, height:mobileW*15/100, 
     
      
      justifyContent:'center'
    },
    backIcon:{ 
      width: mobileW * 10 / 100, 
      height: mobileW * 10 / 100, 
      tintColor: Colors.white_color ,
      borderRadius:mobileW*4/100
    },
    SearchIcon:{ 
      width: mobileW * 6 / 100, 
      height: mobileW * 6 / 100, 
      tintColor: Colors.white_color 
    },
    LoginView: {
      justifyContent: 'center',
      alignItems: 'center',
      height: mobileW * 14 / 100,
      backgroundColor: Colors.themecolor,
      borderRadius: mobileW * 3 / 100,
      margin:mobileW*5/100,
      elevation: 1,
      shadowColor: '#000',
      borderColor: "#e8edfb",
      borderWidth: 1,
      shadowOpacity: 0.1,
      shadowOffset: { width: 0, },
      shadowOpacity: 0.1,

  
    },
})
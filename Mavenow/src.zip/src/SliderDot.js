import { View, Animated, StyleSheet, Dimensions } from 'react-native'
import React from 'react';
import { Colors } from './Provider/Colorsfont';
const {width} = Dimensions.get('screen')

export default function SliderDot({data, scrollX}) {
  return (
    <View style={styles.Container}>
      {/* <Text>SliderDot</Text> */}

      {data.map((_, idx) =>{
        const inputRange = [(idx-1)*width,idx * width,(idx+1)* width];
        const dotWidth =scrollX.interpolate({
            inputRange,
            outputRange:[6,6,6],
            extrapolate:'clamp'
        })
        const backgroundColor = scrollX.interpolate({
            inputRange,
            outputRange: [Colors.gray, Colors.themecolor, Colors.gray],
            extrapolate: 'clamp',
          });
        return <Animated.View kay={idx.toString()} style={[styles.dot, {width: dotWidth, backgroundColor},]}/>
      })}
    </View>
  )
}
const styles = StyleSheet.create({
    Container:{
position:'absolute',
bottom:80,
flexDirection:'row',
width:'100%',
alignItems:'center',
justifyContent:'center'

    },
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        marginHorizontal: 3,
        backgroundColor: '#ccc',
      },
      dotActive: {
        backgroundColor: Colors.themecolor,
      },
//     StyleDot:{
// width:12, height:12, borderRadius:6,
// backgroundColor:Colors.themecolor
//     }
})
import {Modal, Alert, ScrollView, RefreshControl, Switch, TextInput, StatusBar, Animated, FlatList, View, Text, Dimensions, TouchableOpacity, Image, StyleSheet } from 'react-native'
import React, { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors } from './Provider/Colorsfont';
import AnimatedLoader from 'react-native-animated-loader';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;


const userList1 = [
  {
    id: 1,
    image: require('./Icon/icon_student.png'),
    name: 'dixit',
    title: 'hello',
    date: '2022-06-01',
    isEnabled: false
  },
  {
    id: 2,
    image: require('./Icon/icon_student.png'),
    name: 'pritesh',
    title: 'hello',
    date: '20-07-2022',
    isEnabled: false
  },
  {
    id: 3,
    image: require('./Icon/icon_student.png'),
    name: 'Vindi',
    title: 'hello',
    date: '20-07-2022',
    isEnabled: false
  },
]

export default function Chatt({ navigation }) {
  const [show, setShow] = useState('Add')
  const [number, onChangeNumber] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [userList, setuserList] = useState(userList1);
  const [refresh, setrefresh] = useState(false)
 

  console.log('userList------', userList);

  const _onRefresh = async () => {
    console.log('_onRefresh', '_onRefresh')
    setrefresh(true)
    setTimeout(() => {
      setrefresh(false)
    }, 1000);
  }

    const _searchLearner = (textToSearch) => {
    var textToSearch = textToSearch.toString().toLowerCase();
    let data1 = userList
    if (data1 != 'NA') {
       console.log('data1', data1);
      if (data1 != 'NA') {
        var text_data = textToSearch.trim();
        let newData = data1.filter(function (item) {
          var name = item.name
          return (
            name.toString().toLowerCase().indexOf(text_data) >= 0
          )
        });

        if (newData.length > 0) {
          setuserList(newData)
        } else if (newData.length <= 0) {
          setuserList('')
        }
      }
    }
  }

  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        <View style={styles.Header}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()} style={{ marginHorizontal: mobileW * 5 / 100 }} >
              <Image style={styles.backIcon} resizeMode='contain'
                source={require("./Icon/icon_back.png")}></Image>
            </TouchableOpacity>
            <Text style={{ color: Colors.white_color, fontWeight: '500', fontSize: mobileW * 5 / 100 }}>Chat</Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('search')} style={{ marginRight: mobileW * 2 / 100 }} >
              <Image style={styles.SearchIcon} resizeMode='contain'
                source={require("./Icon/icon_search.png")}></Image>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginRight: mobileW * 2 / 100 }} >
              <Image style={styles.SearchIcon} resizeMode='contain'
                source={require("./Icon/icon_info.png")}></Image>
            </TouchableOpacity>
          </View>
        </View>

        {/* =================================================================Model================================================================ */}
        <View  >
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible(!modalVisible);
            }}
          >
            <View style={{ flex: 1, backgroundColor: '#00000090' }}>
              <View style={styles.ModelCard}>
                <View style={styles.ModelHeader}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}>Help:Chat</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                    <Image style={styles.backIcon} resizeMode='contain'
                      source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                </View>
                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    <Text style={{ color: Colors.dark_gray, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </Text>
                    
                  </View>
                </ScrollView>
              </View>
            </View>
          </Modal>
        </View>
        {show != 'Add' &&
          <View 
          style={{ width: mobileW, height: mobileW * 15 / 100, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.themecolor }}>
            <View 
            style={{ backgroundColor: Colors.white_color, width: mobileW * 95 / 100, flexDirection: 'row', borderRadius: mobileW * 1 / 100, alignItems: 'center' }}>
              <TextInput
                style={{ width: mobileW * 85 / 100, borderRadius: mobileW * 1 / 100, height: mobileW * 10 / 100, backgroundColor: Colors.white_color }}
                onChangeText={(txt)=>_searchLearner(txt)}
                value={number}
                placeholder="Search..."

              />
              <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('Add')}>
                <Image resizeMode='contain' 
                style={{ width: mobileW * 6 / 100, height: mobileW * 6 / 100, borderRadius: mobileW * 2 / 100, tintColor: Colors.themecolor }}
                  source={require('./Icon/close2.png')}></Image>
              </TouchableOpacity>
            </View>
          </View>}
        {/* ============================================================================= Page Refresh ============================================================================== */}
        <ScrollView refreshControl={
          <RefreshControl 
         
          refreshing={refresh}
          onRefresh={_onRefresh}
          tintColor={Colors.themecolor}
          colors={[Colors.themecolor]}
            />
        }>
          <FlatList
            data={userList}
            renderItem={({ item, index }) => {
              return (
                <TouchableOpacity
                activeOpacity={0.8} 
                onPress={()=> {navigation.navigate('UserChatting')}}
                  style={{
                    backgroundColor: Colors.light_cyan,
                    flexDirection: 'row',
                    margin: mobileW * 2 / 100,
                    padding: mobileW * 2 / 100
                  }}>
                  <View style={{ width: mobileW * 22 / 100, }}>
                    <View style={styles.imageCard}>
                      <Image resizeMode='contain' style={styles.mavenImage}
                        source={item.image}></Image>
                    </View>
                  </View>
                  <View style={{ width: mobileW * 48 / 100, }}>
                    <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.blackColor, fontWeight: 'bold', marginTop: mobileW * 3 / 100
                  }}>{item.name}</Text>
                    <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.gray, fontWeight: '500' }}>{item.title}</Text>
                  </View>
                  <View style={{ width: mobileW * 22 / 100, justifyContent: 'space-between' }}>
                    <Text style={{ color: Colors.border_color2, fontSize: mobileW * 3 / 100, alignSelf: 'flex-end' }}>{item.date}</Text>
                    <View style={{ width: mobileW * 13 / 100, height: mobileW * 6 / 100, justifyContent: 'center', alignItems: 'center', alignSelf: 'flex-end' }}>
                      <Switch
                        trackColor={{ false: '#767577', true: '#81b0ff' }}
                        thumbColor={item.isEnabled ? Colors.themecolor : '#f4f3f4'}
                        value={item.isEnabled}
                        onChange={() => {setuserList(userList.map(index =>
                          item.id === index.id
                            ?({ ...index, isEnabled: !index.isEnabled })
                            : index
                        ))}}
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              )
            }
            }
          />
        </ScrollView>
      </SafeAreaView>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor:"red"
  },
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 15 / 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  SearchIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  ModelCard: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 3 / 100,
    marginTop: mobileH * 25 / 100,
    alignSelf: 'center',
    backgroundColor: Colors.white_color,
    elevation: 5
  },
  ModelHeader: {
    width: mobileW * 90 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 15 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  lottie: {
    width: 50,
    height: 50
  },
  imageCard: {
    width: mobileW * 18 / 100,
    height: mobileW * 18 / 100,
    borderRadius: mobileW * 10 / 100,
    borderWidth: mobileW * 0.6 / 100,
    borderColor: Colors.themecolor,
    alignItems: 'center',
    justifyContent: 'center'
  },
  mavenImage: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    borderRadius: mobileW * 3 / 100,
    tintColor: Colors.themecolor
  },
}
)
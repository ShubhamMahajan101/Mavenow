import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ScrollView, ImageBackground, YellowBox, Alert, Modal, FlatList, Linking, TouchableNativeFeedback, Share } from 'react-native'
import { Stack, TextInput, } from "@react-native-material/core";
import { StatusBar } from 'react-native'
import React, { useState, useRef, useEffect, useCallback } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors, Font } from './Provider/Colorsfont'
import { localStorage } from './Provider/localStorageProvider';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
// import { Share } from 'react-native';
import axios from "axios"
import moment from 'moment';
import VideoPlayer from 'react-native-video-player';
import YoutubePlayer from "react-native-youtube-iframe";;
import { GoogleSignin, GoogleSigninButton, statusCodes } from '@react-native-google-signin/google-signin';
import LinkedInModal from '@smuxx/react-native-linkedin';
import Video from 'react-native-video';


import { AccessToken, GraphRequest, GraphRequestManager, LoginManager, } from 'react-native-fbsdk'

const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

const MyMavenProfile = ({ navigation }) => {
  const [shouldShow1, SetShouldShow1] = useState("Rating")
  const [modalSill, setModalSkill] = useState(false);
  const [shouldShow2, SetShouldShow2] = useState("right")
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible_share, setModalVisible_share] = useState(false);
  const [modalVisible_loadergif, setModalVisible_loadergif] = useState(false);
  const [modalVisible_video, setModalVisible_video] = useState(false);
  const [userInfo, setuserInfo] = useState({});
  const [name, setName] = useState([]);
  const [details, setDetails] = useState([]);
  const [playing, setPlaying] = useState(false);
  const [name1, setName1] = useState([]);
  const [Fullscreen, setFullscreen] = useState(false);
  const [currentTime, setcurrentTime] = useState(0);
  const [duration, setduration] = useState(0.1);
  const [overlay, setoverlay] = useState(false);
  const [userMode, setuserMode] = useState();
  const isLogin = userInfo.name;
  const buttonText = isLogin ? 'Logout With Facebook' : 'Login From Facebook';

  // -----------------------------------------------------------------------------------
  let lastTap = null;

  const playerRef = useRef();
  // ------------------------------------------------------------------------------------------------

  const onStateChange = useCallback((state) => {
    if (state === "ended") {
      setPlaying(false);
      Alert.alert("video has finished playing!");
    }
  }, []);

  // -------------------------------------------------------------------------------------------
  const togglePlaying = useCallback(() => {
    setPlaying((prev) => !prev);
  }, []);

  const Item = () => (
    <TouchableOpacity activeOpacity={0.8} style={styles.linkdinView}>
      <Image resizeMode='contain' style={{ width: mobileW * 3 / 100, height: mobileW * 3 / 100, backgroundColor: Colors.white_color, tintColor: Colors.themecolor }}
        source={require("./Icon/linkedin.png")}></Image>
    </TouchableOpacity>

  );


  // =======================================================================================        <>               =================================================== 
  useEffect(() => {
    
    setTimeout(() => {
      setModalVisible_loadergif(false)
    }, 2000);

    apiCalling();
    apiCalling1();
    SetMode();
  }, [])

  const SetMode = async (data) => {

    const value = await localStorage.getItemString('UserMode')
    console.log("..........", value);
    setuserMode(value)


  }

  const apiCalling = () => {
    axios.get('https://mavenow.com:8001/user?id=848&userType=1&userId=848&token=%22eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NDEyNzQ1N30.zqWCkVDbh-1a2zUBpOpZg-4_8b2QvdB_AmJeXEdf95Q')
      .then(res => {
        const nameList = res.data.result;

        console.log('--------- data arriwal  api  my maven profile screen->', nameList)

        setDetails(nameList)

        var mystring = nameList.teachingskills
        var elements = mystring.split(',');
        setName(elements)
        console.log('--------->>>', elements);
      })
      .catch(function (error) {
        console.log('---------->', error);
      });
  }


  const apiCalling1 = () => {
    axios.get('https://mavenow.com:8001/userrequest/getUserClassesByRating?userId=848&TypeofRequest=1&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NDIxMzE2Nn0.ASnHQya29LrSAqN6ff2DCam56LZRA_71X2oM6JUyJM8')
      .then(res => {
        const nameList = res.data.result;
        // const imageArray = nameList.result;
        console.log(' 2nd api  data my  maven profile screen==============second>', nameList)

        setName1(nameList)

        setTimeout(() => {
          // setModalVisible3(false)
        }, 1500);
        // setCategory(nameList.category)
      })
      .catch(function (error) {
        console.log('---------->', error);
      });

  }

  // ............................................ SHARE app  CODE ...................................

  // const onShare = async () => {
  //   console.log("sssss!!!!!!!!!!!!!!!!")
  //   try {
  //     const result = await Share.share({
  //       message: Platform.OS === "android" ?
  //         'https://play.google.com/store/search?q=trulinco&c=apps' :
  //         "https://apps.apple.com/in/app/trulinco/id1583020135",
  //     });
  //     if (result.action === Share.sharedAction) {
  //       if (result.activityType) {

  //       } else {

  //       }
  //     } else if (result.action === Share.dismissedAction) {

  //     }
  //   } catch (error) {
  //     alert(error.message);
  //   }
  // };

  // -----------------------------------------------------------------------------------------------------
  const signIn = async () => {
    alert('Unable to Login with Google Account')
  }
  const onShare = async () => {
    try {
      const result = await Share.share({
        message:
          'React Native | A framework for building native apps using React',
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch {
      Alert.alert(error.message);
    }
  };





  // ............................................ SHARE CODE ...................................
  // GoogleSignin.configure({
  //   scopes: ['https://www.googleapis.com/auth/drive.readonly'], // what API you want to access on behalf of the user, default is email and profile
  //   webClientId: '<FROM DEVELOPER CONSOLE>', // client ID of type WEB for your server (needed to verify user ID and offline access)
  //   offlineAccess: true, // if you want to access Google API on behalf of the user FROM YOUR SERVER
  //   hostedDomain: '', // specifies a hosted domain restriction
  //   loginHint: '', // [iOS] The user's ID, or email address, to be prefilled in the authentication UI if possible. [See docs here](https://developers.google.com/identity/sign-in/ios/api/interface_g_i_d_sign_in.html#a0a68c7504c31ab0b728432565f6e33fd)
  //   forceConsentPrompt: true, // [Android] if you want to show the authorization prompt at each login.
  //   accountName: '', // [Android] specifies an account name on the device that should be used
  //   iosClientId: '<FROM DEVELOPER CONSOLE>', // [iOS] optional, if you want to specify the client ID of type iOS (otherwise, it is taken from GoogleService-Info.plist)
  // });

  // const signIn = async () => {
  //   try {
  //     await GoogleSignin.hasPlayServices();
  //     console.log("userInfo111");
  //     const userInfo = await GoogleSignin.signIn();
  //     console.log(userInfo);
  //     // this.setState({ userInfo });
  //   } catch (error) {
  //     if (error.code === statusCodes.SIGN_IN_CANCELLED) {
  //       console.log("userInfo222");
  //       // user cancelled the login flow
  //     } else if (error.code === statusCodes.IN_PROGRESS) {
  //       console.log("userInfo333");
  //       // operation (f.e. sign in) is in progress already
  //     } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
  //       console.log("userInfo444");
  //       // play services not available or outdated
  //     } else {
  //       // some other error happened
  //     }
  //   }
  // };



  // try {
  //   GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
  //   // google services are available
  // } catch (err) {
  //   console.error('play services are not available');
  // }
  // -------------------------------------------------------------------------------------------------------------------------- facebook,
  const logoutWithFacebook = () => {
    LoginManager.logOut();
    setuserInfo({})
  };

  const getInfoFromToken = token => {
    const PROFILE_REQUEST_PARAMS = {
      fields: {
        string: 'id,name,first_name,last_name',
      },
    };
    const profileRequest = new GraphRequest(
      '/me',
      { token, parameters: PROFILE_REQUEST_PARAMS },
      (error, user) => {
        if (error) {
          console.log('login info has error: ' + error);
        } else {
          // this.setState({userInfo: user});
          console.log('result:', user);
        }
      },
    );
    new GraphRequestManager().addRequest(profileRequest).start();
  };

  const loginWithFacebook = () => {
    // Attempt a login using the Facebook login dialog asking for default permissions.
    LoginManager.logInWithPermissions(['public_profile']).then(
      login => {
        if (login.isCancelled) {
          console.log('Login cancelled');
        } else {
          AccessToken.getCurrentAccessToken().then(data => {
            const accessToken = data.accessToken.toString();
            getInfoFromToken(accessToken);
          });
        }
      },
      error => {
        console.log('Login fail with error: ' + error);
      },
    );
  };

  const onPressButton = () => {
    isLogin
      ? logoutWithFacebook()
      : loginWithFacebook();
  }
  // -------- >> pass  url to crome <<------------
  const crome_url = "https://www.mavenow.com/mavenow_webservices/codework/cards/index.html?username=Vinay&rating=0&joindate=11/07/2022&aboutme=hi&skills=As%20a%20student%20skill%20Kotlin(basic)&completeclasses=8&userimage=https://mavenow.com/mavenow_webservices/codework/U&userId=848"
  const loadInBrowser = () => {
    Linking.openURL(crome_url).catch(err => console.error("Couldn't load page", err));
  };
  // ------------------ >> pass url to crome << --------------
  // -------------->> player function <<-------------------
  const FullscreenToggle = () => {

    if (Fullscreen) {
      Orientation.lockToPortrait();
      StatusBar.setHidden(false)
      navigation.setOptions({ headerShown: true });
      setFullscreen(false)
    } else {
      Orientation.lockToLandscape();
      StatusBar.setHidden(true)
      navigation.setOptions({ headerShown: false });
      setFullscreen(true);
    }

  }

  const handleDoubleTap = (doubleTapCallback, singleTapCallback) => {
    const now = Date.now();
    const DOUBLE_PRESS_DELAY = 300;
    if (lastTap && (now - lastTap) < DOUBLE_PRESS_DELAY) {
      clearTimeout(Timer);
      doubleTapCallback();
    } else {
      lastTap = now;
      Timer = setTimeout(() => {
        singleTapCallback();
      }, DOUBLE_PRESS_DELAY);
    }
  }

  const ShowHideOverlay = () => {
    handleDoubleTap(() => {
    }, () => {
      setoverlay(true)
      overlayTimer = setTimeout(() => setoverlay(false), 5000);
    })
  }
  const backward = () => {
    playerRef.current.seek(currentTime - 10);
    clearTimeout(overlayTimer);
    overlayTimer = setTimeout(() => setoverlay(false), 3000);
  }
  const forward = () => {
    playerRef.current.seek(currentTime + 10);
    clearTimeout(overlayTimer);
    overlayTimer = setTimeout(() => setoverlay(false), 3000);
  }
  const onslide = (slide) => {
    playerRef.current.seek(slide * duration);
    clearTimeout(overlayTimer);
    overlayTimer = setTimeout(() => setoverlay(false), 3000);
  }
  const getTime = (t) => {
    const digit = n => n < 10 ? `0${n}` : `${n}`;
    const sec = digit(Math.floor(t % 60));
    const min = digit(Math.floor((t / 60) % 60));
    const hr = digit(Math.floor((t / 3600) % 60));
    // return hr + ':' + min + ':' + sec; 
    return min + ':' + sec;
  }
  const load = ({ duration }) => {
    console.log('duration------', duration);
    setduration(duration);
  }
  const progress = ({ currentTime }) => {
    setcurrentTime(currentTime);
    console.log('currentTime-----', currentTime);
  }
  return (
        <View style={{ flex: 1 }}>
        <SafeAreaView style={{ flex: 1 }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor="#00959e" translucent={true} />
        <View style={styles.Header}>
        <View style={{ flexDirection: "row", alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()}>
        <Image style={styles.backIcon_} resizeMode='contain' source={require("./Icon/bk.png")}></Image>
        </TouchableOpacity>
        <Text style={styles.mavenProfole_text}>{userMode == 'maven' ?Lang_chg.MavenProfileTxt[config.language]:Lang_chg.LearnerProfileTxt[config.language] }</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)}>
        <Image style={styles.backIcon_edit} resizeMode='contain' source={require("./Icon/icon_info.png")}></Image>
        </TouchableOpacity>
        <TouchableOpacity activeOpacity={0.8} style={{ marginRight: mobileW * 1 / 100 }} onPress={() => navigation.navigate('UpdateMavenn_Profile',{},setModalVisible_loadergif(true))}>
        <Image style={styles.edit_Icon} resizeMode="stretch" source={require("./Icon/ic_edit.png")}></Image>
        </TouchableOpacity>
        </View>
        </View>

                     {/* -------------------------------------------- gif loader modal -------------------------- */}
                <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible_loadergif}
                onRequestClose={() => {
                setModalVisible_loadergif(!modalVisible_loadergif)}}>
                <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000096'}}>
                <Image style={styles.GIF} source={require("./Icon/neighcoach_loader.gif")}></Image>
                </View>
                </Modal>
                    {/* -------------------------------------------- gif loader modal -------------------------- */}

        {/* ============================================================ Maven Profile Details ========================================================================= */}
                                     <View style={{ backgroundColor: "#e5f4f5", paddingBottom: mobileW * 10 / 100, marginTop: mobileW * 0.75 / 100,}}>
                                     <View style={{padding:mobileW*2/100}}>
         
                              <View style={{ alignSelf: "flex-end",  }}>
                              <Text style={{ fontSize: mobileW * 2.7 / 100, color: Colors.black_color ,fontFamily:Font.FontMedium}} >{Lang_chg.JoinDateTxt[config.language] + moment(details.createdOn).format("MMM DD, yyyy")}</Text>
                              </View>
                              <View style={{ width: mobileW * 98 / 100, alignSelf: 'center', }}>
                              <View style={{ flexDirection: "row", alignSelf: "center", }}>
                               <View style={{ width: mobileW * 19 / 100, }}>
                               <View style={styles.imageCard}>
                                {userMode == 'maven' ? <Image style={styles.mavenImage} resizeMode='contain' source={require("./Icon/icon_maven.png")}>
                                  </Image> : <Image style={styles.mavenImage} resizeMode='contain' source={require("./Icon/icon_student.png")}>

</Image>}
                  {/* <Image style={styles.mavenImage} resizeMode='contain' source={require("./Icon/icon_maven.png")}></Image> */}
                </View>
                {/* <Text style={{ alignSelf: "center", textAlign:'center', marginTop: mobileW * 1 / 100, color: Colors.blackColor, fontWeight: '500', fontSize: mobileW * 3.5 / 100, width:mobileW*16/100, }}>{details.FirstName} {details.LastName}</Text> */}
                <Text style={{ alignSelf: "center", textAlign:'center', marginTop: mobileW * 1 / 100, color: Colors.blackColor,fontSize: mobileW * 3.1 / 100, width:mobileW*16/100,fontFamily:Font.FontSemiBold }}>Gaurav</Text>
                {/* <Text style={{ alignSelf: "center", color: Colors.blackColor, fontWeight:'500' }}>{name.LastName}</Text> */}
                {userMode == 'maven' ?
                <View style={{ flexDirection: "row", justifyContent: "space-between", }}>
                  <TouchableOpacity>
                    <Image style={styles.ratting_fullimage} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Image style={styles.ratting_fullimage} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <Image style={styles.ratting_fullimage} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                  </TouchableOpacity>
                  <Image style={styles.ratting_fullimage} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                  <TouchableOpacity>
                    <Image style={styles.ratting_fullimage} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                  </TouchableOpacity>
                </View>:null}

              </View>
              <View style={{ width: mobileW * 79 / 100, }}>
                <View style={{ marginHorizontal: mobileW * 1 / 100 }}>
                  <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3 / 100 }}>{details.AboutMe}</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible_share(true)} style={{ marginTop: mobileW * 2 / 100 }}>
                  {userMode == 'maven' ? <Image style={styles.share_icon} resizeMode='contain' source={require("./Icon/SShare.png")}></Image>: 
                  null}
                     
                  </TouchableOpacity>
                </View>
                <View style={{ flexDirection: "row", padding:mobileW*1.2/100,  }}>
                  <View style={{ width: mobileW * 19.7 / 100 }}>
                    <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('Badges')} style={{ alignItems: "center", marginTop: mobileW * 2 / 100 }}>
                      <Image style={{ width: mobileW * 5 / 100, height: mobileW * 5 / 100, tintColor: Colors.themecolor, }} resizeMode='contain' source={require("./Icon/ic_reward_w.png")}></Image>
                      {/* <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{details.numberOfBedges}</Text> */}
                      <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{2}</Text>

                      <Text style={styles.SAME_Text}>{Lang_chg.AchievementTxt[config.language]}</Text>

                    </TouchableOpacity>
                  </View>
                  <View style={{ width: mobileW * 19.8 / 100, }}>
                    <TouchableOpacity activeOpacity={0.8} style={{ alignItems: "center", marginTop: mobileW * 2 / 100 }} >
                      <Image style={{ width: mobileW * 5 / 100, height: mobileW * 5 / 100, tintColor: Colors.themecolor, }} resizeMode='contain' source={require("./Icon/Session_Completed.png")}></Image>
                      {/* <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{details.numberOfDisciple}</Text> */}
                      <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>4</Text>
                      <Text style={styles.SAME_Text}>{Lang_chg.SessionCompletedTxt[config.language]}</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={{ width: mobileW * 19.7 / 100 }}>
                    <TouchableOpacity activeOpacity={0.8} style={{ alignItems: "center", marginTop: mobileW * 2 / 100 }} >
                      <Image style={{ width: mobileW * 5 / 100, height: mobileW * 5 / 100, tintColor: Colors.themecolor, }} resizeMode='contain' source={require("./Icon/Active_Session.png")}></Image>
                      {/* <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{details.activesession}</Text> */}
                      <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{0}</Text>
                      <Text style={styles.SAME_Text}>{Lang_chg.ActiveSessionTxt[config.language]}</Text>
                    </TouchableOpacity>
                  </View>

                  <View style={{ width: mobileW * 19.8 / 100, }}>
                  {userMode == 'maven' ?
                    <TouchableOpacity activeOpacity={0.8} style={{ alignItems: "center", marginTop: mobileW * 2 / 100 }} onPress={() => navigation.navigate('MyLearners')} >
                      <Image style={{ width: mobileW * 5 / 100, height: mobileW * 5 / 100, tintColor: Colors.themecolor, }} resizeMode='contain' source={require("./Icon/icon_student.png")}></Image>
                      {/* <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{details.numberOfDisciple}</Text> */}
                      <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{5}</Text>
                      <Text style={styles.SAME_Text}>{Lang_chg.LearnersTxt[config.language]}</Text>
                    </TouchableOpacity>:
                     <TouchableOpacity activeOpacity={0.8} style={{ alignItems: "center", marginTop: mobileW * 2 / 100 }} onPress={() => navigation.navigate('MyLearners')} >
                     <Image style={{ width: mobileW * 5 / 100, height: mobileW * 5 / 100, tintColor: Colors.themecolor, }} resizeMode='contain' source={require("./Icon/icon_maven.png")}></Image>
                     {/* <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{details.numberOfDisciple}</Text> */}
                     <Text style={{ color: Colors.blackColor, alignSelf: 'center', fontSize: mobileW * 3 / 100 }}>{5}</Text>
                     <Text style={styles.SAME_Text}>{Lang_chg.MavensTxt[config.language]}</Text>
                   </TouchableOpacity>}
                  </View>

                </View>
              </View>
            </View>

            <Text style={styles.skills_Teext}>{Lang_chg.SkillsTxt[config.language]}</Text>
            <View style={{ flexDirection: "row", padding: mobileW * 2 / 100, }}>
              <View style={{ width: mobileW * 50 / 100, }}>
                <FlatList
                  data={name}
                  renderItem={({ item, index }) =>
                    <View>
                      {index <= 2 &&
                        <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.blackColor, }}>{item}{'\n'}</Text>
                      }
                      {index + 1 == name.length &&
                        <TouchableOpacity activeOpacity={0.8} onPress={() => setModalSkill(true)}>
                          <Text style={styles.seeMoreText} >{Lang_chg.seemoreTxt[config.language]}</Text>
                        </TouchableOpacity>
                      }
                    </View>
                  } />
              </View>
              {userMode == 'maven' ?
              <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible_video(true)} style={{ marginTop: mobileW * 5 / 100 }}>
                <Image style={styles.youTube}
                  resizeMode='contain' source={require("./Icon/you_tube.png")}></Image>
              </TouchableOpacity>:null}
            </View>
          </View>
          </View>
        </View>


        <View style={{ flexDirection: "row", alignSelf: "center", marginTop: mobileW * 2 / 100, }}>
          <TouchableOpacity style={[{ backgroundColor: shouldShow1 === 'Rating' ? Colors.themecolor : Colors.light_cyan, }, styles.RatingBtn]} onPress={() => SetShouldShow1('Rating')}>
            <Text style={{ color: shouldShow1 === 'Rating' ? Colors.white_color : Colors.blackColor, fontSize: mobileW * 3.5 / 100 }}>{Lang_chg.RatingReviewTxt[config.language]}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[{ backgroundColor: shouldShow1 === 'About' ? Colors.themecolor : Colors.light_cyan, }, styles.AboutMeBtn]} onPress={() => SetShouldShow1("About")}>
            <Text style={{ color: shouldShow1 === 'About' ? Colors.white_color : Colors.blackColor, fontSize: mobileW * 3.2/ 100 ,fontFamily:Font.FontMedium}}>{Lang_chg.AboutMeTxt[config.language]}</Text>
          </TouchableOpacity>
        </View>
        {shouldShow1 == 'About' &&
          <View>
          {shouldShow2 == "right" ?
          <View style={{ flexDirection: "row", justifyContent: "space-around", marginTop: mobileW * 2 / 100 }}>
          <TextInput color={Colors.themecolor} editable={false}
          value={name.note} style={styles.textInput}  placeholder={Lang_chg.aboutyourselfTxt[config.language]}/>
          <TouchableOpacity onPress={() => SetShouldShow2('write')}>
          <Image style={{ width: mobileW * 6 / 100, height: mobileW * 6 / 100, tintColor: Colors.blackColor }} resizeMode='contain'
                    source={require("./Icon/ic_edit.png")}></Image>
                </TouchableOpacity>
              </View>
               :
              <View style={{ flexDirection: "row", justifyContent: "space-around", marginTop: mobileW * 2 / 100 }}>
               
                  <TextInput
                    style={styles.input}
                    multiline
                    color={Colors.themecolor} 
                    placeholder={Lang_chg.aboutyourselfTxt[config.language]}
                    value={name} />
                <TouchableOpacity onPress={() => SetShouldShow2('right')} style={styles.chackicon}>
                  <Image style={{ width: mobileW * 4 / 100, height: mobileW * 4 / 100, tintColor: Colors.whiteColor }} source={require("./Icon/check.png")}></Image>
                </TouchableOpacity>
              </View>
            }
          </View>
        }
        {/* { Rating==} */}
        {shouldShow1 == 'Rating' &&
          <ScrollView>
            <View style={{ marginBottom: mobileW * 5 / 100 }}>

              <FlatList
                data={name1}
                renderItem={({ item }) =>
                  <View>
                    <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('AutomationTesingScreen', { item: item })} style={styles.rattingCard}>
                      <View style={{ flexDirection: "row", alignItems: "center", }}>
                        <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.4 / 100 }}>{Lang_chg.OverallRatingTxt[config.language]}</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: mobileW * 5 / 100, }}>
                          <Image style={styles.ratting} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                          <Image style={styles.ratting} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                          <Image style={styles.ratting} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                          <Image style={styles.ratting} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                          <Image style={styles.ratting} resizeMode='contain' source={require("./Icon/rating_full.gif")} />
                        </View>
                      </View>

                      <View style={{ flexDirection: "row", alignItems: 'center', marginTop: mobileW * 1 / 100 }}>
                        <View style={{ width: mobileW * 20 / 100 }}>
                          <Text style={styles.gray_text}>{Lang_chg.ClassNameTxt[config.language]}</Text>
                        </View>
                        <View style={{ width: mobileW * 75 / 100 }}>
                          <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.4 / 100 }}>{item.className}</Text>
                        </View>
                      </View>

                      <View style={{ flexDirection: "row", alignItems: 'center', marginTop: mobileW * 1 / 100 }}>
                        <View style={{ width: mobileW * 20 / 100 }}>
                          <Text style={styles.gray_text}>{Lang_chg.SkillssTxt[config.language]}</Text>
                        </View>
                        <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.4 / 100 }}>{item.Skills} ({item.request_level}) </Text>
                      </View>

                      {/* <View style={{ flexDirection: "row", alignItems: 'center', marginTop: mobileW * 1 / 100 }}>
                        <View style={{ width: mobileW * 20 / 100 }}>
                          <Text style={styles.gray_text}>Category</Text>
                        </View>
                        <View style={{ width: mobileW * 75 / 100 }}>
                          <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.4 / 100 }}>{item.SkillsCategory}</Text>
                        </View>
                      </View> */}

                      <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: mobileW * 2 / 100 }}>
                        <View>
                          <Text style={styles.gray_text}>{Lang_chg.StartDateTxt[config.language]}</Text>
                          <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.3 / 100 }}>{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                        </View>
                        <View>
                          <Text style={styles.gray_text}>{Lang_chg.EndDateTxt[config.language]}</Text>
                          <Text style={{ color: Colors.blackColor, fontSize: mobileW * 3.3 / 100 }}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  </View>
                  ///////////////////////////////////////////////////////////////////////////////////////////2nd time data  came to flat list
                } />


            </View>

          </ScrollView>
        }




        {/* ---------------------------------------------------------------------------------------------------- you tube player model---------------------------------- */}
        <View>
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible_video}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible_video(!modalVisible_video);
            }}>
            <View style={{ flex: 1, backgroundColor: "#00000096", alignItems: 'center', justifyContent: 'center' }}>
              <TouchableOpacity style={{ marginLeft: mobileW * 80 / 100 }} activeOpacity={0.8} onPress={() => setModalVisible_video(!modalVisible_video)} >
                <Image tintColor={Colors.themecolor} style={styles.backIcon_video} resizeMode='contain'
                  source={require("./Icon/close2.png")}></Image>
              </TouchableOpacity>
              <YoutubePlayer
                height={mobileH * 35 / 100}
                width={mobileW * 90 / 100}
                play={playing}
                videoId={"27WN1UKKphA"}
                onChangeState={onStateChange}
              />

            </View>
          </Modal>
        </View>
        {/* ---------------------------------------------------------------------------------------------------- you tube player model---------------------------------- */}


        {/* ----------------------------------------------------------------------------------model */}
        <View>
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible(!modalVisible);
            }}>
            <View style={{ flex: 1, backgroundColor: '#00000096', justifyContent: 'center', alignItems:'center' }}>

              <View style={styles.ModelCard}>
                <View style={styles.ModelHeader}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}>Help : profile</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                    <Image style={styles. backIcon_edit} resizeMode='contain'
                      source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                </View>
                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    <Text style={{ color: Colors.dark_gray, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

                    </Text>
                  </View>
                </ScrollView>
              </View>
            </View>

          </Modal>
        </View>
        {/* ----------------------------------------------------------------------------------model */}
        {/* ----------------------------------------------------------------------------------model */}
        <View>
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible_share}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible_share(!modalVisible_share);
            }}>
            <View style={{ flex: 1, backgroundColor: '#00000096', alignItems: 'center', justifyContent: 'center' }}>
              <View style={{ borderRadius: mobileW * 4 / 100, borderBottomEndRadius: mobileW * 4 / 100 }} >
                <View style={styles.CardBlueHeader}>
                  <Image style={{ width: mobileW * 50 / 100, height: mobileW * 12 / 100, alignSelf: "flex-end", marginRight: mobileW * 3 / 100 }} 
                  resizeMode='contain' source={require("./Icon/new_logo_mavenow.png")}></Image>
                </View>
                <View style={styles.MavenWhiteCard}>
                  <View style={{ flexDirection: "row", }}>
                    <View style={styles.imageCard2}>
                      <Image style={styles.imageIcon2} resizeMode='contain' source={require('./Icon/icon_maven.png')}></Image>
                    </View>
                    <View >
                      <View style={{ flexDirection: "row", justifyContent: 'center', marginTop: mobileW * 2 / 100 }}>
                        <Text style={{ color: Colors.blackColor, fontSize: mobileW * 5.5 / 100, fontWeight: '500' }}>{details.FirstName}</Text>
                        <Text style={{ color: Colors.themecolor, fontSize: mobileW * 5.5 / 100, fontWeight: '500', marginHorizontal: mobileW * 2 / 100 }}>Maven</Text>
                      </View>
                      <View style={{ flexDirection: "row", }}>
                        <TouchableOpacity>
                          <Image style={styles.star_image} resizeMode='contain'
                            source={require("./Icon/rating_full.gif")} />
                        </TouchableOpacity>
                        <TouchableOpacity>
                          <Image style={styles.star_image} resizeMode='contain'
                            source={require("./Icon/rating_full.gif")} />
                        </TouchableOpacity>
                        <TouchableOpacity>
                          <Image style={styles.star_image} resizeMode='contain'
                            source={require("./Icon/rating_full.gif")} />
                        </TouchableOpacity>
                        <Image style={styles.star_image} resizeMode='contain'
                          source={require("./Icon/rating_full.gif")} />
                        <TouchableOpacity>
                          <Image style={styles.star_image} resizeMode='contain'
                            source={require("./Icon/rating_full.gif")} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                  <View style={{ padding: mobileW * 5 / 100 }}>
                    <Text style={{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.AboutTxt[config.language]}</Text>
                    <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100 }}>Hii</Text>
                    {/* <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100 }}>{details.studentAboutMe}</Text> */}
                    <View style={{ marginTop: mobileW * 1 / 100 }}>
                      <Text style={{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.joiningDateTxt[config.language]}</Text>
                      <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100 }}>May 09,2023</Text>
                      {/* <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100 }}>{details.createdOn}</Text> */}
                      {/* <Text style={{color:Colors.themecolor,}}>{item.Date}</Text> */}
                    </View>
                    <View style={{ marginTop: mobileW * 2 / 100 }} >
                      <Text style={{ color: Colors.black_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.SkillsTxt[config.language]}</Text>
                      <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.gray }}>As a student skill {name}</Text>
                      {/* {details.teachingskills.replace(/,/g, " ")} */}
                    </View>
                    <View style={{ marginTop: mobileW * 3 / 100 }}>
                      <Text style={{ color: Colors.black_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>{Lang_chg.CompletedsesssionTxt[config.language]}</Text>
                      <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100, }}>{details.numberOfDisciple} Session</Text>
                      {/* <Text style={{color:Colors.themecolor}}>{item.session}</Text> */}

                    </View>
                  </View>
                  <View style={{ backgroundColor: Colors.themecolor, borderBottomLeftRadius: mobileW * 3 / 100, height: mobileW * 11 / 100, borderBottomRightRadius: mobileW * 3 / 100, justifyContent: 'center' }}>
                    <View style={{ flexDirection: "row", alignItems: 'center', justifyContent: "space-between", }}>
                      <View style={{ flexDirection: "row", alignItems: 'center', }}>
                        <TouchableOpacity activeOpacity={0.8} style={styles.faceBookicon} onPress={() => signIn()} >
                          <Image resizeMode='contain' style={styles.faceBook_image}
                            source={require("./Icon/facebook_icon.png")}></Image>
                        </TouchableOpacity>
                        
                        <TouchableOpacity activeOpacity={0.8} style={styles.linkedinIconView} onPress={() => signIn()}>
                          <Image resizeMode='contain' style={styles.linkedinIcon}
                            source={require("./Icon/linkedin.png")}></Image>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => onPressButton()}>
                          {/* <LinkedInModal
                            clientID="77bdw3u6uborp2"
                            clientSecret="7m7uDmHOcZeiS4Sq"
                            redirectUri="https://www.linkedin.com/developers/apps/verification/92b99669-9ea9-4a4f-af27-bd3d14731354"
                            onSuccess={token => console.log(JSON.stringify(token, null, 2))}
                            renderButton={() => <Item />} /> */}
                        </TouchableOpacity>
                        <TouchableOpacity activeOpacity={0.8} style={styles.faceBookicon} onPress={() => signIn()}>
                          <Image resizeMode='contain' style={styles.linkedinIcon}
                            source={require("./Icon/twitter.png")}></Image>
                        </TouchableOpacity>
                      </View>  
                      {/* <Image resizeMode='contain' style={styles.linkedin_Icon}
                            source={require("./Icon/earth.png")}></Image> */}
                      <TouchableOpacity onPress={() => loadInBrowser()} activeOpacity={0.8}>
                        <Text style={styles.www_text}>www.mavenow.com</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                  <Text style={styles.Text}>{Lang_chg.shareprofileTxt[config.language]}</Text>
                  <View style={styles.manage_view}>
                    <TouchableOpacity activeOpacity={0.8} style={styles.shareBtn} onPress={() => setModalVisible_share(!modalVisible_share)}>
                      <View>
                        <Text style={styles.Cancel_text}>{Lang_chg.CancelTxt[config.language]}</Text>
                      </View>
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={0.8} style={styles.shareBtn} 
                    onPress={() => onShare()}
                    >
                      <View>

                        {/* <Text style={styles.Cancel_text}>Share</Text> */}

                        <Text style={styles.share_text}>{Lang_chg.ShareTxt[config.language]}</Text>

                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>

            </View>
          </Modal>
        </View>

        {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++See more Modal+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
        <View >
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalSill} >
            <View style={styles.Modal_View}>
              <View style={{ width: mobileW * 90 / 100, }}>
                <View style={styles.skillmodalHeader}>
                  <Text style={styles.skills_text}>Skills</Text>
                </View>
                <View style={styles.skillmodalCard}>
                  <ScrollView>
                    <FlatList
                      data={name}
                      renderItem={({ item, index }) =>
                        <View>
                          <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.blackColor, }}>{item}{'\n'}</Text>
                        </View>
                      } />
                    <TouchableOpacity activeOpacity={0.8} onPress={() => setModalSkill(!modalSill)} style={[styles.chatBtn, { alignSelf: 'center', marginTop: mobileW * 8 / 100 }]}>
                      <Text style={styles.ok_text}>Okay</Text>
                    </TouchableOpacity>
                  </ScrollView>
                </View>
              </View>
            </View>
          </Modal>
        </View>



      </SafeAreaView>

    </View>
  )
};
export default MyMavenProfile
const styles = StyleSheet.create({
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 13 / 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  ok_text:{
    fontSize:mobileW*3.5/100,
    color:Colors.white_color
  },
  youTube:{ 
    width: mobileW * 8 / 100, 
    height: mobileW * 8 / 100, 
    marginLeft: mobileW * 15 / 100, 
    tintColor: Colors.red 
  },
  input: {
  width: mobileW * 85 / 100
  },
  skills_Teext:{ 
    color: Colors.gray, 
    fontSize: mobileW * 3 / 100, 
    paddingLeft: mobileW * 2 / 100, 
    marginTop: mobileW * 5 / 100 
  },
  www_text:{ 
    color: Colors.white_color, 
    fontSize: mobileW * 3.5 / 100, 
    fontWeight: '500', 
    marginRight: mobileW * 3 / 100 
  },
  ratting:{ 
    width: mobileW * 4 / 100, 
    height: mobileW * 4 / 100, 
    tintColor: Colors.light_grey 
  },
star_image: { 
  width: mobileW * 4 / 100, 
  height: mobileW * 4 / 100, 
  tintColor: Colors.gray 
},
 gray_text:{ 
  color: Colors.gray, 
  fontSize: mobileW * 2.8 / 100 
},
faceBook_image: { 
  width: mobileW * 3.5 / 100, 
  height: mobileW * 3.5 / 100, 
  backgroundColor: Colors.white_color,
   tintColor: Colors.themecolor, 
   borderRadius: mobileW * 4 / 100, 
  },
  manage_view: { 
    flexDirection: "row", 
    justifyContent: 'space-evenly', 
    padding: mobileW * 4 / 100 
  },
  Text: { 
    color: Colors.blackColor, 
    alignSelf: "center", 
    marginTop: mobileW * 5 / 100, 
    fontSize: mobileW * 3.2 / 100 
  },
  Cancel_text: { 
    color: Colors.whiteColor, 
    fontSize: mobileW * 3.3 / 100, 
    fontWeight: '500' 
  },
  Modal_View: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: '#00000096', 
  },
  skills_text: { 
    color: Colors.white_color, 
    fontSize: mobileW * 5 / 100, 
    fontWeight: '500' 
  },
  textInput:{ 
    width: mobileW * 85 / 100, 
    height: mobileW * 5 / 100, 
    borderBottomWidth: mobileW * 1 / 100, 
    borderBottomColor: Colors.themecolor ,
    fontSize:mobileW*2/100
   
  },
  mavenProfole_text: { 
    color: Colors.white_color, 
    fontSize: mobileW * 4.3/ 100, 
    marginHorizontal: mobileW * 3/ 100, 
    fontFamily:Font.FontMedium
  },
  share_text: { 
    color: Colors.whiteColor, 
    fontSize: mobileW * 3.5 / 100, 
    fontWeight: '500' 
  },
  ratting_fullimage:{ 
    width: mobileW * 3.8 / 100, 
    height: mobileW * 3.8 / 100, 
    tintColor: Colors.light_grey 
  },
  GIF: { 
    width: mobileW * 25 / 100, 
  height: mobileW * 12 / 100 
},
  backIcon_: {
    width: mobileW * 9.5/ 100,
    height: mobileW *9.5/ 100,
    tintColor: Colors.white_color,
    marginHorizontal:mobileW*2/100

  },
  backIcon: {
    width: mobileW * 3/ 100,
    height: mobileW *6/ 100,
    tintColor: Colors.white_color,
    marginHorizontal:mobileW*2/100
  },
  backIcon_edit: {
    width: mobileW * 5.5/ 100,
    height: mobileW *5.5/ 100,
    tintColor: Colors.white_color,
    
  },
  SAME_Text:{ 
    width:mobileW*18/100, 
    fontSize: mobileW * 2.4/ 100, 
    textAlign: "center", 
    color: Colors.blackColor ,
   fontFamily:Font.FontMedium
  },
 
  backIcon_video: {
    width: mobileW * 7 / 100,
    height: mobileW * 7 / 100,
    backgroundColor: Colors.themecolor,
    borderRadius: mobileW * 3.5 / 100,
    tintColor: Colors.whiteColor,
  },
  edit_Icon: {
    width: mobileW * 7 / 100,
    height: mobileW * 7 / 100,
    tintColor: Colors.white_color,
    alignSelf: "center",
    marginHorizontal: mobileW * 3 / 100
  },
  share_icon: {
    width: mobileW * 4.5 / 100,
    height: mobileW * 4.5 / 100,
    tintColor: Colors.green_color,
    marginTop: mobileW * 1 / 100,
    tintColor: Colors.green

  },
  seeMoreText: {
    color: Colors.blackColor,
    fontSize: mobileW * 3.5 / 100,
    marginTop: mobileW * 1 / 100,
    color: Colors.themecolor,
    fontWeight: '500'
  },
  edit_backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 8 / 100,
    tintColor: Colors.white_color,
    marginHorizontal: mobileW * 2 / 100
  },
  linkdinView: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    backgroundColor: Colors.white_color,
    alignItems: 'center',
    borderRadius: mobileW * 4 / 100,
    justifyContent: 'center'
  },
  learner_icon: {
    width: mobileW * 15 / 100,
    height: mobileW * 15 / 100,
    tintColor: Colors.themecolor,
    alignSelf: "center",
    borderWidth: mobileW * 0.25 / 100,
    borderColor: Colors.themecolor,
    borderRadius: mobileW * 10 / 100,
    marginTop: mobileW * -2 / 100
  },
  shareBtn: {
    backgroundColor: Colors.themecolor,
    width: mobileW * 28 / 100,
    height: mobileW * 8 / 100,
    borderRadius: mobileW * 1 / 100,
    justifyContent: "center",
    alignItems: "center"
  },
  MavenWhiteCard: {
    marginTop: mobileW * -3 / 100,
    backgroundColor: Colors.whiteColor,
    elevation: mobileW * 4 / 100,
    textAlign: "center",
    width: mobileW * 98 / 100,
    borderRadius: mobileW * 0 / 100,
    borderRadius: mobileW * 4 / 100
  },
  CardBlueHeader: {
    backgroundColor: Colors.themecolor,
    height: mobileW * 25 / 100,
    justifyContent: 'center',
    width: mobileW * 98 / 100,
    borderTopLeftRadius: mobileW * 3 / 100,
    borderTopRightRadius: mobileW * 3 / 100
  },
  learner_icon2: {
    width: mobileW * 15 / 100,
    height: mobileW * 15 / 100,
    tintColor: Colors.themecolor,
    alignSelf: "center",
    borderWidth: mobileW * 0.25 / 100,
    borderColor: Colors.themecolor,
    borderRadius: mobileW * 10 / 100,
    marginTop: mobileW * -2 / 100
  },
  customRatingBarStyle: {
    justifyContent: 'center',
    flexDirection: 'row',
    marginTop: 0,
  },
  imageCard: {
    width: mobileW * 18 / 100,
    height: mobileW * 18 / 100,
    borderRadius: mobileW * 10 / 100,
    borderWidth: mobileW * 0.6 / 100,
    borderColor: Colors.themecolor,
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageCard2: {
    width: mobileW * 25 / 100,
    height: mobileW * 25 / 100,
    borderRadius: mobileW * 15 / 100,
    marginLeft: mobileW * 5 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: mobileW * 5 / 100,
    marginTop: mobileW * -10 / 100,
    backgroundColor: Colors.white_color,
    elevation: mobileW * 2 / 100
  },
  imageIcon: {
    width: mobileW * 12 / 100,
    height: mobileW * 12 / 100,
    tintColor: Colors.themecolor,
    marginHorizontal: mobileW * 2 / 100
  },
  imageIcon2: {
    width: mobileW * 20 / 100,
    height: mobileW * 20 / 100,
    tintColor: Colors.themecolor,
    borderRadius: mobileW * 6 / 100
  },
  mavenImage: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    borderRadius: mobileW * 8 / 100,
    tintColor: Colors.themecolor
  },
  RatingBtn: {
    width: mobileW * 49 / 100,
    height: mobileW * 10 / 100,
    borderBottomLeftRadius: mobileW * 3 / 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  AboutMeBtn: {
    width: mobileW * 49 / 100,
    height: mobileW * 10 / 100,
    borderBottomRightRadius: mobileW * 3 / 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chackicon: {
    width: mobileW * 7 / 100,
    height: mobileW * 7 / 100,
    backgroundColor: Colors.themecolor,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: mobileW * 4 / 100
  },
  rattingCard: {
    backgroundColor: Colors.white_color,
    width: mobileW * 95 / 100,
    alignSelf: 'center',
    borderRadius: mobileW * 1 / 100,
    marginTop: mobileW * 2 / 100,
    padding: mobileW * 2 / 100,
    elevation: 1,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,

  },
  ModelHeader: {
    width: mobileW * 90 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 13 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  linkedinIconView:{ 
    width: mobileW * 5 / 100, 
    height: mobileW * 5 / 100, 
    backgroundColor: Colors.white_color, 
    alignItems: 'center', 
    borderRadius: mobileW * 4 / 100, 
    justifyContent: 'center' 
  },
  linkedinIcon:{ 
    width: mobileW * 3 / 100, 
    height: mobileW * 3 / 100, 
    backgroundColor: Colors.white_color, 
    tintColor: Colors.themecolor 
  },
  linkedin_Icon:{ 
    width: mobileW * 3 / 100, 
    height: mobileW * 3 / 100, 
    backgroundColor: Colors.white_color, 
    tintColor: Colors.themecolor,
  },
  faceBookicon: {
    width: mobileW * 5 / 100,
    marginHorizontal: mobileW * 3 / 100,
    height: mobileW * 5 / 100,
    backgroundColor: Colors.white_color,
    alignItems: 'center',
    borderRadius: mobileW * 4 / 100,
    justifyContent: 'center'
  },
  ModelCard: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 2 / 100,
    backgroundColor: Colors.white_color,
    elevation: 5
  },
  fullscreenVideo: {
    backgroundColor: 'black',
    ...StyleSheet.absoluteFill,
    elevation: 1
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  overlaySet: {
    flex: 1,
    flexDirection: 'row',
  },
  icon: {
    color: 'white',
    flex: 1,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: mobileW * 8 / 100
  },
  timer: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 5
  },
  skillmodalHeader: {
    backgroundColor: Colors.themecolor,
    height: mobileW * 12 / 100,
    alignItems: 'center',
    justifyContent: "center",
    borderTopLeftRadius: mobileW * 3 / 100,
    borderTopRightRadius: mobileW * 3 / 100
  },
  skillmodalCard: {
    backgroundColor: Colors.whiteColor,
    elevation: mobileW * 3 / 100,
    padding: mobileW * 3 / 100,
    borderBottomRightRadius: mobileW * 3 / 100,
    borderBottomLeftRadius: mobileW * 3 / 100,
  },
  chatBtn: {
    backgroundColor: Colors.themecolor,
    width: mobileW * 17 / 100,
    height: mobileW * 7 / 100,
    borderRadius: mobileW * 1 / 100,
    alignItems: "center",
    justifyContent: "center"
  },
})
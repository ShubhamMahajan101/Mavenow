import { Modal, Alert, ScrollView, TextInput, StatusBar, Animated, FlatList, RefreshControl, View, Text, Dimensions, TouchableOpacity, Image, StyleSheet } from 'react-native'
import React, { useState, useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors, Font } from './Provider/Colorsfont';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import { localStorage } from './Provider/localStorageProvider';
import axios from 'axios';
import moment from 'moment';
import { log } from 'react-native-reanimated';
import { getDate, set } from 'date-fns';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

export default function MyLearners({ navigation }) {
  const [checked, setChecked] = useState('Current')
  const [show, setShow] = useState('Add')
  const [modalVisible, setModalVisible] = useState(false);
  const [oldData, setOldData] = useState('')
  const [CurrentData, setCurrentData] = useState('')
  const [Searchtext, setSearchtext] = useState('')
  const [CurrentDataForSearch, setCurrentDataForSearch] = useState('')
  const [OldDataForSearch, setOldDataForSearch] = useState('')
  const [refresh, setrefresh] = useState(false)
  const [userMode, setuserMode] = useState();

  const _onRefresh = async () => {
    console.log('_onRefresh', '_onRefresh')
    setrefresh(true)
    setTimeout(() => {
      setrefresh(false)
    }, 1000);
  }

  useEffect(() => {
    apiCalling();
    SetMode();
    // recommendedApi();
  }, [])

  const SetMode = async (data) => {

    const value = await localStorage.getItemString('UserMode')
    console.log("..........", value);
    setuserMode(value)
  }

  const apiCalling = () => {
    axios.post('https://mavenow.com:8001/user/discipleOrMaster?userId=848&for=disciple&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI', {
      "currentdate": "21/02/2022"
    })
      .then(function (data) {
        var GetData = data.data.result
        console.log('-------- discipleOrMaster >', GetData)
        var ErrorMessage = data.data.ErrorMessage
        console.log("data ------------------------------->", ErrorMessage)
        console.log('Current Data------------>', GetData.current);
        console.log('Old Data------------------->', GetData.old);
        
        var olddataa = GetData.old
        for(let i=0; i<olddataa.length; i++){
          console.log('Old Daa Classes ------------------->', olddataa[i].classes);
           }

        setCurrentData(GetData.current)
        setOldData(GetData.old)

      


        setCurrentDataForSearch(GetData.current)
        setOldDataForSearch(GetData.old)

      })
      .catch(function (error) {
        console.log('======>', error);
      });
  }

  //--------function for subject local search-------//

  const _searchLearner = (textToSearch) => {
    var textToSearch = textToSearch.toString().toLowerCase();
    let data1 = OldDataForSearch
    if (data1 != 'NA') {
      console.log('data1', data1);
      if (data1 != 'NA') {
        var text_data = textToSearch.trim();
        let newData = data1.filter(function (item) {
          // var name = item.fullname 
          if (checked == 'Current') {
            var name = item.fullname
          } else {
            var name = item.fullname
          }
          return (
            name.toString().toLowerCase().indexOf(text_data) >= 0
          )
        });

        if (newData.length > 0) {
          setOldData(newData)
        } else if (newData.length <= 0) {
          setOldData('')
        }
      }
    }
  }

  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>

        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor}/>
        



        <View style={styles.Header}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()} style={{ marginHorizontal: mobileW * 2 / 100 }} >
              <Image style={styles.backIcon_} resizeMode='contain'
                source={require("./Icon/bk.png")}></Image>
            </TouchableOpacity>
            <Text style={{ color: Colors.white_color, fontWeight: '500', fontSize: mobileW * 5 / 100, marginHorizontal: mobileW * 5 / 100 }}>{userMode == 'maven' ?Lang_chg.MyLearnerTxt[config.language]   : Lang_chg.MyMavenTxt[config.language]  }</Text>

            {/* <Text style={{ color: Colors.white_color,fontSize: mobileW * 4.5 / 100, marginHorizontal:mobileW*4.5/100,fontFamily:Font.FontMedium }}>{userMode == 'maven' ? "My Learner(s)" : "My Maven(s)"}</Text> */}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', }}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('search')} style={{}} >
              <Image style={styles.SearchIcon} resizeMode='contain' 
                source={require("./Icon/icon_search.png")}></Image>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginHorizontal: mobileW * 4 / 100 }}  >
              <Image style={styles.SearchIcon} resizeMode='contain'
                source={require("./Icon/icon_info.png")}></Image>
            </TouchableOpacity>
          </View>
        </View>
        {/* =================================================================Model================================================================ */}
        <View  >
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
          >
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' }}>
              <View style={styles.ModelCard}>
                <View style={styles.ModelHeader}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}>      Help:My Learner(s)</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 4 / 100 }} >
                    <Image style={styles.backIcon} resizeMode='contain'
                      source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                </View>

                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>
                    <Text style={{ color: Colors.gray, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </Text>
                  </View>
                </ScrollView>

              </View>
            </View>
          </Modal>
        </View>
        {show != 'Add' &&
          <View style={{ width: mobileW, height: mobileW * 12 / 100, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.themecolor }}>
            <View style={{ backgroundColor: Colors.white_color, width: mobileW * 95 / 100, flexDirection: 'row', borderRadius: mobileW * 1 / 100, alignItems: 'center' }}>
              <TextInput
                style={styles.searchInput}
                // onChangeText={text => setSearchtext(text)}
                onChangeText={(txt) => _searchLearner(txt)}
                placeholder={Lang_chg.search[config.language]}
                placeholderTextColor={Colors.gray}
              />
              <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('Add')}>
                <Image resizeMode='contain' style={{ width: mobileW * 6 / 100, height: mobileW * 6 / 100, borderRadius: mobileW * 2 / 100, tintColor: Colors.themecolor }}
                  source={require('./Icon/close2.png')}></Image>
              </TouchableOpacity>
            </View>
          </View>}

        <View style={{ backgroundColor: Colors.themecolor, flexDirection: 'row', justifyContent: 'center' }}>
          <TouchableOpacity activeOpacity={0.8} onPress={() => setChecked('Current')} style={[{ backgroundColor: checked === 'Current' ? Colors.white_color : Colors.themecolor }, styles.CurrentLearner]} >
            <Text style={{ color: checked === 'Current' ? Colors.themecolor : Colors.white_color, fontSize: mobileW * 3/ 100, fontFamily:Font.FontSemiBold }}>{userMode == 'maven' ?Lang_chg.CurrentLearnerTxt[config.language]  :Lang_chg.CurrentMavenTxt[config.language] }</Text>
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={0.8} onPress={() => setChecked('Old')} style={[{ backgroundColor: checked === 'Old' ? Colors.white_color : Colors.themecolor }, styles.CurrentLearner]} >
            <Text style={{ color: checked === 'Old' ? Colors.themecolor : Colors.white_color, fontSize: mobileW *3 / 100, fontFamily:Font.FontSemiBold }}>{userMode == 'maven' ?Lang_chg.OldLearnerTxt[config.language] :Lang_chg.OldMavenTxt[config.language] }</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={{ marginVertical: mobileW * 5 / 100 }}
          refreshControl={
            <RefreshControl
              refreshing={refresh}
              onRefresh={_onRefresh}
              tintColor={Colors.themecolor}
              colors={[Colors.themecolor]}
            />
          }>
          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Current Data +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/}

          {checked == 'Current' &&
            <View>
              {CurrentData != '' ?
                <FlatList
                  data={CurrentData}
                  renderItem={({ item, index }) =>
                    <View style={styles.flatlistCard}>
                      <TouchableOpacity
                        activeOpacity={0.8}
                        onPress={() => navigation.navigate('LearnersDetail')}
                        style={{ flexDirection: 'row', paddingTop: mobileW * 6 / 100, }}>
                        <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100, }}>
                          <View style={styles.imageCard}>
                            <Image resizeMode='contain' style={styles.mavenImage}
                              source={item.profileImage}></Image>
                          </View>
                          <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color, fontWeight: '400', }}>{item.fullname} </Text>

                        </View>
                        <View style={{ width: mobileW * 72 / 100, }}>
                          <FlatList
                            // data={checked=='Current'? DATA:DATA1 }
                            data={item.classes}
                            renderItem={({ item, index }) =>
                              <View>
                                <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color }}>{item.skill} (Basic)</Text>
                                <View style={{ flexDirection: 'row' }}>
                                  <View style={{ width: mobileW * 36 / 100, }}>
                                    <View style={{ marginTop: mobileW * 2 / 100 }} >
                                      <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>Start Date</Text>
                                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}>{item.StartDate}</Text>
                                    </View>
                                    <View style={{ marginTop: mobileW * 2 / 100 }} >
                                      <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}> End Date</Text>
                                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}>{item.Enddate}</Text>
                                    </View>
                                  </View>
                                  <View style={{ width: mobileW * 36 / 100, }}>
                                    <View style={{ marginTop: mobileW * 2 / 100 }} >
                                      <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.gray }}>Fee</Text>
                                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.themecolor }}>{item.charges}</Text>
                                    </View>
                                    <View style={{ marginTop: mobileW * 2 / 100 }} >
                                      <Text style={{ fontSize: mobileW * 3 / 100, color: "#777" }}>Payment Status</Text>
                                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}>{item.status}</Text>
                                    </View>
                                  </View>
                                </View>

                                <View style={styles.underLine}></View>

                              </View>
                            } />
                        </View>
                      </TouchableOpacity>
                    </View>
                  }
                  keyExtractor={item => item.id} />
                :
                <View style={{ mobileH: mobileH, mobileW: mobileW, justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.blackColor, marginTop: mobileW * 20 / 100,fontFamily:Font.FontSemiBold }}>{Lang_chg.notMavenTxt[config.language]}</Text>

                </View>
              }
            </View>
          }

          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ Old Data +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/}
          {checked === 'Old' &&

            <View>
              {oldData != '' ?
                <FlatList
                  // data={checked=='Current'? DATA:DATA1 }   
                  data={oldData}
                  renderItem={({ item, index }) =>
                  {
                    const classesData =  item.classes ;
                    return (
                    <View style={styles.flatlistCard}>
                      <TouchableOpacity activeOpacity={0.4} onPress={() => navigation.navigate('LearnersDetail', { item: item })}
                        style={{ flexDirection: 'row', paddingTop: mobileW * 6 / 100, }}>
                        <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100, }}>
                          <View style={styles.imageCard}>
                            <Image resizeMode='contain' style={styles.mavenImage}
                              source={item.profileImage != null ? require("./Icon/icon_student.png") : item.profileImage}></Image>
                          </View>
                          <Text style={{ fontSize: mobileW * 3.5 / 100, marginTop: mobileW * 1 / 100, color: Colors.black_color, fontWeight: '500' }}>{item.fullname} </Text>
                        </View>

                        <View style={{ width: mobileW * 72 / 100, }}>
                          <FlatList
                            data={classesData}
                            renderItem={({ item, index }) => {
                              const ArrayLength =   classesData.length ;
                              return (
                                <View >
                                  <Text style={{ fontSize: mobileW * 3.8 / 100, color: Colors.black_color, marginTop: mobileW * 2 / 100 }}
                                  >{item.skill} (Basic)</Text>
                                  <View style={{ flexDirection: 'row', paddingBottom: mobileW * 5 / 100 }}>
                                    <View style={{ width: mobileW * 36 / 100, }}>
                                      <View style={{ marginTop: mobileW * 2 / 100 }} >
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: "#777" }}>{Lang_chg.StartDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}
                                        >{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                                      </View>
                                      <View style={{ marginTop: mobileW * 2 / 100 }} >
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: "#777" }}>{Lang_chg.EndDateTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}
                                        >{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                                      </View>
                                    </View>
                                    <View style={{ width: mobileW * 36 / 100, }}>
                                      <View style={{ marginTop: mobileW * 2 / 100, marginHorizontal: mobileW * 2 / 100 }}>
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: "#777" }}>{Lang_chg.FeeTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.themecolor }}>Rs : {item.charges}</Text>
                                      </View>
                                      <View style={{ marginTop: mobileW * 2 / 100 }} >
                                        <Text style={{ fontSize: mobileW * 3 / 100, color: "#777" }}>{Lang_chg.PaymentStatusTxt[config.language]}</Text>
                                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.black_color }}>{Lang_chg.PaymentStatusTxt[config.language]}</Text>
                                      </View>
                                    </View>
                                  </View>
                                      { 
                                       ArrayLength > 1 &&
                                        <View style={styles.underLine}></View> 
                                       }
                                          

                                  {/* {index == 0 ? null :
                                    <View>
                                      {index != 0 ?
                                        <View style={styles.underLine}></View> : null}
                                    </View>} */}

                                </View>
                              )
                            }} />
                        </View>
                      </TouchableOpacity>
                    </View>)}
                  }
                  keyExtractor={item => item.id} />
                :
                <View style={{ mobileH: mobileH, mobileW: mobileW, justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ fontSize: mobileW * 4.5 / 100,fontFamily:Font.FontMedium, color: Colors.blackColor, marginTop: mobileW * 20 / 100 }}> {userMode == 'maven' ? "You do not have rave any Learner." : "You do not have rave any Maven."}</Text>
                 
                </View>}
            </View>
          }
        </ScrollView>
      </SafeAreaView>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 13/ 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  backIcon_: {
    width: mobileW * 9.5/ 100,
    height: mobileW * 9.5 / 100,
    tintColor: Colors.white_color
  },
  SearchIcon: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    tintColor: Colors.white_color
  },
  searchInput: {
    width: mobileW * 85 / 100,
    borderRadius: mobileW * 1 / 100,
    color: Colors.gray,
    height: mobileW * 10 / 100,
    backgroundColor: Colors.white_color,
    fontSize: mobileW * 4 / 100,
    color: Colors.blackColor
  },
  flatlistCard: {
    width: mobileW * 96 / 100,
    alignSelf: 'center',
    marginTop: mobileW * 1 / 100,
    marginBottom: mobileW * 2 / 100,
    paddingBottom: mobileW * 2 / 100,
    borderRadius: mobileW * 2 / 100,
    backgroundColor: Colors.white_color,
    elevation: 2,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
  },
  underLine: {
    width: mobileW * 70 / 100,
    height: mobileW * 0.3 / 100,
    backgroundColor: Colors.themecolor
  },
  imageCard: {
    width: mobileW * 18 / 100,
    height: mobileW * 18 / 100,
    borderRadius: mobileW * 10 / 100,
    borderWidth: mobileW * 0.6 / 100,
    borderColor: Colors.themecolor,
    alignItems: 'center',
    justifyContent: 'center'
  },
  mavenImage: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    borderRadius: mobileW * 7 / 100,
    tintColor: Colors.themecolor
  },
  ModelCard: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 3 / 100,
    backgroundColor: Colors.white_color,
    elevation: 5
  },
  ModelHeader: {
    width: mobileW * 90 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 15 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  CurrentLearner: {
    width: mobileW * 47 / 100,
    height: mobileW * 10 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    justifyContent: 'center',
    alignItems: 'center'
  }
})
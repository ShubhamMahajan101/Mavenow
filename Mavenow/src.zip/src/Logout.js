import { View, Text } from 'react-native'
import React from 'react'

export default function Logout() {
  return (
    <View>
      <Text>Logout</Text>
    </View>
  )
}
const COLORS={
  
Red:"#FF0000",
Cyan:"#00FFFF",
Blue:"#0000FF",



}
export default COLORS;
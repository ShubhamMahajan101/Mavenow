import {  StatusBar, Modal, Alert, ScrollView, TextInput, FlatList, View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, RefreshControl } from 'react-native'
import React, { useState, useEffect } from 'react'
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors, Font } from './Provider/Colorsfont';
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from 'axios';
import moment from 'moment';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

const ActiveDATA = [
    {
        id: 1,
        image: require('./Icon/icon_maven.png'),
        name: 'cvv',
        request: 'Learning',
        skills: 'Automation testing',
        startdate: 'Dec 07, 2022',
        level: 'Basic',
        enddate: 'Dec 09, 2022',
        postdate: 'Dec 06, 2022',
        Language: 'PHP',
        fee: '',
        status: 'Request From Learner',
        // selected:false
    },
    {
        id: 1,
        image: require('./Icon/icon_maven.png'),
        name: 'cvv',
        request: 'Learning',
        skills: 'Automation testing',
        startdate: 'Dec 07,2022',
        level: 'Basic',
        enddate: 'Dec 09, 2022',
        postdate: 'Dec 06, 2022',
        Language: 'PHP',
        fee: '',
        status: 'Request From Learner',
        // selected:false
    },
    {
        id: 1,
        image: require('./Icon/icon_maven.png'),
        name: 'cvv',
        request: 'Learning',
        skills: 'Automation testing',
        startdate: 'Dec 07,2022',
        level: 'Basic',
        enddate: 'Dec 09, 2022',
        postdate: 'Dec 06, 2022',
        Language: 'PHP',
        fee: '',
        status: 'Request From Learner',
        // selected:false
    },
    {
        id: 1,
        image: require('./Icon/icon_maven.png'),
        name: 'cvv',
        request: 'Learning',
        skills: 'Automation testing',
        startdate: 'Dec 07, 2022',
        level: 'Basic',
        enddate: 'Dec 09, 2022',
        postdate: 'Dec 06, 2022',
        Language: 'PHP',
        fee: '',
        status: 'Request From Learner',
        // selected:false
    },
    {
        id: 1,
        image: require('./Icon/icon_maven.png'),
        name: 'cvv',
        request: 'Learning',
        skills: 'Automation testing',
        startdate: 'Dec 07, 2022',
        level: 'Basic',
        enddate: 'Dec 09, 2022',
        postdate: 'Dec 06, 2022',
        Language: 'PHP',
        fee: '',
        status: 'Request From Learner',
        // selected:false
    },
]

export default function History({ navigation }) {
    const [modalVisible, setModalVisible] = useState(false);
    const [timePicker, setTimePicker] = useState(false);
    const [endtimePicker, setendTimePicker] = useState(false);
    const [date, setdate] = useState(Lang_chg.StartDateTxt[config.language]);
    const [enddate, setenddate] = useState(Lang_chg.EndDateTxt[config.language]);
    const [refresh, setrefresh] = useState(false)


    // -------------------->> refresh
    const refresh_Control = () => {
        setrefresh(true)
        setTimeout(() => {
            setrefresh(false)

        }, 1200);

    }
    // -------------------->> refresh

    const setDatetoFunction = (date) => {
        setTimePicker(false)
        setTimeout(() => {
            console.log(timePicker);
        }, 500);

        var formateDate = date.nativeEvent.timestamp

        let newDate = moment(new Date(formateDate)).format('DD/MM/YYYY')

        setdate(newDate)

        console.log('date is here--------->>>>>>', newDate);
    }
    const setendDatetoFunction = (date1) => {
        setendTimePicker(false)
        setTimeout(() => {
            console.log(endtimePicker);
        }, 500);

        var formateDate = date1.nativeEvent.timestamp

        let newDate = moment(new Date(formateDate)).format('DD/MM/YYYY')

        setenddate(newDate)

        console.log('date is here--------->>>>>>', newDate);
    }


    useEffect(() => {
        apiCalling();

    }, [])

    const apiCalling = () => {
        axios.get('https://mavenow.com:8001/userrequest/history?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NDIxMzE2Nn0.ASnHQya29LrSAqN6ff2DCam56LZRA_71X2oM6JUyJM8&fromdate=2022-12-20T18:30:00.000Z&todate=2022-12-29T18:29:00.000Z', {
            "isactive": 1
        })
            .then(function (data) {
                var GetData = data.data
                //   console.log('jsdsssss',GetData);

                if (GetData.StatusCode == 200) {
                    var GetData1 = GetData.result
                    console.log("result data", GetData1);
                    var DataToSet = GetData.response
                    console.log('All response ==>', DataToSet);

                } else {
                    console.log("I am in nor found")
                }

                //   console.log("dfdfsfs",GetData);

            })
            .catch(function (error) {
                console.log('======>', error);
            });
    }

    return (
        <View style={{ flex: 1, }}>
            <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
                <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
                {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
                <View style={styles.Header}>
                    {/* <View style={{ flexDirection: 'row', alignItems: 'center' }}> */}
                    <TouchableOpacity style={{marginHorizontal:mobileW*2/100}} activeOpacity={0.8} onPress={() => navigation.goBack()}  >
                        <Image style={styles.backIcon_} resizeMode='contain'
                            source={require("./Icon/bk.png")}></Image>
                    </TouchableOpacity>
                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 4.5 / 100, marginHorizontal:mobileW*4.5/100,fontFamily:Font.FontMedium }}>{Lang_chg.HistoryTxt[config.language]}</Text>
                    {/* </View> */}

                </View>

                <ScrollView
                    refreshControl={
                        <RefreshControl
                            refreshing={refresh}
                            onRefresh={refresh_Control}
                            tintColor={Colors.themecolor}
                            colors={[Colors.themecolor]}
                        />
                    }>
                    <View style={{ marginBottom: mobileW * 5 / 100 }}>
                        <FlatList
                            data={ActiveDATA}
                            renderItem={({ item, index }) =>
                                <TouchableOpacity activeOpacity={0.8} style={styles.flatlistCard}>
                                    <View style={{ flexDirection: 'row', }}>
                                        <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100 }}>
                                            <View style={styles.imageCard}>
                                                <Image resizeMode='contain' style={styles.mavenImage}
                                                    source={item.image}></Image>
                                            </View>
                                            {/* <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color }}>{item.name} </Text> */}
                                            <Text style={{ fontSize: mobileW * 3/ 100, color: Colors.black_color,  }}>vinay Dexit </Text>
                                            <Text style={{ fontSize: mobileW * 3/ 100, color: Colors.black_color,marginTop:mobileW*0.5/100 }}>(Maven)</Text>
                                        </View>

                                        <View style={{ width: mobileW * 24 / 100, marginTop: mobileW * 1.10 / 100 }}>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.RequestTxt[config.language]}</Text>
                                                <Text style={styles.Dynamic_text}>{item.request}</Text>
                                            </View>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.SkillsTxt[config.language]}</Text>
                                                <Text numberOfLines={2} style={{ fontSize: mobileW * 3 / 100, color: Colors.gray, width: mobileW * 22 / 100 }}>{item.skills}</Text>
                                            </View>
                                        </View>
                                        <View style={{ width: mobileW * 24 / 100, marginTop: mobileW * 1.10 / 100 }}>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.StartDateTxt[config.language]}</Text>
                                                <Text style={styles.Dynamic_text}>{item.startdate}</Text>
                                            </View>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.LevelTxt[config.language]}</Text>
                                                <Text style={styles.Dynamic_text}>{item.level}</Text>
                                            </View>
                                        </View>
                                        <View style={{ width: mobileW * 24 / 100, marginTop: mobileW * 1.10 / 100 }}>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.EndDateTxt[config.language]}</Text>
                                                <Text style={styles.Dynamic_text}>{item.enddate}</Text>
                                            </View>
                                            <View style={{ marginTop: mobileW * 2 / 100 }} >
                                                <Text style={styles.request_text}>{Lang_chg.PostdateTxt[config.language]}</Text>
                                                <Text style={styles.Dynamic_text}>{item.postdate}</Text>
                                            </View>
                                        </View>
                                    </View>



                                    <View style={styles.flatlistFootar}>
                                        <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.white_color }}>{item.fee}</Text>
                                        <Text style={{ fontSize: mobileW * 3.4/ 100, color: Colors.white_color ,fontWeight:'400'}}>{Lang_chg.studentstatusTxt[config.language]}{}</Text>
                                    </View>
                                </TouchableOpacity>
                            }
                            keyExtractor={item => item.id} />
                    </View>
                </ScrollView>
                {/* ================================================================= Time Duration Model================================================== */}
                <View  >
                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modalVisible}
                        onRequestClose={() => {
                            Alert.alert("Modal has been closed.");
                            setModalVisible(!modalVisible);
                        }}
                    >
                        <View style={{ flex: 1, backgroundColor: '#00000090', alignItems:'center', justifyContent:'center' }}>
                            <View style={styles.ModelCard}>
                                <View style={styles.ModelHeader}>
                                    <Text style={{ color: Colors.white_color, fontSize: mobileW * 3.5/ 100, fontWeight: '500' }}>{Lang_chg.SelectDateTxt[config.language]}</Text>
                                </View>
                                <ScrollView>
                                    <View style={{ alignItems: 'center',  paddingBottom:mobileW*2/100}}>

                                        {/* =================================================== Date / Time ================================================================ */}

                                        <View style={{ flexDirection: 'row' }}>

                                            {timePicker && (                                                                   //Date Picker
                                                <DateTimePicker
                                                    mode={'date'}
                                                    value={new Date(Date.now())}
                                                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                                    is24Hour={false}
                                                    onChange={text => setDatetoFunction(text)}
                                                />
                                            )}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setTimePicker(true)} style={styles.CalanderView}>
                                                <Image resizeMode='contain' style={styles.iconQuestionMark}
                                                    source={require('./Icon/icon_calendar.png')}></Image>
                                                <Text style={styles.calanderText}>{date}</Text>
                                            </TouchableOpacity>

                                            {endtimePicker && (                                                                   //Date Picker
                                                <DateTimePicker
                                                    mode={'date'}
                                                    value={new Date(Date.now())}
                                                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                                    is24Hour={false}
                                                    onChange={text => setendDatetoFunction(text)}
                                                />
                                            )}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setendTimePicker(true)} style={styles.CalanderView}>
                                                <Image resizeMode='contain' style={styles.iconQuestionMark}
                                                    source={require('./Icon/icon_calendar.png')}></Image>
                                                <Text style={styles.calanderText}>{enddate}</Text>
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ flexDirection: 'row', marginTop: mobileW * 3 / 100 }}>
                                            <TouchableOpacity onPress={() => setModalVisible(!modalVisible)} activeOpacity={0.8} style={styles.CancleButton}>
                                                <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.white_color, fontWeight: '500' }}>{Lang_chg.CancelTxt[config.language]}</Text>
                                            </TouchableOpacity>
                                            <TouchableOpacity activeOpacity={0.8} style={styles.CancleButton}  onPress={() => setModalVisible(!modalVisible)} >
                                                <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.white_color, fontWeight: '500' }}>{Lang_chg.OkTxt[config.language]}</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </ScrollView>
                            </View>
                        </View>
                    </Modal>
                </View>
                <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginRight: mobileW * 5 / 100 }}>
                    <View style={styles.Button}>
                        <Image resizeMode='contain' style={styles.Bottom_Image}
                            source={require('./Icon/history_modal.png')}></Image>
                    </View>
                </TouchableOpacity>
            </SafeAreaView>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        // backgroundColor:"red"
    },
    Header: {
        backgroundColor: Colors.themecolor,
        width: mobileW, 
        height: mobileW * 13 / 100,
        flexDirection: 'row',
        alignItems: 'center',
    },
    backIcon: {
        width: mobileW * 6 / 100,
        height: mobileW * 6 / 100,
        tintColor: Colors.white_color
    },
    backIcon_: {
        width: mobileW * 9.5/ 100,
        height: mobileW * 9.5/ 100,
        tintColor: Colors.white_color
    },
    flatlistCard: {
        width: mobileW * 96 / 100,
        alignSelf: 'center',
        marginTop: mobileW * 3 / 100,
        borderRadius: mobileW * 2 / 100,
        backgroundColor: Colors.white_color,
        // backgroundColor:'green',
        elevation: 5,
        shadowColor: '#000',
        borderColor: "#e8edfb",
        // borderWidth: 1,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, },
        // shadowColor: '#000',
        shadowOpacity: 0.1,
    },
    imageCard: {
        width: mobileW * 16 / 100,
        height: mobileW * 16 / 100,
        borderRadius: mobileW * 10 / 100,
        borderWidth: mobileW * 0.6 / 100,
        borderColor: Colors.themecolor,
        alignItems: 'center',
        justifyContent: 'center'
    },
    mavenImage: {
        width: mobileW * 12/ 100,
        height: mobileW * 12 / 100,
        borderRadius: mobileW * 2 / 100,
        tintColor: Colors.themecolor
    },
    flatlistFootar: {
        width: mobileW * 96 / 100,
        flexDirection: 'row',
        alignItems: 'center',
        padding: mobileW * 1.8 / 100,
        justifyContent: 'space-between',
        borderBottomLeftRadius: mobileW * 2 / 100,
        borderBottomRightRadius: mobileW * 2 / 100,
        backgroundColor: Colors.themecolor,
        marginTop: mobileW * 5 / 100
    },
    ModelCard: {
        width: mobileW * 85 / 100,
        borderRadius: mobileW * 3 / 100,
        backgroundColor: Colors.white_color,
        elevation: 5
    },
    ModelHeader: {
        width: mobileW * 85 / 100,
        justifyContent: 'center',
        alignItems: 'center',
        height: mobileW * 12 / 100,
        borderTopLeftRadius: mobileW * 2 / 100,
        borderTopRightRadius: mobileW * 2 / 100,
        backgroundColor: Colors.themecolor
    },
    CalanderView: {
        width: mobileW * 38 / 100,
        marginHorizontal: mobileW * 2 / 100,
        height: mobileW * 13.5/ 100,
        marginTop: mobileW * 3 / 100,
        borderRadius: mobileW * 1.5 / 100,
        padding: mobileW * 2 / 100,
        borderWidth: mobileW * 0.3/ 100,
        borderColor:"#9f9f9f",
        flexDirection: 'row',
        alignItems: 'center'
    },
    calanderText: {
        color:"#777",
        alignSelf: 'center',
        fontSize: mobileW * 3.4/ 100,
        fontWeight: '400',
        marginHorizontal: mobileW * 2 / 100
    },
    sessionDuration: {
        color: Colors.gray,
        // alignSelf:'center', 
        fontSize: mobileW * 5 / 100,
        fontWeight: '500',
        marginHorizontal: mobileW * 2 / 100
    },
    iconQuestionMark: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        tintColor: Colors.gray
    },
    Button: {
        width: mobileW * 15 / 100,
        height: mobileW * 15 / 100,
        backgroundColor: Colors.themecolor,
        position: 'absolute',
        bottom: mobileW * 10 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: mobileW * 10 / 100,
        alignSelf: 'flex-end'
    },
    CancleButton: {
        width: mobileW * 23 / 100,
        height: mobileW * 7 / 100,
        marginHorizontal: mobileW * 2 / 100,
        borderRadius: mobileW * 2 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.themecolor
    },
     request_text:{
         fontSize: mobileW * 3 / 100, 
         color: Colors.black_color, 
    //  fontFamily:Font.FontExtraBold
            // fontWeight: "400"
    
         },
         Dynamic_text:{
         fontSize: mobileW * 3/ 100, 
         color: "#777",
         marginTop:mobileW*0.6/100
         },
         Bottom_Image:{
             width: mobileW * 8 / 100, 
            height: mobileW * 8 / 100, 
            tintColor: Colors.white_color
             }
        
   
})
// rnf
import { View, Text } from 'react-native'
import React from 'react'

export default function note() {
  return (
    <View>
      <Text>note</Text>
    </View>
  )
}
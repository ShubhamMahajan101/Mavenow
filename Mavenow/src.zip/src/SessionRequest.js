import {  StatusBar, Modal, Alert, ScrollView, TextInput, FlatList, View, Text, Dimensions, TouchableOpacity, Image, StyleSheet, RefreshControl } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Colors, Font } from './Provider/Colorsfont';
import { localStorage } from './Provider/localStorageProvider';
import { config, msgProvider, msgText, consolepro, Lang_chg,   msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';

import axios from 'axios';
import moment from 'moment';
import { SafeAreaView } from 'react-native-safe-area-context'
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

export default function SessionRequest({ navigation }) {
  const [checked, setChecked] = useState('Active')
  const [show, setShow] = useState('Add')
  const [number, onChangeNumber] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const [active, setActived] = useState('');
  const [scheduled, setScheduled] = useState('');
  const [completed, setCompleted] = useState('');
  const [refresh, setrefresh] = useState(false)
  const [userMode, setuserMode] = useState();
  const [activeForSearch, setActiveForSearch] = useState([]);
  const [scheduledForSearch, setScheduleForSearch] = useState([]);
  const [completedForSearch, setCompletedForSearch] = useState([]);

  useEffect(() => {
    CompletedData();
    ScheduledDATA();
    ActiveDATA();
    SetMode();
  }, [])

     const SetMode = async (data) => {
     const value = await localStorage.getItemString('UserMode')
     console.log("..........", value);
     setuserMode(value)
 }

  const ActiveDATA = () => {
    axios.post('https://mavenow.com:8001/userrequest/AppliedRequets?userId=848&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NzQ5NTc5Nn0.hp75g4O_N7R7MVkAyeWYiMlfglGAXP5Sl9pGohbPUYY', {
      "currentDate": "2022-12-24 18:29:00",
      "typeofrequest": 1
    })
      .then(function (data) {
        var GetData = data.data.result
        setActived(GetData)
        setActiveForSearch(GetData)
      })
      .catch(function (error) {
        console.log('======>', error);
      });
  }

  const ScheduledDATA = () => {
    axios.post('https://mavenow.com:8001/userrequest/ProcessRequets?userId=848&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NzQ5NTc5Nn0.hp75g4O_N7R7MVkAyeWYiMlfglGAXP5Sl9pGohbPUYY', {
      "currentDate": "2022-12-24 18:29:00",
      "typeofrequest": 1
    })
      .then(function (data) {
        var GetData = data.data.result
        setScheduled(GetData)
        setScheduleForSearch(GetData)
      })
      .catch(function (error) {
        console.log('======>', error);
      });
  }

  const CompletedData = () => {
    axios.post('https://mavenow.com:8001/userrequest/CompleteRequest?userId=848&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoicGF0aGFrZzg3NkBnbWFpbC5jb20iLCJ1c2VyX0lkIjo5MDksImlhdCI6MTY3NzQ5NTc5Nn0.hp75g4O_N7R7MVkAyeWYiMlfglGAXP5Sl9pGohbPUYY', {
      "currentDate": "2022-12-24 18:29:00",
      "typeofrequest": 1
    })
      .then(function (data) {
        var GetData = data.data.result
        setCompleted(GetData)
        setCompletedForSearch(GetData)
        console.log('Completed API ========= >', GetData)
      })
      .catch(function (error) {
        console.log('======>', error);
      });
  }
  // -----------------------------------------------------------------
  const _searchLearner = (textToSearch) => {
    console.log('textToSearch---------',textToSearch);
    var textToSearch = textToSearch.toString().toLowerCase();
    if (checked == 'Active') {
      var data1 = active
    } else if (checked == 'Scheduled') {
      var data1 = scheduled
    } else if (checked == 'Completed') {
      var data1 = completed
    }
  var data1=completedForSearch
    if (data1 != 'NA') {
      console.log('data1', data1);
      if (data1 != 'NA') {
        var text_data = textToSearch.trim();
        let newData = data1.filter(function (item) {
          var name = item.userDetail.FirstName
          return (
            // name.toString().toLowerCase().indexOf(text_data) >- 1
            name.toString().toLowerCase().indexOf(text_data) >= 0
          )
        });
 
        console.log('newData-------',newData);
        if (checked == 'Active') {
          if (newData.length > 0) {
            setActived(newData)
          } else if (newData.length <= 0) {
            setActived('')
          }
        } else if (checked == 'Scheduled') {
          if (newData.length > 0) {
            setScheduled(newData)
          } else if (newData.length <= 0) {
            setScheduled('')
          }
        } else if (checked == 'Completed') {
          if (newData.length > 0) {
            setCompleted(newData)
          } else if (newData.length <= 0) {
            // name.toString().toLowerCase().indexOf(text_data) >= 0
            setCompleted('')
          }
        }
      }
    }
  }


  // -------------------------- refresh --------------------
  const _onRefresh = async () => {
    console.log('_onRefresh', '_onRefresh')
    setrefresh(true)
    setTimeout(() => {
      setrefresh(false)
    }, 1200);
  }
  // -----------------------refresh-------------------

return (
        <View style={{ flex: 1, }}>
        <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.Header}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()} style={{ marginHorizontal: mobileW * 2 / 100 }} >
        <Image style={styles.backIcon_top} resizeMode='contain'source={require("./Icon/bk.png")}></Image>
        </TouchableOpacity>



        <Text style={{ color: Colors.white_color, fontSize: mobileW * 4.3 / 100 ,marginHorizontal:mobileW*1/100,fontFamily:Font.FontMedium}}>{userMode == 'maven' ? Lang_chg.sessionrequestTxt[config.language] :  Lang_chg.LearningRequestTxt[config.language] }     </Text>

        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('search')} style={{ marginHorizontal: mobileW * 2 / 100 }} >
        <Image style={styles.SearchIcon} resizeMode='contain'source={require("./Icon/icon_search.png")}></Image>
        </TouchableOpacity>
        <TouchableOpacity activeOpacity={0.8} onPress={() =>{userMode == 'maven' ? navigation.navigate('AddCourse'): navigation.navigate('Chatbots')}} style={{ marginHorizontal: mobileW * 2 / 100 }} >
        <Image style={styles.plusicon} resizeMode='contain'source={require("./Icon/plus.png")}></Image>
        </TouchableOpacity>
        <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginHorizontal: mobileW * 2 / 100 }}>
        <Image style={styles.SearchIcon} resizeMode='contain'source={require("./Icon/icon_info.png")}></Image>
        </TouchableOpacity>
        </View>
        </View>

        {/* =================================================================Model================================================================ */}
        <View  >
        <Modal animationType="slide"
        transparent={true} visible={modalVisible} onRequestClose={() => {
        setModalVisible(!modalVisible);
         }}>
                  <View style={{ flex: 1, backgroundColor: '#00000090' }}>
                  <View style={styles.Modal}>
                  <View style={styles.ModalHeader}>
                  <Text style={styles.HELP_TEXT}></Text>
                  <Text style={styles.HELP_TEXT}>         Help:Session Request(s)</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }}>
                  <Image style={styles.backIcon} resizeMode='contain' source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                  </View>
                  <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    <Text style={{ color: Colors.dark_gray, fontSize: mobileW * 3.6/ 100, fontFamily:Font.FontRegular }}>
                      Lorem Ipsum is simply dummy  text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,when an unknown printer took a galley {'\n'}of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960. {'\n'} with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </Text>
                  </View>
                 </ScrollView>
                 </View>
                 </View>
                 </Modal>
                 </View>

               {show != 'Add' &&
              <View style={styles.searchView}>
              <View style={styles.TextInputView}>
               <TextInput style={styles.TextInput} onChangeText={(txt) => _searchLearner(txt)}
                // value={number}
                placeholder={Lang_chg.SearchEngine[config.language]}
                placeholderTextColor={Colors.gray} />
               <TouchableOpacity activeOpacity={0.8} onPress={() => setShow('Add')}>
                <Image resizeMode='contain' style={styles.croseImage} source={require('./Icon/close2.png')}></Image>
                </TouchableOpacity>
                </View>
                 </View>}
              <View style={{ padding:mobileW * 2 / 100,}}>
              <View style={styles.buttonCard}>
             <TouchableOpacity activeOpacity={0.8} onPress={() => setChecked('Active')}style={[{ backgroundColor: checked === 'Active' ? Colors.themecolor : Colors.white_color, }, styles.activeButton]}>
             <Text style={{color: checked === 'Active' ? Colors.white_color : Colors.black_color, fontSize: mobileW * 3.1 / 100,fontFamily:Font.FontSemiBold}}>{Lang_chg.ActiveTxt[config.language]}</Text>
             </TouchableOpacity >
             <TouchableOpacity activeOpacity={0.8} onPress={() => setChecked('Scheduled')} style={[{ backgroundColor: checked === 'Scheduled' ? Colors.themecolor : Colors.white_color, }, styles.activeButton]}>
              <Text style={{color: checked === 'Scheduled' ? Colors.white_color : Colors.black_color, fontSize: mobileW * 3.1 / 100,fontFamily:Font.FontSemiBold}}>{Lang_chg.ScheduledTxt[config.language]}</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setChecked('Completed')}
              style={[{ backgroundColor: checked === 'Completed' ? Colors.themecolor : Colors.white_color }, styles.activeButton]}>
              <Text style={{color: checked === 'Completed' ? Colors.white_color : Colors.black_color, fontSize: mobileW * 3.1 / 100,fontFamily:Font.FontSemiBold }}>{Lang_chg.CompletedTxt[config.language]}</Text>
            </TouchableOpacity>
             </View>
             </View>

                              <ScrollView
                              refreshControl={
                              <RefreshControl
                               refreshing={refresh}
                              onRefresh={_onRefresh}
                              tintColor={Colors.themecolor}
                              colors={[Colors.themecolor]} /> }>

                        <View style={{ marginBottom: mobileW * 10 / 100 }}>
                          
                          {checked == 'Active' &&    
                               <View>    
                                {active!=""? <View>                  
                        <FlatList
                        data={active}
                        renderItem={({ item, index }) =>
                        <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('SessionRequestBasic', { Active: checked, item: item })} style={styles.flatlistCard}>
                       <View style={{ flexDirection: 'row' }}>
                        <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100 }}>
                         <View style={styles.imageCard}>
                         <Image resizeMode='contain' style={styles.mavenImage} source={item.userDetail.profileImage == '' ? require("./Icon/icon_maven.png") : { uri: item.userDetail.profileImage }}></Image>
                         </View>
                        <Text style={{ fontSize: mobileW * 3/ 100, color: Colors.black_color }}>{item.userDetail.FullName !=''?'[maven]':item.userDetail.FullName}</Text>
                         </View>
                         <View>
                         <View style={{ flexDirection:'row', marginTop:mobileW*3/100  }}>
                          <View style={{width: mobileW * 24 / 100, }} >
                            <Text style={styles.text_view}>Request:</Text>
                            <Text style={styles.appi_text}>{item.TypeOfRequest}</Text>
                              </View>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>Start Date</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                             </View>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>End Date</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                            </View>
                            </View>
                            <View style={{ flexDirection:'row', marginTop:mobileW*2/100 }}>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>Post date:</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.DateOfRequest)).format('MMM DD, YYYY')}</Text>
                            </View>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>Level</Text>
                            <Text style={styles.appi_text}>{item.skill_level}</Text>
                            </View>
                            </View>

                            <View style={{width: mobileW * 72 / 100,  marginTop:mobileW*2/100, }} >
                            <Text style={styles.text_view}>Skills</Text>
                            <Text style={styles.appi_text}>{item.Skills}</Text>
                            </View>
                            </View>
                       </View>
                      <View style={styles.flatlistFootar}>
                      <View style={{ flexDirection: 'row', paddingLeft: mobileW * 3 / 100, alignItems: 'center' }}>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.white_color }}>Fee {item.charges}</Text>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.white_color, }}> Rs</Text>
                      </View>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, color: item.requestagainreason != 'Student paid fee.' ? Colors.black_color : Colors.whiteColor, paddingRight: mobileW * 2 / 100 }}>{item.requestagainreason}</Text>
                      </View>
                      </TouchableOpacity>
                       }  keyExtractor={item => item.id} />
                          </View>
                        :
                        <View style={{alignItems:"center",justifyContent:"center",marginTop:mobileH*35/100}}>
                        <Text style={{fontSize:mobileW*5/100,color:Colors.blackColor,fontFamily:Font.FontSemiBold}}>No data found</Text>  
                        </View>
                        }
                          </View>
                       }

                     {checked == 'Scheduled' &&
                      <View>    
                      {scheduled!=""? <View>    
                 <FlatList
                   // data={DATA}
                data={scheduled}
                renderItem={({ item, index }) =>
                <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('SessionRequestBasic', { Active: checked, item: item })} style={styles.flatlistCard}>
                <View style={{ flexDirection: 'row' }}>
                <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100 }}>
                <View style={styles.imageCard}>
                <Image resizeMode='contain' style={styles.mavenImage}source={item.userDetail.profileImage == '' || null ? require("./Icon/icon_maven.png") : { uri: item.userDetail.profileImage }}></Image>
                </View>
                        <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color }}>{item.userDetail.FullName}</Text>
                        {/* <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.black_color }}>[Maven]</Text> */}

                           </View>
                            <View>
                            <View style={{ flexDirection:'row', marginTop:mobileW*3/100  }}>
                            <View style={{width: mobileW * 24 / 100, }} >
                            <Text style={styles.text_view}>Request:</Text>
                            <Text style={styles.appi_text}>{item.TypeOfRequest}</Text>
                             </View>
                             <View style={styles.mainview} >
                             <Text style={styles.text_view}>Start Date</Text>
                             <Text style={styles.appi_text}>{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                             </View>
                             <View style={styles.mainview} >
                             <Text style={styles.text_view}>End Date</Text>
                             <Text style={styles.appi_text}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                             </View>
                             </View>

                            <View style={{ flexDirection:'row', marginTop:mobileW*2/100 }}>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>Post date:</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.DateOfRequest)).format('MMM DD, YYYY')}</Text>
                            </View>
                             <View style={styles.mainview} >
                            <Text style={styles.text_view}>Level</Text>
                             <Text style={styles.appi_text}>{item.skill_level}</Text>
                             </View>
                             </View>
                            <View style={{width: mobileW * 72 / 100,  marginTop:mobileW*2/100, }} >
                            <Text style={styles.text_view}>Skills</Text>
                            <Text style={styles.appi_text}>{item.Skills}</Text>
                            </View>
                            </View>
                  
                        </View>
                        <View style={styles.flatlistFootar}>
                        <View style={{ flexDirection: 'row', paddingLeft: mobileW * 3 / 100, alignItems: 'center' }}>
                        <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.white_color }}>Fee {item.charges}</Text>
                        <Text style={{ fontSize: mobileW * 4 / 100, color: Colors.white_color, }}> Rs</Text>
                        </View>
                       <Text style={{ fontSize: mobileW * 3.5 / 100, color: item.requestagainreason != 'Student paid fee.' ? Colors.black_color : Colors.whiteColor, paddingRight: mobileW * 2 / 100 }}>{item.requestagainreason}</Text>
                       </View>
                       </TouchableOpacity>
                        } keyExtractor={item => item.id} />
                        </View>
                        :
                        <View style={{alignItems:"center",justifyContent:"center",marginTop:mobileH*35/100}}>
                        <Text style={{fontSize:mobileW*5/100,color:Colors.blackColor,fontWeight:"500"}}>No data found</Text>  
                        </View>
                        }
                          </View>
                       }

             {checked == 'Completed' &&
              <View>    
              {completed!=""? <View>  
              <FlatList
                data={completed}
                renderItem={({ item, index }) => {
                  return (
                            <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('SessionRequestBasic', { Active: checked, item: item })}style={styles.flatlistCard}>
                            <View style={{ flexDirection: 'row' }}>
                            <View style={{ width: mobileW * 24 / 100, alignItems: 'center', padding: mobileW * 2 / 100, }}>
                            <View style={styles.imageCard}>
                            <Image resizeMode='contain' style={styles.mavenImage} source={item.userDetail.profileImage == '' || null ? require("./Icon/icon_maven.png") : { uri: item.userDetail.profileImage }}></Image>
                            </View>
                           <Text style={{ fontSize: mobileW * 3.3 / 100, color: Colors.black_color,fontFamily:Font.FontRegular }}>{item.userDetail.FullName !=''?item.userDetail.FullName:'[Maven]'}</Text>
                           </View>
                            <View>
                            <View style={{ flexDirection:'row', marginTop:mobileW*3/100  }}>
                            <View style={{width: mobileW * 24 / 100, }} >
                            <Text style={styles.text_view}>{Lang_chg.RequestTxt[config.language]}</Text>
                            <Text style={styles.appi_text}>{item.TypeOfRequest}</Text>
                             </View>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>{Lang_chg.StartDateTxt[config.language]}</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.StartDate)).format('MMM DD, YYYY')}</Text>
                            </View>
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>{Lang_chg.EndDateTxt[config.language]}</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.Enddate)).format('MMM DD, YYYY')}</Text>
                            </View>
                            </View>
                               <View style={{ flexDirection:'row', marginTop:mobileW*2/100 }}>
                               <View  style={styles.mainview} >
                             <Text style={styles.text_view}>{Lang_chg.SkillsTxt[config.language]}</Text>
                             <Text style={styles.appi_text}>{item.Skills}</Text>
                             </View>

                           
                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>{Lang_chg.LevelTxt[config.language]}</Text>
                            <Text style={styles.appi_text}>{item.skill_level}</Text>
                            </View>

                            <View style={styles.mainview} >
                            <Text style={styles.text_view}>{Lang_chg.PostdateTxt[config.language]}</Text>
                            <Text style={styles.appi_text}>{moment(new Date(item.DateOfRequest)).format('MMM DD, YYYY')}</Text>
                            </View>
                            </View>
  
                             {/* <View style={{width: mobileW * 72 / 100,  marginTop:mobileW*2/100, }} >
                             <Text style={styles.text_view}>Skills</Text>
                             <Text style={styles.appi_text}>{item.Skills}</Text>
                             </View> */}
                             </View>
                  
                        </View>
                        <View style={styles.flatlistFootar}>
                        <View style={{ flexDirection: 'row', paddingLeft: mobileW * 3 / 100 }}>
                          <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.white_color, fontWeight: "500" }}>{Lang_chg.FeeTxt[config.language]} {item.charges} </Text>
                          <Text style={{ fontSize: mobileW * 2.2 / 100, color: Colors.white_color, alignSelf: 'flex-end' }}>{Lang_chg.RsTxt[config.language]}</Text>
                        </View>
                         <Text style={{ fontSize: mobileW * 2.8 / 100, color: item.requestagainreason != 'Student paid fee.' ? Colors.black_color : Colors.whiteColor, paddingRight: mobileW * 2 / 100,fontFamily:Font.FontMedium }}>{item.requestagainreason}</Text>
                        </View>
                        </TouchableOpacity>) }  }
                         keyExtractor={item => item.id} /> 
                          </View>
                        :
                        <View style={{alignItems:"center",justifyContent:"center",marginTop:mobileH*35/100}}>
                        <Text style={{fontSize:mobileW*5/100,color:Colors.blackColor,fontWeight:"500"}}>No data found</Text>  
                        </View>
                        }
                          </View>
                       }
                            </View>

                           </ScrollView>
                           </SafeAreaView> 
                           </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  HELP_TEXT:{ color: Colors.white_color, fontSize: mobileW * 4 / 100,fontFamily:Font.FontMedium  },

  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 13 / 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  text_view:{ fontSize: mobileW * 3/ 100, color: Colors.black_color, },

  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  backIcon_top: {
    width: mobileW * 9.5/ 100,
    height: mobileW * 9.5 / 100,
    tintColor: Colors.white_color
  },
  mainview:{ width: mobileW * 24 / 100, },

  SearchIcon: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    tintColor: Colors.white_color
  },
  plusicon: {
    width: mobileW * 4.5 / 100,
    height: mobileW * 4.5 / 100,
    tintColor: Colors.white_color
  },
  appi_text:{ fontSize: mobileW * 3 / 100, color:"#777" ,width:mobileW*21/100,marginTop:mobileW*0.3/100,fontFamily:Font.FontRegular},

  searchView: {
    width: mobileW,
    height: mobileW * 12 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.themecolor
  },
  TextInputView: {
    backgroundColor: Colors.white_color,
    width: mobileW * 95 / 100,
    flexDirection: 'row',
    borderRadius: mobileW * 1 / 100,
    alignItems: 'center'
  },
  TextInput: {
    width: mobileW * 85 / 100,
    borderRadius: mobileW * 1 / 100,
    height: mobileW * 10 / 100,
    backgroundColor: Colors.white_color,
    color: Colors.gray
  },
  croseImage: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    borderRadius: mobileW * 2 / 100,
    tintColor: Colors.themecolor
  },
  buttonCard: {
    flexDirection: 'row',
    backgroundColor: Colors.white_color,
    elevation: 5,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    // shadowColor: '#000',
    shadowOpacity: 0.1,

  },
  activeButton: {
    width: mobileW * 32 / 100,
    height: mobileW * 10 / 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: mobileW * 2 / 100
  },
  flatlistCard: {
    //  width: mobileW * 97 / 100,
    alignSelf: 'center',
    marginTop: mobileW * 3 / 100,

    borderRadius: mobileW * 1.5 / 100,
    backgroundColor: Colors.white_color,

    elevation: 5,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    // borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
  },

  imageCard: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    borderRadius: mobileW * 9 / 100,
    borderWidth: mobileW * 0.6 / 100,
    borderColor: Colors.themecolor,
    backgroundColor: Colors.white_color,
    alignItems: 'center',
    justifyContent: 'center' 
  },
  mavenImage: {
    width: mobileW * 14 / 100,
    height: mobileW * 14 / 100,
    borderRadius: mobileW * 8 / 100,
    tintColor: Colors.themecolor,
  },
  flatlistFootar: {
    width: mobileW * 96 / 100,
    height: mobileW * 9 / 100,
    marginTop: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor,
    borderBottomEndRadius: mobileW * 1.5 / 100,
    borderBottomStartRadius: mobileW * 1.5 / 100,
    alignSelf: "center",
    justifyContent: 'space-between',
    alignItems: 'center',
    // padding: mobileW * 1 / 100,
    flexDirection: 'row',
    elevation: 1,
    shadowColor: '#000',
    // borderColor: "#e8edfb",
    // borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    //  shadowColor: '#000',
    shadowOpacity: 0.1,
  },
  ModalHeader: {
    width: mobileW * 90 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    height: mobileW * 15 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  Modal: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 3 / 100,
    marginTop: mobileH * 25 / 100,
    alignSelf: 'center',
    backgroundColor: Colors.white_color,
    elevation: 5
  },

}
)
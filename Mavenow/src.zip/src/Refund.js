import { View, ScrollView, StatusBar, Modal, Alert, FlatList, Text, StyleSheet, Dimensions, TouchableOpacity, Image } from 'react-native'
import React, { useState, useEffect } from 'react'
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';


import { Colors, Font } from './Provider/Colorsfont';

import { SafeAreaView } from 'react-native-safe-area-context'
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

export default function Refund({navigation}) {
  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.Header}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity activeOpacity={0.8} style={{ marginHorizontal: mobileW * 5 / 100 }} onPress={() => navigation.goBack()}>
        <Image style={styles.backIcon_} resizeMode='contain'source={require("./Icon/bk.png")}></Image>
        </TouchableOpacity>
        <Text style={styles.headerText}>{Lang_chg.RefundHeaderTxt[config.language]}</Text>
        </View>
       
        </View>
        </SafeAreaView>
        </View>
  )
}

const styles = StyleSheet.create({
    container: {
      flex: 1
    },
    Header: {
      backgroundColor: Colors.themecolor,
      width: mobileW, height: mobileW * 13 / 100,
      flexDirection: 'row',
     
      
    },
    backIcon_: {
      width: mobileW * 9.5 / 100,
      height: mobileW *9.5 / 100,
      tintColor: Colors.white_color,
      marginHorizontal: mobileW * -3/ 100, 
    },
    headerText:{ 
        color: Colors.white_color, 
        marginHorizontal: mobileW * 2 / 100, 
        fontSize: mobileW * 4.5 / 100 ,
        fontFamily:Font.FontMedium
      },
})
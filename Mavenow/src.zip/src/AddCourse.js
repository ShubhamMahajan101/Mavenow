
import { View, Text, ScrollView, FlatList, StatusBar, StyleSheet, Dimensions, TouchableOpacity, Image, Button, Alert, Modal, } from 'react-native'
import React, { useState, useRef, useCallback, useEffect } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors, Font } from './Provider/Colorsfont';
import {    consolepro, Lang_chg,   msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import { Stack, TextInput, } from "@react-native-material/core";
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from 'axios';
import moment from 'moment';
import { msgProvider, msgText } from './Provider/Messageconsolevalidationprovider/messageProvider';
import { config } from './Provider/configProvider';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;



const Level = [
  { label: Lang_chg.BasicTxt[config.language], value: '1' },
  { label: Lang_chg.MediumTxt[config.language], value: '2' },
  { label: Lang_chg.AdvanceTxt[config.language], value: '3' },
];

const AddCourse = ({ navigation }) => {

  const [datePicker, setShow] = useState(false);
  const [timePicker, setTimePicker] = useState(false);
  const [endtimePicker, setendTimePicker] = useState(false);
  const [date, setdate] = useState(Lang_chg.StartDateTxt[config.language]);
  const [enddate, setenddate] = useState(Lang_chg.EndDateTxt[config.language]);
  const [time, setTime] = useState('HH:MM');

  const [category, setCategory] = useState([]);

  const [modalVisible_GIF, setModalVisible_GIF] = useState(false);
  const [price, setPrice] = useState('')

  const [modalVisible_active, setModalVisible_active] = useState(false);
  const [SkillName, setSkillName] = useState('Basic');
  

  const [ModalForCommission, setModalForCommission] = useState(false);
  
 
  const [fullname, setFullname] = useState('')
  const [topic, setTopic] = useState('')
  const [checkedd, setCheckedd] = useState('Basic')
  const [checkedData, setCheckedData] = useState('')




  const PostButton=()=>{
    

    if (SkillName == "Basic") {
      msgProvider.toast(msgText.selectskillsbasic[config.language], 'center')
      return false
    }

    
    if (date == "Start Date") {
      msgProvider.toast(msgText.StartDate[config.language], 'center')
      return false
    }
    
    //======================================mobile============================
    if (enddate == 'End Date') {
      msgProvider.toast(msgText.EndDate[config.language], 'center')
      return false
    }
    if (time == "HH:MM") {
      msgProvider.toast(msgText.TimeSelect[config.language], 'center')
      return false
    }
    if (price == '') {
      msgProvider.toast(msgText.priceset[config.language], 'center')
      return false
    }
    var mobilevalidation = config.mobilevalidation;
    if (mobilevalidation.test(mobile_number) !== true) {
      msgProvider.toast(msgText.validMobile[config.language], 'center')
      return false
    }
  
    if (language == 'Select language') {
      msgProvider.toast(msgText.ChooseLanguage[config.language], 'center')
      return false
    }

  }



  // const skillCategory_close = (item) => {
  //   console.log("am here", item);

  //   setSkillName(item.name)
  //   setSkills(item.Skills)
  //   setmodalCategory(false)
  // }

  // const skill_close = (item) => {
  //   console.log("am here", item);
  //   setSkill(item.SkillName)
  //   if (item.level == 1) {
  //     setSkillLevelForText('Basic')
  //   } else if (item.level == 2) {
  //     setSkillLevelForText("Medium")
  //   } else if (item.level == 3) {
  //     setSkillLevelForText('Advance')
  //   }
  //   setmodalSkills(false)
  // }

  // ---------- To get Percenage State ----------  
  const [percentage, setPercentage] = useState('you');

  useEffect(() => {
    // Not sure but percentage should be divided 300 I guess
    const per = ((price) * 5) / 100;
    setPercentage(price - per);
  }, [price]);

  const setDatetoFunction = (date) => {
    setTimePicker(false)
    setTimeout(() => {
      console.log(timePicker);
    }, 500);

    var formateDate = date.nativeEvent.timestamp
    let newDate = moment(new Date(formateDate)).format('DD-MM-YYYY')

    setdate(newDate)
    console.log('date is here--------->>>>>>', newDate);
  }

  const setendDatetoFunction = (date1) => {
    setendTimePicker(false)
    setTimeout(() => {
      console.log(endtimePicker);
    }, 500);

    var formateDate = date1.nativeEvent.timestamp
    let newDate = moment(new Date(formateDate)).format('DD-MM-YYYY')
    setenddate(newDate)
    console.log('date is here--------->>>>>>', newDate);
  }

  const setTimetoFunction = (given_time) => {
    if (given_time.type != 'dismissed') {
      console.log(given_time.type)
      setShow(false)
      var formateDate = given_time.nativeEvent.timestamp
      var hours = new Date(formateDate).getHours(); //Current Hours
      var min = new Date(formateDate).getMinutes(); //Current Minutes
      var sec = new Date(formateDate).getSeconds(); //Current Seconds

      var formattedDate = hours + ":" + min
      setTime(formattedDate)
      console.log('Time is here===========', formattedDate);

    } else {
      setTime("HH:MM")
      setShow(false)
    }


  }

  useEffect(() => {
    apiCalling();
  }, [])

  const apiCalling = () => {
    axios.get('https://mavenow.com:8001/usercategory?userId=848&userType=1&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI', {
    })
      .then(function (data) {
        var GetData = data.data.result
        console.log('-------- discipleOrMaster >', GetData)
        setCategory(GetData)
        setCategory(GetData)
        var data = data.data.result;
      })
      .catch(function (error) {
        console.log('======>', error);
      });
  }

        return (
        <View style={{ flex: 1, }}>
        <SafeAreaView style={styles.SafeArea_View}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />

            <View>
            <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible_active}>
           <View style={styles.success_modal}>
           <View style={styles.modalHeader}>
           <Text style={styles.success_text}>Success</Text>
           </View>
           <View style={styles.modalCard}>
          <View style={{alignSelf:'center', padding:mobileW*3/100}} >
          <Text style={[styles.commission_TExt,{width:mobileW*70/100, }]} >Your Teaching been submitted successfully for admin approval</Text>
          </View>
          <TouchableOpacity activeOpacity={0.8} style={styles.ok_Button} onPress={() => navigation.navigate('SessionRequest')}>
           <Text style={styles.OKKK_text}>Okay</Text>
          </TouchableOpacity>
          </View>
          </View>
          </Modal>
          </View>

          <View>
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible_GIF}>
            <View style={{ flex: 1, alignSelf: 'center', justifyContent: "center"}}>
           </View>
           </Modal>
          </View>
              {/* ++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++ */}
              <View style={styles.Header}>
          
              <TouchableOpacity activeOpacity={0.8}  onPress={() => navigation.goBack()}>
              <Image style={styles.backIcon_} resizeMode='contain' source={require("./Icon/bk.png")}></Image>
              </TouchableOpacity>
              <Text style={styles.HeaderText}>{Lang_chg.AddCourseTxt[config.language]}</Text>
           
              </View>
              <View style={{  backgroundColor: '#d6eef8',width: mobileW, padding:mobileW*3/100, borderBottomLeftRadius:mobileW*4/100, borderBottomRightRadius:mobileW*4/100}}>

                <Text style={{fontSize:mobileW*4/100,color:Colors.black_color,fontFamily:Font.FontSemiBold}}>Vinay Dexit</Text>
                <Text style={{fontSize:mobileW*3/100,color:Colors.gray,fontFamily:Font.FontRegular}}>Create Your Course</Text>
              </View>













              <ScrollView showsVerticalScrollIndicator={false} style={{margin:mobileW*4/100,}}>
<Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,fontFamily:Font.FontMedium}}>Course Name</Text>
              <View>
      <TextInput style={{marginTop:mobileW*2/100}}
      height={mobileW*12/100}
onChangeText={(txt) => setFullname(txt)}   
color={fullname==""? Colors.red:Colors.themecolor}label="Name" variant="outlined"
trailing={props =>(<Text></Text>)}/>
</View>

<Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,fontFamily:Font.FontMedium}}>Select Topic</Text>
<Text style={{fontSize:mobileW*3.5/100, color:Colors.gray,fontFamily:Font.FontRegular}}>We recommend adding your skill used in this experience your skills section</Text>

<View>
      <TextInput style={{marginTop:mobileW*2/100}}
onChangeText={(txt) => setTopic(txt)}   
color={topic==""? Colors.red:Colors.themecolor}label="Topic" variant="outlined"
trailing={props =>(<Text></Text>)}/>
</View>


<Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,fontFamily:Font.FontMedium}}>Select Level</Text>
<Text style={{fontSize:mobileW*3.5/100, color:Colors.gray,fontFamily:Font.FontRegular}}>We have whom can help you immediately to fix your problem would like to connect level of maven experties</Text>
          
          
<View style={{ height: mobileH * 10 / 100, alignItems: 'center', justifyContent: 'center', }}>
                      <FlatList
                        data={Level}
                        horizontal
                        contentContainerStyle={{ height: mobileH * 8 / 100, alignItems: 'center', justifyContent: 'center' }}
                        renderItem={({ item }) =>
                          <View style={{}}>
                            <TouchableOpacity activeOpacity={0.8} onPress={() => { setCheckedd(item.value), setCheckedData(item) }}
                              style={[styles.levelBtn, { borderColor: checkedd === item.value ? Colors.themecolor : Colors.gray, }]}
                            >
                              {checkedd == item.value ?
                                <Image resizeMode='contain' style={styles.iconTick} source={require('./Icon/icon_tick.png')} /> :
                                <Image resizeMode='contain' style={{
                                  width: mobileW * 4 / 100, height: mobileW * 4 / 100, alignSelf: 'flex-end',
                                  tintColor: Colors.white_color
                                }} source={require('./Icon/icon_tick.png')}
                                />
                              }
                              <Text style={{ fontSize: mobileW * 4 / 100, color: checkedd === item.value ? Colors.themecolor : Colors.gray, fontFamily:Font.FontRegular, marginTop: mobileW * -1 / 100, }}>{item.label}</Text>
                            </TouchableOpacity>
                          </View>}
                        keyExtractor={item => item.id} />
                    </View>
          
        

              <Text style={{fontSize:mobileW*3.5/100, color:Colors.black_color,fontFamily:Font.FontMedium}}>Estimated Course Duration</Text>
              
              <View style={styles.dateView}>
               <View>
               <Text style={{fontSize:mobileW*3.5/100, color:Colors.gray,fontFamily:Font.FontRegular}}>Start Date</Text>
              
               
              {timePicker && ( 
               <DateTimePicker
                mode={'date'}
                value={new Date(Date.now())}
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                is24Hour={false}
                onChange={text => setDatetoFunction(text)} />)}
              
               <TouchableOpacity activeOpacity={0.8} onPress={() => setTimePicker(true)} style={styles.CalanderView}>
               <Image resizeMode='contain' style={styles.iconQuestionMark} source={require('./Icon/icon_calendar.png')}></Image>
               <Text style={styles.calanderText}>  {date}</Text>
              </TouchableOpacity>
              </View>
              <View>
              <Text style={{fontSize:mobileW*3.5/100, color:Colors.gray,fontFamily:Font.FontRegular}}>End Date</Text>

               {endtimePicker && ( 
               <DateTimePicker
                mode={'date'}
                value={new Date(Date.now())}
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                is24Hour={false}
                onChange={text => setendDatetoFunction(text)}/> )}
               <TouchableOpacity activeOpacity={0.8} onPress={() => setendTimePicker(true)}style={styles.CalanderView}>
              <Image resizeMode='contain' style={styles.iconQuestionMark}source={require('./Icon/icon_calendar.png')}></Image>
              <Text style={styles.calanderText}>  {enddate}</Text>

             </TouchableOpacity>
             </View>
             </View>
             <Text style={{fontSize:mobileW*3.5/100, marginTop:mobileW*5/100, color:Colors.gray,fontFamily:Font.FontRegular}}>Session Duration</Text>
             {/* <Text style={[styles.CourseDurationText, { marginTop: mobileW * 3 / 100, }]}>{Lang_chg.SessionDurationnTxt[config.language]}</Text> */}
             {datePicker && (
             <DateTimePicker
              mode={'time'}
              value={new Date(Date.now())}
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              is24Hour={false}
              onChange={text => setTimetoFunction(text)} />)}
            <TouchableOpacity  activeOpacity={0.8} onPress={() => setShow(true)} style={styles.TimeView}>
              <Image resizeMode='contain'  style={{width:mobileW*6/100, height:mobileW*6/100, marginHorizontal:mobileW*4/100}}
              source={require('./Icon/history.png')}></Image>
            <Text style={styles.calanderText}>{time}</Text>
            </TouchableOpacity>

            <View style={styles.charges_view}>
            <Text style={{ marginHorizontal:mobileW*5/100, color: Colors.themecolor, fontFamily:Font.FontRegular, fontSize: mobileW * 3.2 / 100 }}>Mavenow 5 % Service Charge</Text>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setModalForCommission(true)}style={{}} >
               <Image style={styles.info_icon}resizeMode='contain' source={require("./Icon/icon_info.png")}></Image>
               </TouchableOpacity>
               </View>


           
          {/* +++++++++++++++++++++++++++++++++ Set Charges +++++++++++++++++++++++++++++++++ */}
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: mobileW * 2 / 100 }}>
              <View style={styles.setprice_view}>

             


              <TextInput onChangeText={(text) => { setPrice(text) }}
                 value={price}
              
                height={mobileW * 14 / 100} 
                keyboardType={'number-pad'}
                trailingContainerStyle={{fontSize:mobileW*3/100,color:Colors.red}}
                color={Colors.themecolor}
                label="Course Fee" variant="outlined"/>
                </View>
              
             
                {percentage != ""?
                <View style={styles.userCharges1}>
                 <Text style={styles.multipletext}>Rs {percentage}</Text>
                </View>
                 :
                <View style={styles.userCharges}>
                <Text style={styles.UserEarning}>Your Earning*</Text>
               </View>
              }
            

              </View>
              {/* +++++++++++++++++++++++++++++++++ Post Button +++++++++++++++++++++++++++++++++ */}
               <TouchableOpacity activeOpacity={0.8} style={styles.PostButton} onPress={() => { PostButton() }}>
               {/* <Text style={styles.post___texttt}>{Lang_chg.POSTTxt[config.language]}</Text> */}
               <Text style={styles.post___texttt}>NEXT</Text>
              </TouchableOpacity> 
              {/* ------------------------------------- MODEL -------------------------------------*/}

                   

          {/* ------------ MOdal to Select Category -------------- */}

              {/* <Modal animationType="slide"  transparent={true} visible={modalCategory}>
              <View style={styles.category_view}>
              <View style={styles.ModelCard}>
              <View style={styles.ModelHeader}>
               <Text style={styles.cHOOSECATEGORY_TEXT}>Choose category</Text>
              </View>
              <ScrollView showsVerticalScrollIndicator={false}>
              <View style={{ padding: mobileW * 3 / 100 }}>
              <View style={{ alignItems: 'center', }}>
              <FlatList
               data={category}
              renderItem={({ item }) =>
              <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }}onPress={() => skillCategory_close(item)}>
              <Text style={styles.multipletext}>{item.name}</Text>
              <View style={styles.skillCategory_close_view} />
              </TouchableOpacity>
              } />
              </View>
              <View style={styles.Main__View}>
              <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
              <Text style={styles.ok_cancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.okBtn}>
              <Text style={styles.ok_cancel}>Ok</Text>
              </TouchableOpacity>
              </View>
              </View>
              </ScrollView>
              </View>
              </View>
              </Modal> */}

          {/* ------------ MOdal to Select Skills -------------- */}

                {/* <Modal  animationType="slide"     transparent={true}  visible={modalskills} >
                <View style={styles.chooseskill_modal}>
                <View style={styles.ModelCard}>
                <View style={styles.ModelHeader}>
                <Text style={styles.choose_skill}>Choose skill</Text>
                 </View>
                <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ padding: mobileW * 3 / 100 }}>
                {skills != '' ?
                <View style={{ alignItems: 'center',}}>
                <FlatList
                data={skills}
                renderItem={({ item }) =>
                <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }} onPress={() => skill_close(item)}>
                 <Text style={styles.multipletext}>{item.SkillName}</Text>
                <View style={styles.underline} />
                </TouchableOpacity>} />
                    </View> :
                    <View>
                    <Text style={styles.selectcategory}>Plesae Select Category First</Text>
                    </View>}
                    <View style={styles.Main__View}>
                    <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalSkills(!modalskills)} style={styles.CancelBtn}>
                    <Text style={styles.ok_cancel}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalSkills(!modalskills)} style={styles.okBtn}>
                    <Text style={styles.ok_cancel}>Ok</Text>
                    </TouchableOpacity>
                    </View>
                   </View>
                  </ScrollView>
                  </View>
                  </View>
                  </Modal> */}

          { /* +++++++++++++++++++++++++++ Skill Category Modal +++++++++++++++++++++++++++ */}
            {/* <Modal
            animationType="slide"
            transparent={true}
            visible={modalCategory}>
            <View style={styles.modal____VIEW}>
            <View style={styles.ModelCard}>
            <View style={styles.ModelHeader}>
            <Text style={styles.ChooseCategory_text}>Choose category</Text>
            </View>
            <ScrollView showsVerticalScrollIndicator={false} >
            <View style={{ padding: mobileW * 3 / 100 }}>
            <View style={{ alignItems: 'center', }}>
            <FlatList
            data={category}
            renderItem={({ item }) =>
            <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }} onPress={() => skillCategory_close(item)}>
            <Text style={styles.multipletext}>{item.name}</Text>
            <View style={styles.underline} />
            </TouchableOpacity>}/>
            </View>
            <View style={styles.Main__View}>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
            <Text style={styles.cancel_text}>Cancel</Text>
            </TouchableOpacity>
             <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
            <Text style={styles.okk}>Ok</Text>
             </TouchableOpacity>
            </View>
            </View>
            </ScrollView>
            </View>
            </View>
            </Modal> */}

          {/* ------------ MOdal to Select Skills -------------- */}
               <Modal
              animationType='fade'
               transparent={true}
              visible={ModalForCommission}
              onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalForCommission(!ModalForCommission); }}>
              <View style={styles.modal_commission}>
              <View style={[styles.ModelCard]}>
              <View style={styles.ModelHeader}>
              <Text style={styles.Alert_text}>Alert</Text>
              </View>
              <View style={{  }}>
              <Text style={styles.commission_TExt}>Commision 0% for next 30 course {"\n"} then 10% should be charge per user</Text>
              <View style={{ alignItems: 'center', justifyContent: 'center', marginTop: mobileW * 3 / 100 }}>
              <TouchableOpacity activeOpacity={0.8} onPress={() => setModalForCommission(!ModalForCommission)} style={styles.ok_Button} >
              <Text style={styles.OK_TExt}>Ok</Text>
              </TouchableOpacity>
              </View>
              </View>
               </View>
              </View>
              </Modal>
              </ScrollView>
             </SafeAreaView>
            </View>

  )
}
export default AddCourse
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  FlatList__Data:{width: mobileW * 85 / 100,height: mobileW * 0.5 / 100, marginTop: mobileW * 3 / 100, marginBottom: mobileW * 3 / 100, backgroundColor: Colors.gray },
  post___texttt:{ color: Colors.white_color,fontSize: mobileW * 4 / 100, fontWeight: '500'},
  Alert_text: {
    color: Colors.white_color,
    fontSize: mobileW * 4.5 / 100,
    fontWeight: '500'
  },
  multi:{
    fontSize:mobileW*2/100,
    color:Colors.green

  },
  dianamic___text:{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, },
  modalview_view:{flex: 1, justifyContent: 'center', alignItems: 'center',  paddingVertical: mobileH * 7 / 100,backgroundColor: '#00000090' },
  sharma_text:{ fontSize: mobileW * 3.1/ 100, color: Colors.gray,fontFamily:Font.FontRegular },
  info_icon:{ 
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100, 
    borderRadius: mobileW * 2 / 100 ,
  },
  choose_skill:{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
  cHOOSECATEGORY_TEXT:{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
  selectcategory:{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, fontWeight: '500',alignSelf:"center" },
  commission_TExt: {
    fontSize: mobileW * 4 / 100,
    fontWeight: '400',
    color: Colors.blackColor,
    textAlign: 'center'
  },
  ChooseCategory_text: {
    color: Colors.white_color,
    fontSize: mobileW * 4 / 100,
    fontWeight: '500'
  },
  chooseskill_modal:{flex: 1,paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
  multipletext:{ 
    fontSize: mobileW * 4 / 100, 
    color: Colors.themecolor, 
    fontFamily:Font.FontRegular  
  },
  modal_commission: {
    flex: 1,
    // paddingVertical:mobileH*7/100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#00000090'
  },
  skillCategory_close_view:{width: mobileW * 85 / 100, height: mobileW * 0.5 / 100, marginTop: mobileW * 3 / 100,marginBottom: mobileW * 3 / 100, backgroundColor: Colors.gray},
  camcelok_whitetext:{ fontSize: mobileW * 4 / 100, fontWeight: '500', color: Colors.white_color },

  category_view:{ flex: 1, paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
  ok_cancel:{ fontSize: mobileW * 4 / 100, fontWeight: '500',
   color: Colors.white_color },
   modal____VIEW:{ flex: 1, paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
  
  cancel_text: {
    fontSize: mobileW * 4 / 100,
    fontWeight: '500',
    color: Colors.white_color
  },
  OK_TExt: {
    fontSize: mobileW * 4 / 100,
    fontWeight: '500',
    color: Colors.white_color
  },
  success_modal:{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000096' },
  okk: {
    fontSize: mobileW * 4 / 100,
    fontWeight: '500',
    color: Colors.white_color
  },
  SafeArea_View: {
    flex: 1,
    backgroundColor: Colors.white_color
  },
  charges_view:{
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent:'flex-end',
    marginTop: mobileW * 2 / 100 
  },
  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color,
  },
  ok_Button: {
    width: mobileW * 22 / 100,
    height: mobileW * 8 / 100,
    backgroundColor: Colors.themecolor,
    borderRadius: mobileW * 2 / 100,
    alignSelf: "center",
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: mobileW * 2 / 100,
    marginBottom: mobileW * 3 / 100
  },
  show_touchableview:{ width: mobileW * 94 / 100,  marginTop: mobileW * 4 / 100, borderColor: Colors.light_grey, alignSelf: 'center' },
  backIcon_: {
    width: mobileW * 9.5 / 100,
    height: mobileW * 9.5/ 100,
    tintColor: Colors.blackColor,
  },
  _ModalCategory:{color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
  OKKK_text:{ color: Colors.whiteColor, fontSize: mobileW * 4 / 100, fontWeight: '500' },
  modalHeader: {
    backgroundColor: Colors.themecolor,
    height: mobileW * 12 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    width: mobileW * 90 / 100
  },
  Main__View:{ flexDirection: 'row', alignSelf: 'flex-end', marginTop: mobileW * 5 / 100 },
 
  modalCard: {
    backgroundColor: Colors.whiteColor,
    elevation: mobileW * 3 / 100,
    borderBottomRightRadius: mobileW * 2 / 100,
    borderBottomLeftRadius: mobileW * 2 / 100,
    width: mobileW * 90 / 100
  },
  setprice_view:{ 
    marginTop: mobileW * 2 / 100, 
    width: mobileW * 45 / 100, 
    marginLeft:mobileW*3/100,
    // height:mobileW*10/100
  },

  HeaderText: {
    color: Colors.black_color,
    marginHorizontal: mobileW * 2 / 100,
     fontSize: mobileW * 3.5 / 100,
     fontFamily:Font.FontMedium
   
  },
  Header: {
    backgroundColor: '#d6eef8',
    width: mobileW,
    height: mobileW * 13/ 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',

  },
  Categoryselect: {
    width: mobileW * 94 / 100,
    height: mobileW * 13 / 100,
    padding: mobileW * 3 / 100,
    margin: mobileW * 2 / 100,
    borderWidth: mobileW * 0.3/ 100,
    borderColor:"#9f9f9f",
    backgroundColor: Colors.white_color,
    elevation: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: mobileW * 1 / 100,
    alignSelf: 'center'
  },
  dateView: {
    flexDirection: 'row',
    marginTop: mobileW * 2 / 100,
    width: mobileW * 92 / 100,
    justifyContent: 'space-between',
    alignSelf: 'center'
  },
  iconTick: {
    width: mobileW * 4 / 100,
    height: mobileW * 4 / 100,
    alignSelf: 'flex-end',
    tintColor: Colors.themecolor,
  },
  levelBtn: {
    backgroundColor: Colors.whiteColor,
    margin: mobileW * 1.5 / 100,
    width: mobileW * 28 / 100,
    height: mobileW * 14 / 100,
    borderWidth: mobileW * 0.2 / 100,
    alignItems: 'center',
    padding: mobileW * 1 / 100,
    borderRadius: mobileW * 2 / 100,
  },
  iconQuestionMark: {
    width: mobileW * 6.5 / 100,
    height: mobileW * 6.5 / 100,
    tintColor: Colors.gray
  },
  success_text:{ color: Colors.whiteColor, fontSize: mobileW * 4 / 100, fontWeight: '500' },
  CourseDurationText: {
    marginLeft: mobileW * 5 / 100,
    marginTop: mobileW * 1.5 / 100,
    color: Colors.gray,
    fontSize: mobileW * 2.9/ 100,
    fontFamily:Font.FontRegular

  },
  sessionDurationTime: {
    color: Colors.gray,
    fontSize: mobileW * 3.5 / 100,
    marginTop: mobileW * 2 / 100,
    marginHorizontal: mobileW * 3 / 100,
    marginLeft: mobileW * 5 / 100,
  },
  CalanderView: {
    width: mobileW * 42 / 100,
    height: mobileW * 13 / 100,
    backgroundColor: Colors.whiteColor,
    borderRadius: mobileW * 1 / 100,
    padding: mobileW * 2 / 100,
    marginTop:mobileW*2/100,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    borderWidth: mobileW * 0.2/ 100,
    borderColor:"#9f9f9f",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
    borderColor:Colors.gray
  },
  TimeView: {
    // marginLeft: mobileW * 3 / 100,
    marginTop: mobileW * 1/ 100,
    width: mobileW * 92 / 100,
    height: mobileW * 13 / 100,
    backgroundColor: Colors.whiteColor,
    borderRadius: mobileW * 1 / 100,
    flexDirection:'row',
    // justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    borderColor: Colors.light_grey,
    borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
    borderColor: Colors.themecolor
  },
  calanderText: {
    color: Colors.black_color,
    // alignSelf: 'center',
    fontSize: mobileW * 4 / 100,
    // fontWeight: '400',
    marginHorizontal: mobileW * 2 / 100
  },
  calanderText1: {
    color: Colors.gray,
    fontSize: mobileW * 3 / 100,
    fontWeight: '500',
    marginHorizontal: mobileW * 12 / 100,
    alignSelf: 'center'
  },
  UserEarning:{
    color:Colors.blackColor,
    fontSize:mobileW*4/100

  },
  PostButton: {
    width: mobileW * 92 / 100,
    height: mobileW * 12 / 100,
    marginTop: mobileW * 3 / 100,
    borderRadius: mobileW * 2.4 / 100,
    backgroundColor: Colors.themecolor,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: mobileW * 10 / 100
  },
  ModelCard: {
    width: mobileW * 90 / 100,
    // height:mobileH*90/100,
    borderRadius: mobileW * 3 / 100,
    backgroundColor: Colors.white_color,
    elevation: 5
  },
  ModelHeader: {
    width: mobileW * 90 / 100,
    marginBottom: mobileW * 5 / 100,
    justifyContent: 'center',
    alignItems: 'center',
    height: mobileW * 11 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  underline: {
    width: mobileW * 85 / 100,
    height: mobileW * 0.3 / 100,
    marginTop: mobileW * 3 / 100,
    marginBottom: mobileW * 3 / 100,
    backgroundColor: Colors.gray
  },
  CancelBtn: {
    width: mobileW * 25 / 100,
    height: mobileW * 8 / 100,
    borderRadius: mobileW * 2 / 100,
    marginHorizontal: mobileW * 1 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.themecolor
  },
  okBtn: {
    width: mobileW * 25 / 100,
    height: mobileW * 8 / 100,
    borderRadius: mobileW * 2 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.themecolor
  },
  DRAWER_image:{ 
    width: mobileW * 3.4 / 100, 
    height: mobileW * 3.4/ 100,
    tintColor:'gray'
  },
  
  showBox: {
    width: mobileW * 94 / 100,
    elevation: 1,
    padding: mobileW * 5 / 100,
    borderRadius: mobileW * 2 / 100,
    backgroundColor: Colors.white_color,
    borderColor: Colors.gray,
    borderWidth:mobileW*0.3/100
  },
  userCharges: {
    marginTop: mobileW * 2 / 100,
    width: mobileW * 40 / 100,
    height: mobileW * 15/ 100,
   marginRight:mobileW*3/100,
    borderWidth: mobileW * 0.3 / 100,
    borderRadius: mobileW * 1 / 100,
    borderColor: Colors.gray,
    alignItems: 'center',
    justifyContent: 'center'
  },
  userCharges1: {
    marginTop: mobileW * 2 / 100,
    width: mobileW * 42 / 100,
    height: mobileW * 13 / 100,
    padding:mobileW*2/100,
    // marginHorizontal: mobileW * 2 / 100,
    borderWidth: mobileW * 0.3 / 100,
    borderRadius: mobileW * 1 / 100,
    borderColor: Colors.themecolor,
    // alignItems: 'center',
    justifyContent: 'center'
  },
})
















// ++++++++++++++++++++++++++++++++++++++++++++++++++ OLD SCREEN ++++++++++++++++++++++++++++++++++++++++++++++++++++++




// import { View, Text, ScrollView, FlatList, StatusBar, StyleSheet, Dimensions, TouchableOpacity, Image, Button, Alert, Modal, } from 'react-native'
// import React, { useState, useRef, useCallback, useEffect } from 'react'
// import { SafeAreaView } from 'react-native-safe-area-context'
// import { Colors, Font } from './Provider/Colorsfont';
// import {    consolepro, Lang_chg,   msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
// import { Stack, TextInput, } from "@react-native-material/core";
// import DateTimePicker from '@react-native-community/datetimepicker';
// import axios from 'axios';
// import moment from 'moment';
// import { msgProvider, msgText } from './Provider/Messageconsolevalidationprovider/messageProvider';
// import { config } from './Provider/configProvider';
// const mobileW = Dimensions.get('window').width;
// const mobileH = Dimensions.get('window').height;

// const SkillLevelsss = [
//   { id: 1, level: 'Basic' },
//   { id: 2, level: 'Medium' },
//   { id: 3, level: 'Advance' }
// ]

// const AddCourse = ({ navigation }) => {

//   const [datePicker, setShow] = useState(false);
//   const [timePicker, setTimePicker] = useState(false);
//   const [endtimePicker, setendTimePicker] = useState(false);
//   const [date, setdate] = useState(Lang_chg.StartDateTxt[config.language]);
//   const [enddate, setenddate] = useState(Lang_chg.EndDateTxt[config.language]);
//   const [time, setTime] = useState('HH:MM');
//   const [shouldShow, setShouldShow] = useState(false);
//   const [category, setCategory] = useState([]);
//   const [skills, setSkills] = useState([]);
//   const [modalVisible, setmodalVisible] = useState(false);
//   const [modalVisible_GIF, setModalVisible_GIF] = useState(false);
//   const [price, setPrice] = useState('')
//   const [modalCategory, setmodalCategory] = useState(false);
//   const [modalVisible_active, setModalVisible_active] = useState(false);
//   const [SkillName, setSkillName] = useState('Basic');
//   const [modalskills, setmodalSkills] = useState(false);
//   const [modalskillsLevel, setmodalSkillsLevel] = useState(false);
//   const [ModalForCommission, setModalForCommission] = useState(false);
//   const [Skill, setSkill] = useState('Medium');
//   const [SkillLevelForText, setSkillLevelForText] = useState('Advance');
//   const [SkillLevel, setSkillLevel] = useState(SkillLevelsss);
//   const [checked, setChecked] = useState('Active')




//   const PostButton=()=>{
//     // if (shouldShow == false) {
//     //   msgProvider.toast(msgText.acceptTerms[config.language], 'center')
//     //   return false
//     // }
//     // ======================== Validations for Signup ==================
//     // {fullname.length==""?Colors.red:Colors.themecolor}
//     // if (fullname.length <= 0?Colors.red:Colors.themecolor && email.length <= 0 && mobile_number.length <= 0) {
//     //   msgProvider.toast(msgText.Sign_In_or_Login_error_msg[config.language], 'center')
//     //   return false
//     // }
//     //=====================All Fields Check================

//     if (SkillName == "Basic") {
//       msgProvider.toast(msgText.selectskillsbasic[config.language], 'center')
//       return false
//     }

//     // if (Skill == "Medium") {
//     //   msgProvider.toast(msgText.selectskillsmedium[config.language], 'center')
//     //   return false
//     // }
//     // //===========email============================
//     // if (SkillLevelForText == "Advance") {
//     //   msgProvider.toast(msgText.selectskills[config.language], 'center')
//     //   setEmail('NA')
//     //   return false
//     // }
    
//     if (date == "Start Date") {
//       msgProvider.toast(msgText.StartDate[config.language], 'center')
//       return false
//     }
    
//     //======================================mobile============================
//     if (enddate == 'End Date') {
//       msgProvider.toast(msgText.EndDate[config.language], 'center')
//       return false
//     }
//     if (time == "HH:MM") {
//       msgProvider.toast(msgText.TimeSelect[config.language], 'center')
//       return false
//     }
//     if (price == '') {
//       msgProvider.toast(msgText.priceset[config.language], 'center')
//       return false
//     }
//     var mobilevalidation = config.mobilevalidation;
//     if (mobilevalidation.test(mobile_number) !== true) {
//       msgProvider.toast(msgText.validMobile[config.language], 'center')
//       return false
//     }
  
//     if (language == 'Select language') {
//       msgProvider.toast(msgText.ChooseLanguage[config.language], 'center')
//       return false
//     }

//   }

//   const SkillLevelToSet = (item) => {
//     setSkillLevelForText(item.level)
//     setmodalSkillsLevel(false)
//   }

//   const skillCategory_close = (item) => {
//     console.log("am here", item);

//     setSkillName(item.name)
//     setSkills(item.Skills)
//     setmodalCategory(false)
//   }

//   const skill_close = (item) => {
//     console.log("am here", item);
//     setSkill(item.SkillName)
//     if (item.level == 1) {
//       setSkillLevelForText('Basic')
//     } else if (item.level == 2) {
//       setSkillLevelForText("Medium")
//     } else if (item.level == 3) {
//       setSkillLevelForText('Advance')
//     }
//     setmodalSkills(false)
//   }

//   // ---------- To get Percenage State ----------  
//   const [percentage, setPercentage] = useState('you');

//   useEffect(() => {
//     // Not sure but percentage should be divided 300 I guess
//     const per = ((price) * 5) / 100;
//     setPercentage(price - per);
//   }, [price]);

//   const setDatetoFunction = (date) => {
//     setTimePicker(false)
//     setTimeout(() => {
//       console.log(timePicker);
//     }, 500);

//     var formateDate = date.nativeEvent.timestamp
//     let newDate = moment(new Date(formateDate)).format('DD-MM-YYYY')

//     setdate(newDate)
//     console.log('date is here--------->>>>>>', newDate);
//   }

//   const setendDatetoFunction = (date1) => {
//     setendTimePicker(false)
//     setTimeout(() => {
//       console.log(endtimePicker);
//     }, 500);

//     var formateDate = date1.nativeEvent.timestamp
//     let newDate = moment(new Date(formateDate)).format('DD-MM-YYYY')
//     setenddate(newDate)
//     console.log('date is here--------->>>>>>', newDate);
//   }

//   const setTimetoFunction = (given_time) => {
//     if (given_time.type != 'dismissed') {
//       console.log(given_time.type)
//       setShow(false)
//       var formateDate = given_time.nativeEvent.timestamp
//       var hours = new Date(formateDate).getHours(); //Current Hours
//       var min = new Date(formateDate).getMinutes(); //Current Minutes
//       var sec = new Date(formateDate).getSeconds(); //Current Seconds

//       var formattedDate = hours + ":" + min
//       setTime(formattedDate)
//       console.log('Time is here===========', formattedDate);

//     } else {
//       setTime("HH:MM")
//       setShow(false)
//     }


//   }

//   useEffect(() => {
//     apiCalling();
//   }, [])

//   const apiCalling = () => {
//     axios.get('https://mavenow.com:8001/usercategory?userId=848&userType=1&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2VtYWlsIjoidmluYXlAaW53aXphcmRzLmluIiwidXNlcl9JZCI6ODQ4LCJpYXQiOjE2NzQyMDkzNjF9.kEE4daftkvB5z3xMdMhjTq1DYnnNz__U1yXS2TRQRjI', {
//     })
//       .then(function (data) {
//         var GetData = data.data.result
//         console.log('-------- discipleOrMaster >', GetData)
//         setCategory(GetData)
//         setCategory(GetData)
//         var data = data.data.result;
//       })
//       .catch(function (error) {
//         console.log('======>', error);
//       });
//   }

//         return (
//         <View style={{ flex: 1, }}>
//         <SafeAreaView style={styles.SafeArea_View}>
//         <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />

//             <View>
//             <Modal
//             animationType="slide"
//             transparent={true}
//             visible={modalVisible_active}>
//            <View style={styles.success_modal}>
//            <View style={styles.modalHeader}>
//            <Text style={styles.success_text}>Success</Text>
//            </View>
//            <View style={styles.modalCard}>
//           <View style={{alignSelf:'center', padding:mobileW*3/100}} >
//           <Text style={[styles.commission_TExt,{width:mobileW*70/100, }]} >Your Teaching been submitted successfully for admin approval</Text>
//           </View>
//           <TouchableOpacity activeOpacity={0.8} style={styles.ok_Button} onPress={() => navigation.navigate('SessionRequest')}>
//            <Text style={styles.OKKK_text}>Okay</Text>
//           </TouchableOpacity>
//           </View>
//           </View>
//           </Modal>
//           </View>

//           <View>
//           <Modal
//             animationType="slide"
//             transparent={true}
//             visible={modalVisible_GIF}>
//             <View style={{ flex: 1, alignSelf: 'center', justifyContent: "center"}}>
//            </View>
//            </Modal>
//           </View>
//               {/* ++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++ */}
//               <View style={styles.Header}>
//               <View style={{ flexDirection: 'row', alignItems: 'center' }}>
//               <TouchableOpacity activeOpacity={0.8}  onPress={() => navigation.goBack()}>
//               <Image style={styles.backIcon_} resizeMode='contain' source={require("./Icon/bk.png")}></Image>
//               </TouchableOpacity>
//               <Text style={styles.HeaderText}>{Lang_chg.AddCourseTxt[config.language]}</Text>
//               </View>
//               <TouchableOpacity activeOpacity={0.8} style={{ marginRight: mobileW * 5 / 100 }} >
//               <Image style={styles.backIcon} resizeMode='contain' source={require("./Icon/icon_info.png")}></Image>
//               </TouchableOpacity>
//               </View>
//               <ScrollView showsVerticalScrollIndicator={false}>

//             {/*  +++++++++++++++++++++++++++ Skill, Category, Level +++++++++++++++++++++++++++ */}
//             <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(true)} style={styles.Categoryselect}>
//             <Text style={styles.dianamic___text}  >{SkillName}</Text>
//             <Image style={styles.DRAWER_image} resizeMode='contain' source={require("./Icon/icon_drapdown.png")}></Image>
//             </TouchableOpacity>

//             <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalSkills(true)} style={styles.Categoryselect}>
//             <Text style={styles.dianamic___text}  >{Skill}</Text>
//             <Image style={styles.DRAWER_image}resizeMode='contain' source={require("./Icon/icon_drapdown.png")}></Image>
//             </TouchableOpacity>
//             <TouchableOpacity activeOpacity={0.8} style={styles.Categoryselect}>
//             <Text style={styles.dianamic___text}  >{SkillLevelForText}</Text>
//             <Image style={styles.DRAWER_image}resizeMode='contain' source={require("./Icon/icon_drapdown.png")}></Image>
//             </TouchableOpacity>

//           {/* ==============================Date Picker============================== */}
//               <Text style={styles.CourseDurationText}>{Lang_chg.EstimatedDurationTxt[config.language]}</Text>
//               <View style={styles.dateView}>
//               {timePicker && ( 
//                <DateTimePicker
//                 mode={'date'}
//                 value={new Date(Date.now())}
//                 display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                 is24Hour={false}
//                 onChange={text => setDatetoFunction(text)} />)}
//                <TouchableOpacity activeOpacity={0.8} onPress={() => setTimePicker(true)} style={styles.CalanderView}>
//                <Image resizeMode='contain' style={styles.iconQuestionMark} source={require('./Icon/icon_calendar.png')}></Image>
//                <Text style={styles.calanderText}>  {date}</Text>
//               </TouchableOpacity>

//                {endtimePicker && ( 
//                <DateTimePicker
//                 mode={'date'}
//                 value={new Date(Date.now())}
//                 display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//                 is24Hour={false}
//                 onChange={text => setendDatetoFunction(text)}/> )}
//                <TouchableOpacity activeOpacity={0.8} onPress={() => setendTimePicker(true)}style={styles.CalanderView}>
//               <Image resizeMode='contain' style={styles.iconQuestionMark}source={require('./Icon/icon_calendar.png')}></Image>
//               <Text style={styles.calanderText}>  {enddate}</Text>

//              </TouchableOpacity>
//              </View>
//              <Text style={[styles.CourseDurationText, { marginTop: mobileW * 3 / 100, }]}>{Lang_chg.SessionDurationnTxt[config.language]}</Text>
//              {datePicker && (
//              <DateTimePicker
//               mode={'time'}
//               value={new Date(Date.now())}
//               display={Platform.OS === 'ios' ? 'spinner' : 'default'}
//               is24Hour={false}
//               onChange={text => setTimetoFunction(text)} />)}
//             <TouchableOpacity  activeOpacity={0.8} onPress={() => setShow(true)} style={styles.TimeView}>
//             <Text style={styles.calanderText}>{time}</Text>
//             </TouchableOpacity>
//             <TouchableOpacity activeOpacity={0.8} style={styles.show_touchableview} onPress={() => setShouldShow(!shouldShow)}>
//             {shouldShow ? (
//            <TouchableOpacity style={{ width: mobileW * 94 / 100, }}>
//            <TextInput color={Colors.themecolor} height={mobileH * 20 / 100}
//             textAlignVertical={'top'}
//              paddingTop={mobileH * 2 / 100}
//              multiline label="Please explain about  your  concern"
//             variant="outlined" trailing={props => (<Text></Text>)} />
//               </TouchableOpacity>
//              ) :
//               (<View style={styles.showBox}>
//                <Text style={styles.sharma_text}>Hello,{'\n'} I am  Aman Sharma,I am into growth marketing. {'\n'}I want to learn how to
//                 integrate WhatsApp API to send automated replies and Promotional messages to our users.</Text>
//                 </View>)}
//                 </TouchableOpacity>

//                <View style={styles.charges_view}>
//                {/* <Text style={{ marginHorizontal: mobileW * 5 / 100, color: Colors.themecolor, fontSize: mobileW * 3.5 / 100 }}>Mavenow 5 % Service Charge</Text> */}
//                <Text style={{ marginHorizontal: mobileW * 5 / 100, color: Colors.themecolor, fontSize: mobileW * 3.5 / 100 }}>{Lang_chg.freesessionTxt[config.language]}</Text>
//                {/* <TouchableOpacity activeOpacity={0.8} onPress={() => setModalForCommission(true)}style={{}} >
//                <Image style={styles.info_icon}resizeMode='contain' source={require("./Icon/icon_info.png")}></Image>
//                </TouchableOpacity> */}
//                </View>
//           {/* +++++++++++++++++++++++++++++++++ Set Charges +++++++++++++++++++++++++++++++++ */}
//               <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: mobileW * 2 / 100 }}>
//               <View style={styles.setprice_view}>
//               <TextInput onChangeText={(text) => { setPrice(text) }}
//                  value={price}
              
//                 height={mobileW * 14 / 100} 
//                 keyboardType={'number-pad'}
//                 trailingContainerStyle={{fontSize:mobileW*3/100,color:Colors.red}}
//                 color={Colors.themecolor}
//                 label="Course Fee" variant="outlined"/>
//                 </View>
              
             
//                 {percentage != ""?
//                 <View style={styles.userCharges1}>
//                  <Text style={styles.multipletext}>{percentage}</Text>
//                 </View>
//                  :
//                 <View style={styles.userCharges}>
//                 <Text style={styles.UserEarning}>Your Earning*</Text>
//                </View>
//               }
            

//               </View>
//               {/* +++++++++++++++++++++++++++++++++ Post Button +++++++++++++++++++++++++++++++++ */}
//                <TouchableOpacity activeOpacity={0.8} style={styles.PostButton} onPress={() => { PostButton() }}>
//                <Text style={styles.post___texttt}>{Lang_chg.POSTTxt[config.language]}</Text>
//               </TouchableOpacity> 
//               {/* ------------------------------------- MODEL -------------------------------------*/}

//                        <Modal animationType="slide" transparent={true}  visible={modalVisible}>
//                        <View style={styles.modalview_view}>
//                        <View style={styles.ModelCard}>
//                        <View style={styles.ModelHeader}>
//                        <Text style={styles._ModalCategory}>Choose category</Text>
//                        </View>
//                        <ScrollView showsVerticalScrollIndicator={false} >
//                        <View style={{ padding: mobileW * 3 / 100 }}>
//                        <View style={{ alignItems: 'center', }}>
//                        <FlatList
//                         data={category}
//                         renderItem={({ item }) =>
//                         <View style={{ alignItems: 'center' }}>
//                         <Text style={{fontSize:mobileW*3/100}}>{item.name}</Text>
//                         <View style={styles.FlatList__Data} />
//                         </View>}/>
//                         </View>
//                         <View style={styles.Main__View}>
//                         <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalVisible(!modalVisible)} style={styles.CancelBtn}>
//                         <Text style={styles.camcelok_whitetext}>Cancel</Text>
//                         </TouchableOpacity>
//                         <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalVisible(!modalVisible)} style={styles.okBtn}>
//                         <Text style={styles.camcelok_whitetext}>Ok</Text>
//                        </TouchableOpacity>
//                        </View>
//                        </View>
//                        </ScrollView>
//                        </View>
//                        </View>
//                        </Modal>

//           {/* ------------ MOdal to Select Category -------------- */}

//               <Modal animationType="slide"  transparent={true} visible={modalCategory}>
//               <View style={styles.category_view}>
//               <View style={styles.ModelCard}>
//               <View style={styles.ModelHeader}>
//                <Text style={styles.cHOOSECATEGORY_TEXT}>Choose category</Text>
//               </View>
//               <ScrollView showsVerticalScrollIndicator={false}>
//               <View style={{ padding: mobileW * 3 / 100 }}>
//               <View style={{ alignItems: 'center', }}>
//               <FlatList
//                data={category}
//               renderItem={({ item }) =>
//               <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }}onPress={() => skillCategory_close(item)}>
//               <Text style={styles.multipletext}>{item.name}</Text>
//               <View style={styles.skillCategory_close_view} />
//               </TouchableOpacity>
//               } />
//               </View>
//               <View style={styles.Main__View}>
//               <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
//               <Text style={styles.ok_cancel}>Cancel</Text>
//               </TouchableOpacity>
//               <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.okBtn}>
//               <Text style={styles.ok_cancel}>Ok</Text>
//               </TouchableOpacity>
//               </View>
//               </View>
//               </ScrollView>
//               </View>
//               </View>
//               </Modal>

//           {/* ------------ MOdal to Select Skills -------------- */}

//                 <Modal  animationType="slide"     transparent={true}  visible={modalskills} >
//                 <View style={styles.chooseskill_modal}>
//                 <View style={styles.ModelCard}>
//                 <View style={styles.ModelHeader}>
//                 <Text style={styles.choose_skill}>Choose skill</Text>
//                  </View>
//                 <ScrollView showsVerticalScrollIndicator={false}>
//                 <View style={{ padding: mobileW * 3 / 100 }}>
//                 {skills != '' ?
//                 <View style={{ alignItems: 'center',}}>
//                 <FlatList
//                 data={skills}
//                 renderItem={({ item }) =>
//                 <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }} onPress={() => skill_close(item)}>
//                  <Text style={styles.multipletext}>{item.SkillName}</Text>
//                 <View style={styles.underline} />
//                 </TouchableOpacity>} />
//                     </View> :
//                     <View>
//                     <Text style={styles.selectcategory}>Plesae Select Category First</Text>
//                     </View>}
//                     <View style={styles.Main__View}>
//                     <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalSkills(!modalskills)} style={styles.CancelBtn}>
//                     <Text style={styles.ok_cancel}>Cancel</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalSkills(!modalskills)} style={styles.okBtn}>
//                     <Text style={styles.ok_cancel}>Ok</Text>
//                     </TouchableOpacity>
//                     </View>
//                    </View>
//                   </ScrollView>
//                   </View>
//                   </View>
//                   </Modal>

//           { /* +++++++++++++++++++++++++++ Skill Category Modal +++++++++++++++++++++++++++ */}
//             <Modal
//             animationType="slide"
//             transparent={true}
//             visible={modalCategory}>
//             <View style={styles.modal____VIEW}>
//             <View style={styles.ModelCard}>
//             <View style={styles.ModelHeader}>
//             <Text style={styles.ChooseCategory_text}>Choose category</Text>
//             </View>
//             <ScrollView showsVerticalScrollIndicator={false} >
//             <View style={{ padding: mobileW * 3 / 100 }}>
//             <View style={{ alignItems: 'center', }}>
//             <FlatList
//             data={category}
//             renderItem={({ item }) =>
//             <TouchableOpacity activeOpacity={0.8} style={{ alignItems: 'center' }} onPress={() => skillCategory_close(item)}>
//             <Text style={styles.multipletext}>{item.name}</Text>
//             <View style={styles.underline} />
//             </TouchableOpacity>}/>
//             </View>
//             <View style={styles.Main__View}>
//             <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
//             <Text style={styles.cancel_text}>Cancel</Text>
//             </TouchableOpacity>
//              <TouchableOpacity activeOpacity={0.8} onPress={() => setmodalCategory(!modalCategory)} style={styles.CancelBtn}>
//             <Text style={styles.okk}>Ok</Text>
//              </TouchableOpacity>
//             </View>
//             </View>
//             </ScrollView>
//             </View>
//             </View>
//             </Modal>

//           {/* ------------ MOdal to Select Skills -------------- */}
//                <Modal
//               animationType='fade'
//                transparent={true}
//               visible={ModalForCommission}
//               onRequestClose={() => {
//               Alert.alert("Modal has been closed.");
//               setModalForCommission(!ModalForCommission); }}>
//               <View style={styles.modal_commission}>
//               <View style={[styles.ModelCard]}>
//               <View style={styles.ModelHeader}>
//               <Text style={styles.Alert_text}>Alert</Text>
//               </View>
//               <View style={{  }}>
//               <Text style={styles.commission_TExt}>Commision 0% for next 30 course {"\n"} then 10% should be charge per user</Text>
//               <View style={{ alignItems: 'center', justifyContent: 'center', marginTop: mobileW * 3 / 100 }}>
//               <TouchableOpacity activeOpacity={0.8} onPress={() => setModalForCommission(!ModalForCommission)} style={styles.ok_Button} >
//               <Text style={styles.OK_TExt}>Ok</Text>
//               </TouchableOpacity>
//               </View>
//               </View>
//                </View>
//               </View>
//               </Modal>
//               </ScrollView>
//              </SafeAreaView>
//             </View>

//   )
// }
// export default AddCourse
// const styles = StyleSheet.create({
//   container: {
//     flex: 1
//   },
//   FlatList__Data:{width: mobileW * 85 / 100,height: mobileW * 0.5 / 100, marginTop: mobileW * 3 / 100, marginBottom: mobileW * 3 / 100, backgroundColor: Colors.gray },
//   post___texttt:{ color: Colors.white_color,fontSize: mobileW * 4 / 100, fontWeight: '500'},
//   Alert_text: {
//     color: Colors.white_color,
//     fontSize: mobileW * 4.5 / 100,
//     fontWeight: '500'
//   },
//   multi:{
//     fontSize:mobileW*2/100,
//     color:Colors.green

//   },
//   dianamic___text:{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, },
//   modalview_view:{flex: 1, justifyContent: 'center', alignItems: 'center',  paddingVertical: mobileH * 7 / 100,backgroundColor: '#00000090' },
//   sharma_text:{ fontSize: mobileW * 3.1/ 100, color: Colors.gray,fontFamily:Font.FontRegular },
//   info_icon:{ width: mobileW * 5 / 100,height: mobileW * 5 / 100, borderRadius: mobileW * 2 / 100 },
//   choose_skill:{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
//   cHOOSECATEGORY_TEXT:{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
//   selectcategory:{ color: Colors.blackColor, fontSize: mobileW * 4 / 100, fontWeight: '500',alignSelf:"center" },
//   commission_TExt: {
//     fontSize: mobileW * 4 / 100,
//     fontWeight: '400',
//     color: Colors.blackColor,
//     textAlign: 'center'
//   },
//   ChooseCategory_text: {
//     color: Colors.white_color,
//     fontSize: mobileW * 4 / 100,
//     fontWeight: '500'
//   },
//   chooseskill_modal:{flex: 1,paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
//   multipletext:{ fontSize: mobileW * 4 / 100, color: Colors.black_color },
//   modal_commission: {
//     flex: 1,
//     // paddingVertical:mobileH*7/100,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: '#00000090'
//   },
//   skillCategory_close_view:{width: mobileW * 85 / 100, height: mobileW * 0.5 / 100, marginTop: mobileW * 3 / 100,marginBottom: mobileW * 3 / 100, backgroundColor: Colors.gray},
//   camcelok_whitetext:{ fontSize: mobileW * 4 / 100, fontWeight: '500', color: Colors.white_color },

//   category_view:{ flex: 1, paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
//   ok_cancel:{ fontSize: mobileW * 4 / 100, fontWeight: '500',
//    color: Colors.white_color },
//    modal____VIEW:{ flex: 1, paddingVertical: mobileH * 7 / 100, justifyContent: 'center', alignItems: 'center', backgroundColor: '#00000090' },
  
//   cancel_text: {
//     fontSize: mobileW * 4 / 100,
//     fontWeight: '500',
//     color: Colors.white_color
//   },
//   OK_TExt: {
//     fontSize: mobileW * 4 / 100,
//     fontWeight: '500',
//     color: Colors.white_color
//   },
//   success_modal:{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000096' },
//   okk: {
//     fontSize: mobileW * 4 / 100,
//     fontWeight: '500',
//     color: Colors.white_color
//   },
//   SafeArea_View: {
//     flex: 1,
//     backgroundColor: Colors.white_color
//   },
//   charges_view:{flexDirection: 'row',alignItems: 'center',justifyContent: 'center', marginTop: mobileW * 2 / 100 },
//   backIcon: {
//     width: mobileW * 6 / 100,
//     height: mobileW * 6 / 100,
//     tintColor: Colors.white_color,
//   },
//   ok_Button: {
//     width: mobileW * 22 / 100,
//     height: mobileW * 8 / 100,
//     backgroundColor: Colors.themecolor,
//     borderRadius: mobileW * 2 / 100,
//     alignSelf: "center",
//     alignItems: 'center',
//     justifyContent: 'center',
//     marginTop: mobileW * 2 / 100,
//     marginBottom: mobileW * 3 / 100
//   },
//   show_touchableview:{ width: mobileW * 94 / 100,  marginTop: mobileW * 4 / 100, borderColor: Colors.light_grey, alignSelf: 'center' },
//   backIcon_: {
//     width: mobileW * 9.5 / 100,
//     height: mobileW * 9.5/ 100,
//     tintColor: Colors.white_color,
//   },
//   _ModalCategory:{color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' },
//   OKKK_text:{ color: Colors.whiteColor, fontSize: mobileW * 4 / 100, fontWeight: '500' },
//   modalHeader: {
//     backgroundColor: Colors.themecolor,
//     height: mobileW * 12 / 100,
//     alignItems: 'center',
//     justifyContent: 'center',
//     borderTopLeftRadius: mobileW * 2 / 100,
//     borderTopRightRadius: mobileW * 2 / 100,
//     width: mobileW * 90 / 100
//   },
//   Main__View:{ flexDirection: 'row', alignSelf: 'flex-end', marginTop: mobileW * 5 / 100 },
 
//   modalCard: {
//     backgroundColor: Colors.whiteColor,
//     elevation: mobileW * 3 / 100,
//     borderBottomRightRadius: mobileW * 2 / 100,
//     borderBottomLeftRadius: mobileW * 2 / 100,
//     width: mobileW * 90 / 100
//   },
//   setprice_view:{ 
//     marginTop: mobileW * 2 / 100, 
//     width: mobileW * 45 / 100, 
//     marginLeft:mobileW*3/100,
//     // height:mobileW*10/100
//   },

//   HeaderText: {
//     color: Colors.white_color,
//     marginHorizontal: mobileW * 2 / 100,
//      fontSize: mobileW * 4.3 / 100,
//      fontFamily:Font.FontMedium
   
//   },
//   Header: {
//     backgroundColor: Colors.themecolor,
//     width: mobileW,
//     height: mobileW * 13/ 100,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     marginBottom: mobileW * 2 / 100
//   },
//   Categoryselect: {
//     width: mobileW * 94 / 100,
//     height: mobileW * 13 / 100,
//     padding: mobileW * 3 / 100,
//     margin: mobileW * 2 / 100,
//     borderWidth: mobileW * 0.3/ 100,
//     borderColor:"#9f9f9f",
//     backgroundColor: Colors.white_color,
//     elevation: 1,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     borderRadius: mobileW * 1 / 100,
//     alignSelf: 'center'
//   },
//   dateView: {
//     flexDirection: 'row',
//     marginTop: mobileW * 2 / 100,
//     width: mobileW * 94 / 100,
//     justifyContent: 'space-between',
//     alignSelf: 'center'
//   },
//   iconQuestionMark: {
//     width: mobileW * 6.5 / 100,
//     height: mobileW * 6.5 / 100,
//     tintColor: Colors.gray
//   },
//   success_text:{ color: Colors.whiteColor, fontSize: mobileW * 4 / 100, fontWeight: '500' },
//   CourseDurationText: {
//     marginLeft: mobileW * 5 / 100,
//     marginTop: mobileW * 1.5 / 100,
//     color: Colors.gray,
//     fontSize: mobileW * 2.9/ 100,
//     fontFamily:Font.FontRegular

//   },
//   sessionDurationTime: {
//     color: Colors.gray,
//     fontSize: mobileW * 3.5 / 100,
//     marginTop: mobileW * 2 / 100,
//     marginHorizontal: mobileW * 3 / 100,
//     marginLeft: mobileW * 5 / 100,
//   },
//   CalanderView: {
//     width: mobileW * 44 / 100,
//     height: mobileW * 13 / 100,
//     backgroundColor: Colors.whiteColor,
//     borderRadius: mobileW * 1 / 100,
//     padding: mobileW * 2 / 100,
//     flexDirection: 'row',
//     alignItems: 'center',
//     elevation: 2,
//     shadowColor: '#000',
//     borderWidth: mobileW * 0.2/ 100,
//     borderColor:"#9f9f9f",
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, },
//     shadowColor: '#000',
//     shadowOpacity: 0.1,
//     borderColor:Colors.gray
//   },
//   TimeView: {
//     marginLeft: mobileW * 3 / 100,
//     marginTop: mobileW * 1/ 100,
//     width: mobileW * 44 / 100,
//     height: mobileW * 13 / 100,
//     backgroundColor: Colors.whiteColor,
//     borderRadius: mobileW * 1 / 100,
//     justifyContent: 'center',
//     alignItems: 'center',
//     elevation: 2,
//     shadowColor: '#000',
//     borderColor: Colors.light_grey,
//     borderWidth: 1,
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, },
//     shadowColor: '#000',
//     shadowOpacity: 0.1,
//     borderColor: Colors.themecolor
//   },
//   calanderText: {
//     color: Colors.black_color,
//     alignSelf: 'center',
//     fontSize: mobileW * 4 / 100,
//     // fontWeight: '400',
//     marginHorizontal: mobileW * 2 / 100
//   },
//   calanderText1: {
//     color: Colors.gray,
//     fontSize: mobileW * 3 / 100,
//     fontWeight: '500',
//     marginHorizontal: mobileW * 12 / 100,
//     alignSelf: 'center'
//   },
//   UserEarning:{
//     color:Colors.blackColor,
//     fontSize:mobileW*4/100

//   },
//   PostButton: {
//     width: mobileW * 94 / 100,
//     height: mobileW * 12 / 100,
//     marginTop: mobileW * 3 / 100,
//     borderRadius: mobileW * 2.4 / 100,
//     backgroundColor: Colors.themecolor,
//     justifyContent: 'center',
//     alignItems: 'center',
//     alignSelf: 'center',
//     marginBottom: mobileW * 10 / 100
//   },
//   ModelCard: {
//     width: mobileW * 90 / 100,
//     // height:mobileH*90/100,
//     borderRadius: mobileW * 3 / 100,
//     backgroundColor: Colors.white_color,
//     elevation: 5
//   },
//   ModelHeader: {
//     width: mobileW * 90 / 100,
//     marginBottom: mobileW * 5 / 100,
//     justifyContent: 'center',
//     alignItems: 'center',
//     height: mobileW * 11 / 100,
//     borderTopLeftRadius: mobileW * 2 / 100,
//     borderTopRightRadius: mobileW * 2 / 100,
//     backgroundColor: Colors.themecolor
//   },
//   underline: {
//     width: mobileW * 85 / 100,
//     height: mobileW * 0.3 / 100,
//     marginTop: mobileW * 3 / 100,
//     marginBottom: mobileW * 3 / 100,
//     backgroundColor: Colors.gray
//   },
//   CancelBtn: {
//     width: mobileW * 25 / 100,
//     height: mobileW * 8 / 100,
//     borderRadius: mobileW * 2 / 100,
//     marginHorizontal: mobileW * 1 / 100,
//     alignItems: 'center',
//     justifyContent: 'center',
//     backgroundColor: Colors.themecolor
//   },
//   okBtn: {
//     width: mobileW * 25 / 100,
//     height: mobileW * 8 / 100,
//     borderRadius: mobileW * 2 / 100,
//     alignItems: 'center',
//     justifyContent: 'center',
//     backgroundColor: Colors.themecolor
//   },
//   DRAWER_image:{ 
//     width: mobileW * 3.4 / 100, 
//     height: mobileW * 3.4/ 100,
//     tintColor:'gray'
//   },
  
//   showBox: {
//     width: mobileW * 94 / 100,
//     elevation: 1,
//     padding: mobileW * 5 / 100,
//     borderRadius: mobileW * 2 / 100,
//     backgroundColor: Colors.white_color,
//     borderColor: Colors.gray,
//     borderWidth:mobileW*0.3/100
//   },
//   userCharges: {
//     marginTop: mobileW * 2 / 100,
//     width: mobileW * 45 / 100,
//     height: mobileW * 15/ 100,
//    marginRight:mobileW*3/100,
//     borderWidth: mobileW * 0.3 / 100,
//     borderRadius: mobileW * 1 / 100,
//     borderColor: Colors.gray,
//     alignItems: 'center',
//     justifyContent: 'center'
//   },
//   userCharges1: {
//     marginTop: mobileW * 2 / 100,
//     width: mobileW * 45 / 100,
//     height: mobileW * 15 / 100,
//     // marginHorizontal: mobileW * 2 / 100,
//     borderWidth: mobileW * 0.3 / 100,
//     borderRadius: mobileW * 1 / 100,
//     borderColor: Colors.themecolor,
//     alignItems: 'center',
//     justifyContent: 'center'
//   },
// })




import { View, StatusBar, TextInput, Text,StyleSheet, Dimensions, TouchableOpacity, Image, Modal, Alert } from 'react-native'
import React, { useState } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Colors } from './Provider/Colorsfont';

const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

import { ScrollView } from 'react-native-gesture-handler';
import { Value } from 'react-native-reanimated';

const ForgotPassword = ({ navigation }) => {

  const [password, setpassword] = useState('')

 

  return (
        <View style={{ flex: 1, backgroundColor: Colors.themecolor }}>
        <SafeAreaView style={styles.SafeAreaView}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
              <ScrollView>
               <View style={styles.header_view}>
               {/* <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.goBack()}>
               <Image style={styles.backIcon} resizeMode='contain'source={require("./Icon/icon_back.png")}></Image>
               </TouchableOpacity> */}
               
                <View style={{ alignItems: 'center' ,marginTop: mobileW * 4 / 100 }}>
                <Text style={styles.loginText}>Reset Password</Text>
                </View>
               </View>
               <View style={styles.cardView}>
            
            {/* ======================================= Phone ===================================== */}
            <View style={styles.phoneView}>
             
              <TextInput
                style={styles.input}
                placeholderTextColor={Colors.gray}
                value={password}
                onChangeText={(text) => { setpassword(text);
                }}
                placeholder="Email"
              />
            </View>
            {/* ======================================= Login Button ===================================== */}
            <TouchableOpacity activeOpacity={0.8} style={styles.LoginView}>
            <Text style={styles.LOGIN_TEXT}>SEND OTP</Text>
            </TouchableOpacity>
         
              </View>
      
               </ScrollView>
             </SafeAreaView>
      {/* </KeyboardAwareScroll> */}
    </View>

  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  backIcon: {
    width: mobileW * 5.5 / 100,
    height: mobileW * 5.5/ 100,
    tintColor: Colors.white_color
  },
  input: {
    height: mobileW * 12.8/ 100,
    padding:mobileW*2/100,
    color: Colors.black_color,
    width: mobileW * 57 / 100,
    backgroundColor: Colors.white_color,
    borderRadius: mobileW * 4 / 100,
    paddingRight: mobileW * 4 / 100,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,
  },
  loginText: {
    fontSize: mobileW *  7 / 100,
    color: Colors.white_color,
    fontWeight: '500',
    marginTop: mobileW * 1 / 100
  },
  cardView: {
    width: mobileW,
    height: mobileH * 86 / 100,
    backgroundColor: Colors.whiteColor,
    paddingLeft: mobileW * 6.5/ 100,
    paddingRight: mobileW * 6.5/ 100,
    borderTopLeftRadius: mobileW * 10 / 100,
  },
  phoneView: {
    backgroundColor: Colors.white_color,
    borderRadius: mobileW * 4 / 100,
    flexDirection: 'row',
    marginTop: mobileW * 15 / 100,
    elevation: 2,
    shadowColor: '#000',
    // borderColor: "#e8edfb",
    borderColor: Colors.gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,
    borderWidth:mobileW*0.20/100
  },
  LoginView: {
    justifyContent: 'center',
    alignItems: 'center',
    height: mobileW * 12.8/ 100,
    backgroundColor: Colors.themecolor,
    borderRadius: mobileW * 3 / 100,
    marginTop: mobileW * 10 / 100,
    elevation: 1,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    borderWidth: 0,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowOpacity: 0.1,
  },
  LOGIN_TEXT:{
     fontSize: mobileW * 3.5 / 100,
      color: Colors.white_color,
       fontWeight: "500" },
  header_view:{ 
    width: mobileW, 
    height: mobileH * 16 / 100,
     padding: mobileW * 3 / 100 
    },
  SafeAreaView:{ 
    flex: 0, 
    backgroundColor: Colors.themecolor 
  },
})

export default ForgotPassword

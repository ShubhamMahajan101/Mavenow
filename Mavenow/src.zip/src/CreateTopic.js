
import { View, ScrollView,  StatusBar, Modal, Alert, FlatList, Text, StyleSheet, Dimensions, TouchableOpacity, Image } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Stack, TextInput, } from "@react-native-material/core";
import { Colors, Font } from './Provider/Colorsfont';
import { config, msgProvider, msgText, consolepro, Lang_chg,  msgTitle, localimag, apifuntion, notification } from './Provider/utilslib/Utils';
import axios from 'axios';
import { SafeAreaView } from 'react-native-safe-area-context'
import { fonts } from 'react-native-elements/dist/config';
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;


export default function CreateTopic({navigation}) {
    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('')
    const [count, setCount] = useState('')
    const [duration, setDuration] = useState('')
  return (
    <View style={{ flex: 1, }}>
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
      <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
      {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
      <View style={styles.Header}>
      {/* <View style={{ flexDirection: 'row', alignItems: 'center' }}> */}
      <TouchableOpacity activeOpacity={0.8} style={{}} onPress={() => navigation.goBack()}>
      <Image style={{height:mobileW*10/100, height:mobileW*10/100, }} resizeMode='contain'source={require("./Icon/bk.png")}></Image>
      </TouchableOpacity>
      <Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontRegular, color:Colors.black_color, marginRight:mobileW*8/100}}>Create Topic</Text>
      </View>
      <View style={{alignSelf:'center',  width:mobileW*94/100}}>
      <View style={{width:mobileW*94/100, height:mobileW*0.3/100, backgroundColor:Colors.gray,fontFamily:Font.FontRegular, marginTop:mobileW*2/100}}></View>
      <Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontMedium, color:Colors.black_color, marginTop:mobileW*2/100}}>flutter</Text>
      <Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontRegular, color:Colors.gray, marginTop:mobileW*2/100}}>flutter description</Text>

<View >
      <TextInput style={{marginTop:mobileW*2/100, }}
onChangeText={(txt) => setTitle(txt)}
color={title==""? Colors.red:Colors.themecolor}label="title" variant="outlined"
trailing={props =>(<Text></Text>)}/>
</View>

<TextInput style={{marginTop:mobileW*2/100, }}
height={mobileW*47/100}
textAlignVertical={"top"}

onChangeText={(txt) => setDescription(txt)}
color={description==""? Colors.red:Colors.themecolor}label="Short Description" variant="outlined"
trailing={props =>(<Text></Text>)}/>

<Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontMedium, color:Colors.black_color, marginTop:mobileW*2/100}}>Lecturer Count</Text>
<View>
      <TextInput style={{marginTop:mobileW*2/100}}
onChangeText={(txt) => setCount(txt)}   
color={count==""? Colors.red:Colors.themecolor}label="count" variant="outlined"
trailing={props =>(<Text></Text>)}/>
</View>
<Text style={{fontSize:mobileW*3.5/100, fontFamily:Font.FontMedium, color:Colors.black_color, marginTop:mobileW*2/100}}>Duration:</Text>
<View>
      <TextInput style={{marginTop:mobileW*2/100}}
onChangeText={(txt) => setDuration(txt)}   
color={duration==""? Colors.red:Colors.themecolor}label="Duration:" variant="outlined"
trailing={props =>(<Text></Text>)}/>
</View>
  </View>


  {/* <View style={styles.textinput_view}>
      </View> */}

      <View style={{flexDirection:'row', alignSelf:'center', position:'absolute', bottom:8}}>
        <TouchableOpacity activeOpacity={0.8} style={{width:mobileW*45/100, height:mobileW*12/100, backgroundColor:Colors.lightgray,marginHorizontal:mobileW* 1/100, borderRadius:mobileW*2/100, alignItems:'center',justifyContent:'center'}}>
            <Text style={{fontSize:mobileW*4/100, color:Colors.black_color, fontFamily:Font.FontRegular}}>SAVE & EXIT</Text>
        </TouchableOpacity>
        <TouchableOpacity activeOpacity={0.8} style={{width:mobileW*45/100, height:mobileW*12/100, backgroundColor:Colors.themecolor,marginHorizontal:mobileW* 1/100, borderRadius:mobileW*2/100, alignItems:'center',justifyContent:'center'}}>
        <Text style={{fontSize:mobileW*4/100, color:Colors.white_color, fontFamily:Font.FontRegular}}>SAVE & NEXT</Text>
        </TouchableOpacity>
      </View>
      </SafeAreaView>
      </View>
  )
}
const styles = StyleSheet.create({
    container: {
      flex: 1
    },
    Header: {
      backgroundColor: Colors.white_color,
      width: mobileW, 
      height: mobileW * 13 / 100,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between'
    },
    backIcon_: {

        // width: mobileW * 9.5 / 100,
        // height: mobileW * 9.5 / 100,
        tintColor: Colors.white_color
      },
})
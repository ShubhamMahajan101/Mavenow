import { View, Text, Dimensions } from 'react-native'
import React, { useCallback, useRef, useState, useEffect } from 'react'
import YoutubePlayer from "react-native-youtube-iframe";
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

export default function YouTubePlayer() {

    const [playing, setPlaying] = useState(false);

    const onStateChange = useCallback((state) => {
      if (state === "ended") {
        setPlaying(false);
        Alert.alert("video has finished playing!");
      }
    }, []);

  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'black'}}>
       <YoutubePlayer
        height={mobileH*30/100}
        width={mobileW*98/100}
        play={playing}
        videoId={"27WN1UKKphA"}
        onChangeState={onStateChange}
        onFullScreenChange={true}
    />
    </View>
  )
}
 
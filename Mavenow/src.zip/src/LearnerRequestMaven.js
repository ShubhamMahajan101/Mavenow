
import { View, ScrollView, StatusBar, Modal, Alert, Text, StyleSheet, Dimensions, TouchableOpacity, Image } from 'react-native'
import React, { useState,useEffect } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Font } from './Provider/Colorsfont';
import moment from 'moment';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Stack, TextInput, } from "@react-native-material/core";
const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;

export default function LearnerRequestMaven({ navigation, route }) {

  // const item = .params.recommendedItem;
  // console.log('data',item);

  const item = route.params.item;
  console.log('item', item);
  // console.log('data-----',item.SkillsCategory);

  const [datePicker, setShow] = useState(false);
  const [timePicker, setTimePicker] = useState(false);
  const [date, setdate] = useState('Start Date');
  const [time, setTime] = useState('Start Time');
  const [price ,setPrice]=useState('');
  const [Percentage ,setPercentage]=useState('default');


  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible1, setModalVisible1] = useState(false);


  const [email, setEmail] = useState('');
  console.log("price=====", email);
  useEffect(() => {
    const per=((price)*5/100);
    setPercentage(price-per);
    }, [price])
  

  const setDatetoFunction = (date) => {
    setTimePicker(false)
    setTimeout(() => {
      console.log(timePicker);
    }, 500);

    var formateDate = date.nativeEvent.timestamp

    let newDate = moment(new Date(formateDate)).format('DD/MM/YYYY')

    setdate(newDate)

    console.log('date is here--------->>>>>>', newDate);
  }
  const setTimetoFunction = (given_time) => {
    console.log(given_time)
    setShow(false)
    var formateDate = given_time.nativeEvent.timestamp
    var hours = new Date(formateDate).getHours(); //Current Hours
    var min = new Date(formateDate).getMinutes(); //Current Minutes
    var sec = new Date(formateDate).getSeconds(); //Current Seconds

    var formattedDate = hours + ":" + min // + ":" + sec
    setTime(formattedDate)
    console.log('Time is here===========', formattedDate);

  }
  return (
    <View style={{ flex: 1, }}>
      <SafeAreaView style={{ flex: 1, backgroundColor: Colors.white_color }}>
        <StatusBar barStyle="light-content" hidden={false} backgroundColor={Colors.themecolor} />
        {/* ++++++++++++++++++++++++++++++++++++++ Header ++++++++++++++++++++++++++++++++++++++++ */}
        <View style={styles.Header}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity activeOpacity={0.8} style={{ marginHorizontal: mobileW * 2 / 100 }} onPress={() => navigation.goBack()}>
              <Image style={styles.backIcon_} resizeMode='contain'
                source={require("./Icon/bk.png")}></Image>
            </TouchableOpacity>
            <Text style={{ color: Colors.white_color, marginHorizontal: mobileW * 3/ 100, fontSize: mobileW * 4.3 / 100,fontFamily:Font.FontMedium }}>Learner Request</Text>
          </View>
          <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(true)} style={{ marginRight: mobileW * 2 / 100 }} >
            <Image style={styles.backIcon} resizeMode='contain'
              source={require("./Icon/icon_info.png")}></Image>
          </TouchableOpacity>
        </View>
        {/* ++++++++++++++++++++++++++++++++++++++ Search Bar ++++++++++++++++++++++++++++++++++++++++ */}
        {/* {"Join Date :" + moment(name.createdOn).format("MMM DD, yyyy")} */}
        <View style={styles.DetailsCard}>
          <Text style={{ color: Colors.black_color, fontSize: mobileW * 3 / 100, alignSelf: 'flex-end', marginTop: mobileW * 2 / 100 }}>Posting date : {moment(item.DateOfRequest).format('MMM DD, YYYY')}</Text>
          <View style={{ flexDirection: 'row', marginTop: mobileW * 2 / 100 }}>
            <View style={{ width: mobileW * 31 / 100, alignItems: 'center' }} >
              <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('LearnersDetail')} style={styles.StudentLernerView}>
                <Image style={{ width: mobileW * 13 / 100, height: mobileW * 13 / 100, alignSelf: 'center' }}
                  source={require('./Icon/icon_student.png')}></Image>
              </TouchableOpacity>
              <Text style={{ color: Colors.black_color, fontSize: mobileW * 4 / 100, marginTop: mobileW * 2 / 100, fontWeight: '500' }}>{item.userDetail.FullName}</Text>
              <View style={{ flexDirection: 'row', marginTop:mobileW*1/100 }}>
                <TouchableOpacity activeOpacity={0.8}>
                  <Image resizeMode='contain' style={{ width: mobileW * 4.5 / 100, height: mobileW *4.5 / 100, alignSelf: 'center', tintColor: 'lightgray' }}
                    source={require('./Icon/star.png')}></Image>
                </TouchableOpacity>
                <TouchableOpacity activeOpacity={0.8}>
                  <Image resizeMode='contain' style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100, alignSelf: 'center', tintColor: 'lightgray' }}
                    source={require('./Icon/star.png')}></Image>
                </TouchableOpacity>
                <TouchableOpacity activeOpacity={0.8}>
                  <Image resizeMode='contain' style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100, alignSelf: 'center', tintColor: 'lightgray' }}
                    source={require('./Icon/star.png')}></Image>
                </TouchableOpacity> 
                <TouchableOpacity activeOpacity={0.8}>
                  <Image resizeMode='contain' style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100, alignSelf: 'center', tintColor: 'lightgray' }}
                    source={require('./Icon/star.png')}></Image>
                </TouchableOpacity>
                <TouchableOpacity activeOpacity={0.8}>
                  <Image resizeMode='contain' style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100, alignSelf: 'center', tintColor: 'lightgray' }}
                    source={require('./Icon/star.png')}></Image>
                </TouchableOpacity>
              </View>

            </View>
            <View style={{ width: mobileW * 63 / 100, }} >
              <Text style={{ color: Colors.black_color, fontWeight: '500', fontSize: mobileW * 3.5 / 100 }}>I want to learn {item.name} (Basic)</Text>
              <View style={{ flexDirection: 'row', marginTop: mobileW * 2 / 100, }}>
                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <View style={{}}>
                    <Text style={{ fontSize: mobileW * 2.5 / 100, color: Colors.gray }}>Category</Text>
                  </View>

                </View>
                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <View style={{}}>
                    <Text style={{ fontSize: mobileW * 2.5 / 100, color: Colors.gray }}>Skill</Text>
                  </View>
                </View>
              </View>

              <View style={{ flexDirection: 'row', marginTop: mobileW * 1 / 100 }}>
                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color }}>{item.SkillsCategory}</Text>
                </View>

                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color, width: mobileW * 30 / 100, }}>{item.name} [Basic]</Text>
                </View>
              </View>

              <View style={{ flexDirection: 'row' }}>
                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <View style={{ marginTop: mobileW * 1 / 100, }}>
                    <Text style={{ fontSize: mobileW * 2.5 / 100, color: Colors.gray }}>Details</Text>
                  </View>
                </View>
              </View>

              <View style={{ flexDirection: 'row', marginTop: mobileW * 2 / 100 }}>
                <View style={{ width: mobileW * 31.5 / 100, }}>
                  <Text style={{ fontSize: mobileW * 3 / 100, color: Colors.black_color, width: mobileW * 30 / 100 }}>{item.ShortDescription}</Text>
                </View>
              </View>

            </View>

          </View>
          <View style={{ width: mobileW * 90 / 100, marginTop: mobileW * 5 / 100, flexDirection: 'row', alignSelf: 'center', }}>
            <TouchableOpacity onPress={() => setModalVisible1(true)} activeOpacity={0.8} style={styles.selectBtn}>
              <Text style={{ color: Colors.white_color, fontWeight: '500', fontSize: mobileW * 3.5 / 100 }}>Select</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.8} style={styles.chatBtn} onPress={()=>navigation.navigate('Chat')}>
              <Text style={{ color: Colors.white_color, fontWeight: '500', fontSize: mobileW * 3.5 / 100 }}>Let's Chat</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* =================================================================Model================================================================ */}
          <View>
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              setModalVisible(!modalVisible);
            }} >
            <View style={{ flex: 1, backgroundColor: '#00000090', justifyContent: 'center', alignItems: 'center' }}>
              <View style={styles.modalCard}>
                <View style={styles.modalHeader1}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}></Text>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 5 / 100, fontWeight: '500' }}>Help:Learner Request</Text>
                  <TouchableOpacity activeOpacity={0.8} onPress={() => setModalVisible(!modalVisible)} style={{ marginRight: mobileW * 2 / 100 }} >
                    <Image style={styles.backIcon} resizeMode='contain'
                      source={require("./Icon/close2.png")}></Image>
                  </TouchableOpacity>
                </View>
                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    <Text style={{ color: Colors.dark_gray, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                      Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                      when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                      It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                      It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                      and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

                    </Text>
                  </View>
                </ScrollView>
              </View>
            </View>
          </Modal>
        </View>

        {/* ================================================================= Tiem Duration Model================================================================ */}
        <View  >
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible1}
            onRequestClose={() => {
              Alert.alert("Modal has been closed.");
              setModalVisible1(!modalVisible1);
            }}
          >
            <View style={{ flex: 1, backgroundColor: '#00000090', justifyContent: 'center', alignItems: 'center' }}>
              <View style={styles.modalCard}>
                <View style={styles.modalHeader}>
                  <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>Duration:</Text>
                </View>
                <ScrollView>
                  <View style={{ alignItems: 'center', padding: mobileW * 3 / 100 }}>

                    {/* ================================================================= Date / Time ================================================================ */}

                    <View style={{ flexDirection: 'row' }}>
                      {timePicker && (                                                                   //Date Picker
                        <DateTimePicker
                          mode={'date'}
                          value={new Date(Date.now())}
                          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                          is24Hour={false}
                          onChange={text => setDatetoFunction(text)}/>)}
                      <TouchableOpacity activeOpacity={0.8} onPress={() => setTimePicker(true)} style={styles.CalanderView}>
                        <Image resizeMode='contain' style={styles.iconQuestionMark}
                          source={require('./Icon/icon_calendar.png')}></Image>
                        <Text style={styles.calanderText}>{date}</Text>
                      </TouchableOpacity>

                      {datePicker && (                                                                   //Date Picker
                        <DateTimePicker
                          mode={'time'}
                          value={new Date(Date.now())}
                          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                          is24Hour={false}
                          onChange={text => setTimetoFunction(text)} />  )}
                      <TouchableOpacity activeOpacity={0.8} onPress={() => setShow(true)} style={styles.CalanderView}>
                        <Image resizeMode='contain' style={styles.iconQuestionMark}
                          source={require('./Icon/icon_calendar.png')}></Image>
                        <Text style={styles.calanderText}>{time}</Text>
                      </TouchableOpacity>
                    </View>

                    <View style={{ marginTop: mobileW * 5 / 100, flexDirection: 'row', }}>
                      {/* <TextInput style={{ width: mobileW * 40 / 100, marginHorizontal: mobileW * 2 / 100 }}
              onChangeText={(text) => { setPrice(text) }}
                        
                        keyboardType={'numeric'}
                        color={Colors.themecolor} 
                        value={price}
                        label="Course Fee" variant="outlined" trailing={props => (<Text></Text>)} /> */}
                        {/* {price!=="" */}
                           <TextInput  style={{ width: mobileW * 40 / 100, height:mobileW*15/100, marginHorizontal: mobileW * 2 / 100,borderColor:Colors.themecolor }}
                           onChangeText={(text) => { setPrice(text) }}
                           value={price}
                           height={mobileW*15/100}
                           keyboardType={'number-pad'}
                           color={Colors.themecolor} 
                           label="Concern fee per " variant="outlined" />
                           
                           {Percentage != ""?
                 <View style={styles.userCharges1}>
                 <Text style={styles.multipletext}>{Percentage}</Text>
                </View>
                 :
               <View style={styles.userCharges}>
               <Text style={styles.multipletext}>User Earning</Text>
               </View>
              }

                      {/* <TextInput style={{ width: mobileW * 40 / 100, marginHorizontal: mobileW * 2 / 100 }}
                        value={Percentage}
                        onChangeText={(text) => { setPercentage(text) }}

                        color={Colors.themecolor} label="Your Earning*" variant="outlined" trailing={props => (<Text></Text>)} /> */}
                    </View>
                  </View>
                  {/* =================================================================================================================================================================================== */}
                  <View style={{ padding: mobileW * 1 / 100 }}>
                    <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.gray, marginHorizontal: mobileW * 2 / 100, }}>Session Duration</Text>
                    <TouchableOpacity activeOpacity={0.8} style={styles.sessionDurationView}>
                      <Image resizeMode='contain' style={styles.iconQuestionMark}
                        source={require('./Icon/icon_calendar.png')}></Image>
                      <Text style={styles.sessionDuration}>{time}</Text>
                    </TouchableOpacity>
                   </View>
                    <View style={{ padding: mobileW * 1 / 100, flexDirection: 'row', marginTop: mobileW * 3 / 100 ,marginBottom:mobileW*4/100}}>
                    <TouchableOpacity onPress={() => setModalVisible1(!modalVisible1)} activeOpacity={0.8} style={styles.ModelButton}>
                      <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={0.8} style={[styles.ModelButton, { marginHorizontal: mobileW * 2 / 100 }]}>
                      <Text style={{ color: Colors.white_color, fontSize: mobileW * 4 / 100, fontWeight: '500' }}>Ok</Text>
                    </TouchableOpacity>
                  </View>
                </ScrollView>
              </View>
            </View>
          </Modal>
        </View>
      </SafeAreaView>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  Header: {
    backgroundColor: Colors.themecolor,
    width: mobileW, height: mobileW * 13 / 100,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  backIcon: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.white_color
  },
  backIcon_: {
    width: mobileW * 9.5/ 100,
    height: mobileW * 9.5/ 100,
    tintColor: Colors.white_color
  },
  multipletext:{ fontSize: mobileW * 4 / 100, color: Colors.black_color },
  DetailsCard: {
    width: mobileW * 98 / 100,
    backgroundColor: Colors.white_color,
    borderRadius: mobileW * 1 / 100,
    margin: mobileW * 1 / 100,
    padding: mobileW * 2 / 100,
    alignSelf: 'center',
    elevation: 1,
    shadowColor: '#000',
    borderColor: "#e8edfb",
    borderWidth: 1,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, },
    shadowColor: '#000',
    shadowOpacity: 0.1,
  },
  StudentLernerView: {
    width: mobileW * 16 / 100,
    height: mobileW * 16 / 100,
    justifyContent: 'center',
    borderWidth: mobileW * 0.5 / 100,
    borderColor: Colors.themecolor,
    borderRadius: mobileW * 10 / 100
  },
  chatBtn: {
    width: mobileW * 43 / 100,
    height: mobileW * 12 / 100,
    marginHorizontal: mobileW * 4 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: mobileW * 1 / 100,
    backgroundColor: Colors.themecolor
  },
  selectBtn: {
    width: mobileW * 43 / 100,
    height: mobileW * 12 / 100,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: mobileW * 1 / 100,
    backgroundColor: Colors.themecolor
  },
  userCharges1: {

    width: mobileW * 42 / 100,
    height: mobileW * 15.2 / 100,
    marginHorizontal: mobileW * 2 / 100,
    borderWidth: mobileW * 0.5 / 100,
    borderRadius: mobileW * 1 / 100,
    borderColor: Colors.themecolor,
    alignItems: 'center',
    justifyContent: 'center'
  },
  userCharges: {

    width: mobileW * 42 / 100,
    height: mobileW * 15.2 / 100,
    marginHorizontal: mobileW * 2 / 100,
    borderWidth: mobileW * 0.5 / 100,
    borderRadius: mobileW * 1 / 100,
    borderColor: Colors.themecolor,
    alignItems: 'center',
    justifyContent: 'center'
  },
  input: {
    height: mobileW * 12 / 100,
    margin: mobileW * 2 / 100,
    borderRadius: mobileW * 1 / 100,
    borderWidth: 1,
    padding: mobileW * 2 / 100,
    borderColor: Colors.themecolor
  },
  CalanderView: {
    width: mobileW * 40 / 100,
    marginHorizontal: mobileW * 2 / 100,
    height: mobileW * 14 / 100,
    marginTop: mobileW * 3 / 100,
    borderRadius: mobileW * 1 / 100,
    padding: mobileW * 2 / 100,
    borderWidth: mobileW * 0.5 / 100,
    borderColor: Colors.themecolor,
    flexDirection: 'row',
    alignItems: 'center'
  },
  modalHeader: {
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    width: mobileW * 90 / 100,
    height: mobileW * 12 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    backgroundColor: Colors.themecolor
  },
  sessionDurationView: {
    width: mobileW * 40 / 100,
    marginHorizontal: mobileW * 2 / 100,
    height: mobileW * 13 / 100,
    marginTop: mobileW * 1 / 100,
    borderRadius: mobileW * 1 / 100,
    padding: mobileW * 2 / 100,
    borderWidth: mobileW * 0.5 / 100,
    borderColor: Colors.themecolor,
    flexDirection: 'row',
    alignItems: 'center'
  },
  calanderText: {
    color: Colors.gray,
    alignSelf: 'center',
    fontSize: mobileW * 2.8 / 100,
    fontWeight: '500',
    marginHorizontal: mobileW * 2 / 100
  },
  sessionDuration: {
    color: Colors.gray,
    fontSize: mobileW * 4 / 100,
    fontWeight: '500',
    marginHorizontal: mobileW * 2 / 100
  },
  iconQuestionMark: {
    width: mobileW * 6 / 100,
    height: mobileW * 6 / 100,
    tintColor: Colors.gray
  },
  modalCard: {
    width: mobileW * 90 / 100,
    borderRadius: mobileW * 3 / 100,

    backgroundColor: Colors.white_color,
    elevation: 5
  },
  ModelButton: {
    width: mobileW * 40 / 100,
    height: mobileW * 10 / 100,
    borderRadius: mobileW * 1 / 100,
    marginHorizontal: mobileW * 2 / 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.themecolor,
  },
  modalHeader1: {
    width: mobileW * 90 / 100,
    height: mobileW * 12 / 100,
    borderTopLeftRadius: mobileW * 2 / 100,
    borderTopRightRadius: mobileW * 2 / 100,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.themecolor
  }
}
)

import React, { useEffect, useState } from 'react'
import { Text, View, Image, StyleSheet, StatusBar, Dimensions, PermissionsAndroid } from 'react-native'
 const mobileW = Dimensions.get('window').width;
const mobileH = Dimensions.get('window').height;
 import { config, msgProvider, localStorage, apifuntion, msgText, msgTitle, consolepro, Font, Colors, localimag, Currentltlg } from './utilslib/Utils';


export default function Splash({ navigation }) {
  useEffect(() => {
     authenticateSession();
  }, []);

  const authenticateSession = async () => {
     // ---------- For Onboarding Page Start -----------
    let OnboardingPage = await localStorage.getItemString('OnboardingPage')
    if(OnboardingPage==null){
      setTimeout(() => {
        navigation.navigate('Onbording')
      }, 1500);
    }else{
      let OnboardingPageNav = await localStorage.getItemString('OnboardingPage')
      if(OnboardingPageNav == 'Done'){
        console.log('----------------',OnboardingPage);
      // ---------- For AutoLogin Start -----------
        let user_Details = await localStorage.getItemObject('user_arr')
        console.log('user_Details----------',user_Details);
        if(user_Details==null){
          setTimeout(() => {
            navigation.navigate('Login')
          }, 1500);
        }else{
          setTimeout(() => {
            navigation.navigate('UserMaven')
          }, 1500);
        }
        // ---------- For AutoLogin End -----------
      }else{
        setTimeout(() => {
          navigation.navigate('Onbording')
        }, 1500);
      }
    }
     // ---------- For Onboarding Page End -----------
  }
  
  return (
    <View style={styles.container}>
      <StatusBar
        hidden={false}
        backgroundColor={Colors.themecolor}
        translucent={false}
        barStyle="dark-content"
        networkActivityIndicatorVisible={true}
      />
      <Image style={{width:mobileW*80/100, height:mobileW*40/100}}
      source={require('../Icon/mavenow_splash_screen.png')}></Image>
   <Text style={{fontFamily:Font.FontMediumItalic}} ></Text>
    </View>
  ) 
}
const styles = StyleSheet.create({
  container: {
    flex: 1,alignItems: 'center',justifyContent: 'center', backgroundColor: Colors.themecolor
  },
  logo: {height: mobileH, width: mobileW
  },
});